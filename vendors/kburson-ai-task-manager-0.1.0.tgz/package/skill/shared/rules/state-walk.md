<!-- aitm-skill-version: 1.2.0 -->
<!-- aitm-rule-id: state-movement -->

# rules/state-walk.md

Tier-2. Loaded JIT on `/task promote`, `/task demote`, `/task next`, `/task reconcile`. On first read, emit:

```
aitm-skill-loaded:rules/state-walk:1.2.0
```

## 8-state model

```
backlog → refine → ready-for-plan → plan → develop → test → review → done
```

`ready-for-plan` (display: "Ready for Planning") is the durable parking state after active refinement and before short-lived JIT Plan. `backlog → refine` begins shaping; `refine → ready-for-plan` records current refinement evidence; `ready-for-plan → plan` admits JIT planning. Assignment is ownership metadata, not a lifecycle state, and Plan→Develop enforces the exclusive local owner at the last responsible moment.

Internal state slugs and sanctioned `/task` inputs are canonical; they recognize
only the current state names. The raw, internal-only `move-state.mjs` boundary
temporarily accepts `on-deck` as a one-release compatibility alias and warns
before canonicalizing it to `assigned`. This narrow migration shim does not add
a user-facing `/task` alias or another lifecycle state. See
`docs/migration-history.md` for the migration history.

## Canonical verbs

| Verb                                                    | Action                                                                                                                                                                                                                              |
| ------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `/task promote [<N>]`                                   | Forward one state. Reads current state, picks legal next state, runs the gate.                                                                                                                                                      |
| `/task next [<N>]`                                      | Alias of `/task promote`.                                                                                                                                                                                                           |
| `/task demote [<N>]`                                    | Back to `develop` from `test`/`review`. Code-rework path; requires `--rework "<reason>"`. Invalidates stale AC/VC/DoD evidence and records the demotion in the timing log.                                                          |
| `/task park <N> --reason "<text>"`                      | Back to `backlog` from `refine`/`plan`. For a falsified premise or deprioritization — not code rework. Requires a reason; preserves Priority/Size/Estimate and any already-stamped evidence untouched.                              |
| `/task reconcile <N> <accept-live\|revert-to-recorded>` | Drift recovery. Board ↔ local field-DB disagreement. `accept-live` treats GitHub Projects as source of truth; `revert-to-recorded` pushes the local recorded state back to the board. Run before any other verb on a drifted issue. |

`/task plan-approve #N`, `/task approve #N`, and `/task reject #N --reason "..."` remain first-class — they are gate verbs, not state-walking verbs.

## Workflow exceptions

Workflow exceptions never add a state or permit a state jump. Inspect the
effective policy without mutation using
`/task workflow-preflight #N --target <state> [--json]`. A preflight result is
advisory and conditional on future evidence; it does not bind the issue, start a
timer, activate an exception, or authorize a later mutation.

Only a current explicit `aitm.workflow-exception/v1` GitHub record can waive a
catalogued planning, semantic-review, or approval requirement. Every affected
boundary reloads and revalidates repository, issue, scope, expiry, revision, and
authority. Missing, expired, revoked, stale, malformed, unsupported, or ambiguous
records fail closed. A waiver is recorded as `waived`, never `passed`, and does
not imply a separate completion approval. Retained tests, verification evidence,
ownership, dependencies, binding, state contiguity, exact-SHA provenance, CI,
safe delivery, and external protection remain required.

`/task dod-stamp <key>` is a Test-stage helper, not a state-walking verb. It runs the verifier declared on a Functional DoD item **only when no valid exact-SHA Test receipt already covers that HEAD**; otherwise it stamps from the receipt. Review must not spawn standard lanes — reuse or refuse (demote + `/task test`). See `rules/functional-dod.md`.

`/task ac-stamp <label>` and `/task test` are Develop/Test-stage helpers, not state-walking verbs. `ac-stamp` runs the verifier command(s) declared on an Acceptance Criteria item and stamps genuine execution-proof evidence (exit/sha/ts/key) onto that AC. `test` runs the full Verification Commands suite in a fresh sandbox worktree and, on an all-green result, auto-ticks passing checkboxes/DoD items and moves the issue to Test. Neither advances the kanban board on its own the way `promote`/`demote`/`close` do.

## Forbidden

- ❌ `move-state.mjs <N> <state>` directly to jump arbitrarily. Always use `/task promote` (or `next`) to advance one step and `/task demote` to step back. One step at a time prevents stage-skipping (e.g., Backlog → Develop).
- ❌ `move-state.mjs <N> done` directly. Only `/task close` does that, internally.
- ❌ User-facing `/task move <state>` verb. Does not exist.

## Test → Review

No CLI verb. Agent self-reports `REVIEW_COMPLETE`. The orchestrator confirms the report and runs `/task promote` to move the issue.

## Plan → Develop gate

`/task promote` from Plan refuses unless `<!-- aitm-plan-approved: <ts> -->` is in the issue body. Record approval first with `/task plan-approve #N` (idempotent; valid only while issue is in Plan). Toggled by `gateAnalysisToDevelopment` (legacy name retained).

## Estimation comment surfaces

See [`docs/guides/workflow.md`](../../../docs/guides/workflow.md) → Three-stage estimation for the comment-emitting verbs (`/task promote` from Plan, `/task close`) and their bypass envs.

## Scratch directories during state walks

State-walk verbs that materialize transient files (issue body drafts, plan/heal/inspect scratch, sandbox temp dirs) route through `scripts/task-tracker/lib/scratch-dir.mjs` — `projectScratchDir`, `mkdtempProjectIsolated`, `mkdtempOutsideRepo`. Never write to `/tmp/` / `os.tmpdir()`. Full rule: [`rules/scratch-dirs.md`](scratch-dirs.md). Enforced by `npm run lint:tmp`.

## Drift detection

If `task-tracker.mjs` reports a state mismatch between the board and `.ai-task-manager/task-tracker-state.json`, run `reconcile` BEFORE any other verb. Running `promote` or `demote` on a drifted issue compounds the drift.

```bash
npx aitm reconcile <accept-live|revert-to-recorded> <N>
```

Choose `accept-live` when the board reflects an out-of-band human move; `revert-to-recorded` when an unintended board edit happened and the recorded state was correct.
