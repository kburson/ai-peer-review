#!/bin/bash
# Interactive setup for ai-task-manager.
# Walks through GitHub auth, discovers GitHub Projects V2 field/option IDs,
# and writes .ai-task-manager/task-tracker.json + .github/ISSUE_TEMPLATE/ in the target project.
#
# Usage: scripts/gh/init-project-config.sh [--target <project-dir>]

set -euo pipefail

# ── helpers ────────────────────────────────────────────────────────────────
# Color palette: bold/dim, fg colors, and a couple of bg banners. Each visual
# helper aims to delineate sections clearly without becoming visually noisy.

bold()    { printf "\033[1m%s\033[0m\n" "$*"; }
dim()     { printf "\033[2m%s\033[0m" "$*"; }
info()    { printf "  \033[36m🔹\033[0m %s\n" "$*"; }
ok()      { printf "  \033[32m✅\033[0m %s\n" "$*"; }
warn()    { printf "  \033[33m⚠️ \033[0m %s\n" "$*"; }
err()     { printf "  \033[31m❌\033[0m %s\n" "$*" >&2; }
prompt()  { printf "  \033[35m❓\033[0m \033[1m%s\033[0m " "$*"; }
divider() { printf "  \033[2m─────────────────────────────────────────────────────────\033[0m\n"; }

# banner <emoji> <title> [subtitle]
banner() {
  local emoji="$1" title="$2" sub="${3:-}"
  local pad="                                                              "
  echo
  printf "\033[44m\033[97m\033[1m%s\033[0m\n" "  ${pad:0:60}"
  printf "\033[44m\033[97m\033[1m  %s  %-56s\033[0m\n" "$emoji" "$title"
  if [[ -n "$sub" ]]; then
    printf "\033[44m\033[97m  \033[2m   %-57s\033[0m\n" "$sub"
  fi
  printf "\033[44m\033[97m\033[1m%s\033[0m\n" "  ${pad:0:60}"
  echo
}

# step <emoji> <"Step X of Y"> <title>
step() {
  local emoji="$1" idx="$2" title="$3"
  echo
  printf "\033[36m▸\033[0m \033[1m%s  %s · %s\033[0m\n" "$emoji" "$idx" "$title"
  divider
  echo
}

# success_banner <message>
success_banner() {
  local msg="$1"
  local pad="                                                              "
  echo
  printf "\033[42m\033[30m\033[1m  ✅  %-56s\033[0m\n" "$msg"
  echo
}

jq_get() {
  # jq_get <json-string> <jq-filter>
  echo "$1" | jq -r "$2" 2>/dev/null || echo ''
}

# ── args ───────────────────────────────────────────────────────────────────

TARGET_DIR=""
PROJECT_INPUT=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --target) TARGET_DIR="$2"; shift 2 ;;
    --project) PROJECT_INPUT="$2"; shift 2 ;;
    --project-url) PROJECT_INPUT="$2"; shift 2 ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
done

if [[ -z "$TARGET_DIR" ]]; then
  TARGET_DIR=$(git rev-parse --show-toplevel 2>/dev/null || echo "${CLAUDE_PROJECT_DIR:-$(pwd)}")
fi

CONFIG_DIR="$TARGET_DIR/.ai-task-manager"
CONFIG_FILE="$CONFIG_DIR/task-tracker.json"
mkdir -p "$CONFIG_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
# Deterministic config-authoring / template-writing / parsing logic lives in a
# tested node CLI (scripts/task-tracker/config-init.mjs, @story #560); this bash
# is the interactive gh/GraphQL orchestration shim that delegates to it.
CONFIG_INIT_CLI="$PKG_ROOT/scripts/task-tracker/config-init.mjs"
FIELD_DEFS_FILE="$CONFIG_DIR/project-fields.json"
FIELD_EVENTS_FILE="$CONFIG_DIR/project-field-events.json"

# Validate the existing canonical/legacy Assigned config keys before any
# GraphQL project mutation can run. The final writer repeats this invariant;
# this early read-only pass prevents a late conflict from leaving a partially
# mutated board behind.
if ! node "$CONFIG_INIT_CLI" preflight-config --file "$CONFIG_FILE"; then
  err "Existing task-tracker config is ambiguous; init refused before project mutation."
  exit 1
fi

check_field_defs_drift() {
  local local_file="$1"
  local default_file="$2"
  local label="$3"
  if [[ ! -f "$local_file" || ! -f "$default_file" ]]; then return 0; fi
  local drift
  drift=$(node "$SCRIPT_DIR/lib/field-defs-drift.mjs" "$local_file" "$default_file" 2>/dev/null || echo '')
  if [[ -z "$drift" || "$drift" == "in-sync" ]]; then return 0; fi
  echo ""
  warn "$label drift detected — $drift"
  local ans
  printf "Refresh %s from package default? [y/N]: " "$label" >&2
  read -r ans </dev/tty || ans=""
  if [[ "$ans" =~ ^[Yy]$ ]]; then
    cp -f "$default_file" "$local_file"
    ok "Refreshed $label."
  else
    info "Keeping existing $label. Re-run after manual reconciliation if needed."
  fi
}

# ── banner ─────────────────────────────────────────────────────────────────

banner "🎯" "ai-task-manager — Project Setup" "Target: $TARGET_DIR"

# ── step 1: github auth ────────────────────────────────────────────────────

step "🔐" "Step 1 of 5" "GitHub Authentication"

if ! command -v gh &>/dev/null; then
  err "GitHub CLI (gh) not found. Install from: https://cli.github.com"
  exit 1
fi

if ! command -v jq &>/dev/null; then
  err "jq not found. Install it:"
  err "  macOS:  brew install jq"
  err "  Linux:  apt install jq  (or equivalent)"
  err "  Windows: winget install jqlang.jq"
  exit 1
fi

if ! command -v node &>/dev/null; then
  err "Node.js not found. Install Node.js 24+ from: https://nodejs.org"
  exit 1
fi

if gh auth status &>/dev/null; then
  GH_USER=$(gh api user --jq '.login' 2>/dev/null || echo "unknown")
  ok "Already authenticated as: $GH_USER"
else
  warn "Not authenticated with GitHub CLI."
  echo ""
  info "Starting GitHub authentication..."
  echo ""
  gh auth login
  GH_USER=$(gh api user --jq '.login' 2>/dev/null || echo "unknown")
  ok "Authenticated as: $GH_USER"
fi

AUTH_STATUS=$(gh auth status 2>&1 || true)
if ! echo "$AUTH_STATUS" | grep -Eq "Token scopes:.*'project'|Token scopes:.*'read:project'"; then
  err "GitHub Projects V2 access is not enabled for the current gh token."
  err "Refresh GitHub CLI auth with project scope, then rerun init:"
  err "  gh auth refresh -h github.com -s project"
  err "Current token scopes:"
  echo "$AUTH_STATUS" | sed -n '/Token scopes:/p' >&2
  exit 1
fi
echo ""

# ── step 2: repo + project ─────────────────────────────────────────────────

step "📁" "Step 2 of 5" "Repository & GitHub Project"

# Detect repo from git remote
DETECTED_REPO=$(gh repo view --json nameWithOwner --jq '.nameWithOwner' 2>/dev/null || echo '')

if [[ -n "$DETECTED_REPO" ]]; then
  info "Detected repo: $DETECTED_REPO"
  prompt "Use this repo? [Y/n]:"
  read -r USE_DETECTED
  if [[ "$USE_DETECTED" =~ ^[Nn] ]]; then
    DETECTED_REPO=""
  fi
fi

while [[ -z "$DETECTED_REPO" || ! "$DETECTED_REPO" =~ ^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$ ]]; do
  prompt "GitHub repo (owner/repo):"
  read -r DETECTED_REPO
  if [[ ! "$DETECTED_REPO" =~ ^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$ ]]; then
    err "Expected format: owner/repo (e.g. octocat/hello-world)"
    DETECTED_REPO=""
  fi
done

REPO="$DETECTED_REPO"
OWNER="${REPO%%/*}"
REPO_NAME="${REPO##*/}"

# Verify repo exists and is accessible
if ! gh repo view "$REPO" &>/dev/null; then
  err "Repo '$REPO' not found or not accessible with current gh auth."
  err "Check the name, your gh login (gh auth status), or repo visibility."
  exit 1
fi
ok "Repo: $REPO"
echo ""

# List projects linked to the repo plus user/org projects owned by the repo owner.
info "Fetching GitHub Projects for $OWNER and projects linked to $REPO..."
LINKED_PROJECTS_RAW=$(gh api graphql -f query="
{
  repository(owner: \"$OWNER\", name: \"$REPO_NAME\") {
    projectsV2(first: 50) {
      nodes { id title number }
    }
  }
}" --jq '.data.repository.projectsV2.nodes // [] | map({id,title,number,linked:true})' 2>/dev/null || echo '[]')

OWNER_PROJECTS_RAW=$(gh api graphql -F login="$OWNER" -f query='
query($login: String!) {
  user(login: $login) {
    projectsV2(first: 50) { nodes { id title number } }
  }
  organization(login: $login) {
    projectsV2(first: 50) { nodes { id title number } }
  }
}' --jq '[.data.user.projectsV2.nodes[]?, .data.organization.projectsV2.nodes[]?] | map({id,title,number,linked:false})' 2>/dev/null || echo '[]')

# Normalize + dedup + sort the linked/owner project lists via the tested node
# CLI (parsers.mjs normalizeProjectList + mergeProjectLists, @story #560).
PROJECTS_JSON=$(LINKED_PROJECTS_RAW="$LINKED_PROJECTS_RAW" OWNER_PROJECTS_RAW="$OWNER_PROJECTS_RAW" \
  node "$CONFIG_INIT_CLI" normalize-projects)
PROJECT_COUNT=$(echo "$PROJECTS_JSON" | jq 'length' 2>/dev/null || echo '0')
LINKED_PROJECT_COUNT=$(echo "$PROJECTS_JSON" | jq '[.[] | select(.linked)] | length' 2>/dev/null || echo '0')

PROJECT_NODE_ID=""
PROJECT_NUMBER=""
PROJECT_TITLE=""
EXISTING_PROJECT_LINK_PENDING="false"
CREATED_PROJECT_PENDING="false"
PROJECT_TEMPLATE=""

link_project_to_repo() {
  local project_id="$1"
  local repo_id
  repo_id=$(gh api graphql -f query="{ repository(owner: \"$OWNER\", name: \"$REPO_NAME\") { id } }" --jq '.data.repository.id' 2>/dev/null || echo '')
  if [[ -n "$repo_id" ]]; then
    gh api graphql -f query='
mutation($proj: ID!, $repo: ID!) {
  linkProjectV2ToRepository(input: { projectId: $proj, repositoryId: $repo }) {
    repository { nameWithOwner }
  }
}' -f proj="$project_id" -f repo="$repo_id" &>/dev/null && ok "Linked project to $REPO" || warn "Could not link project to repo — it may already be linked, or you can add it manually in GitHub."
  fi
}

# project_number_from_input <raw> → "<login>:<number>" or '' (no match).
# Delegates to the tested parsers.mjs projectNumberFromInput (@story #560).
project_number_from_input() {
  OWNER="$OWNER" node "$CONFIG_INIT_CLI" parse-project-input "$1" --owner "$OWNER"
}

resolve_existing_project() {
  local raw="$1"
  local parsed login number project_json
  parsed=$(project_number_from_input "$raw")
  if [[ -z "$parsed" ]]; then
    return 1
  fi
  login="${parsed%%:*}"
  number="${parsed##*:}"
  project_json=$(gh api graphql -F login="$login" -F number="$number" -f query='
query($login: String!, $number: Int!) {
  user(login: $login) {
    projectV2(number: $number) { id title number }
  }
  organization(login: $login) {
    projectV2(number: $number) { id title number }
  }
}' --jq '[.data.user.projectV2, .data.organization.projectV2] | map(select(. != null)) | first // empty' 2>/dev/null || echo '')

  if [[ -z "$project_json" || "$project_json" == "null" ]]; then
    return 1
  fi

  PROJECT_NODE_ID=$(echo "$project_json" | jq -r '.id // empty')
  PROJECT_NUMBER=$(echo "$project_json" | jq -r '.number // empty')
  PROJECT_TITLE=$(echo "$project_json" | jq -r '.title // empty')
  [[ -n "$PROJECT_NODE_ID" ]]
}

prompt_project_template() {
  local choice
  echo ""
  info "GitHub's built-in web templates are not exposed by the supported gh/API project-create command."
  info "AI Task Manager can create a compatible project shape and link it to this repo."
  echo ""
  echo "    [1] Feature Release (recommended) - Status, Priority, Size, Estimate, Actuals, Rank"
  echo "    [2] Basic Kanban - Status columns only; remaining fields are mapped/created later"
  echo ""
  while true; do
    prompt "Project workflow template [1]:"
    read -r choice
    [[ -z "$choice" ]] && choice="1"
    case "$choice" in
      1|feature|feature-release|"Feature Release") PROJECT_TEMPLATE="feature-release"; return ;;
      2|basic|kanban|"Basic Kanban") PROJECT_TEMPLATE="basic-kanban"; return ;;
    esac
    err "Enter 1 for Feature Release or 2 for Basic Kanban."
  done
}

create_project_field_if_missing() {
  local name="$1"
  local data_type="$2"
  local options_json="${3:-}"
  local existing fields_raw
  fields_raw=$(gh api graphql -f query="
{
  node(id: \"$PROJECT_NODE_ID\") {
    ... on ProjectV2 {
      fields(first: 50) {
        nodes {
          ... on ProjectV2SingleSelectField { id name options { id name } }
          ... on ProjectV2Field { id name dataType }
        }
      }
    }
  }
}" 2>/dev/null || echo '{}')
  existing=$(printf '%s\n' "$fields_raw" | jq -r --arg name "$name" \
    '[.data.node.fields.nodes[]? | select((.name | ascii_downcase) == ($name | ascii_downcase))] | first.id // empty' \
    2>/dev/null || echo '')
  if [[ -n "$existing" ]]; then
    return
  fi

  local created
  if [[ "$data_type" == "SINGLE_SELECT" ]]; then
    created=$(jq -n \
      --arg proj "$PROJECT_NODE_ID" \
      --arg name "$name" \
      --argjson opts "$options_json" \
      '{query:"mutation($proj:ID!,$name:String!,$opts:[ProjectV2SingleSelectFieldOptionInput!]!){createProjectV2Field(input:{projectId:$proj,dataType:SINGLE_SELECT,name:$name,singleSelectOptions:$opts}){projectV2Field{...on ProjectV2SingleSelectField{id}}}}",variables:{proj:$proj,name:$name,opts:$opts}}' \
      | gh api graphql --input - --jq '.data.createProjectV2Field.projectV2Field.id' 2>/dev/null || echo '')
  else
    created=$(gh api graphql \
      -f query="mutation(\$proj:ID!,\$name:String!){createProjectV2Field(input:{projectId:\$proj,dataType:${data_type},name:\$name}){projectV2Field{...on ProjectV2Field{id}}}}" \
      -f proj="$PROJECT_NODE_ID" -f name="$name" \
      --jq '.data.createProjectV2Field.projectV2Field.id' 2>/dev/null || echo '')
  fi

  [[ -n "$created" ]] && ok "Created '$name' field." || warn "Could not create '$name' field — it can be mapped or created later."
}

# ── Canonical Status palette — SINGLE SOURCE OF TRUTH (#415) ───────────────
# Every place this script declares a Status option name, color, or description
# MUST derive from this one ordered array. Three paths consume it: the fresh-
# field create path (apply_project_template), the existing-field create path
# (STATES_TO_CREATE), and the rename/recolor-on-match normalize step. Keeping a
# second hardcoded copy is the bug this constant exists to prevent — the copies
# drifted (Refine/Plan/Review/Done came out mis-colored on fresh installs) and
# matched default options ("Todo"/"In Progress") were never renamed or
# recolored at all. Verified live against the ai-task-manager board (project
# #11). GitHub single-select color enum: GRAY BLUE GREEN YELLOW ORANGE RED PINK
# PURPLE.
CANONICAL_STATUS_PALETTE='[
  {"name":"Backlog","color":"GRAY","description":"Unvetted ideas; not yet shaped."},
  {"name":"Refine","color":"GREEN","description":"Items being shaped: AC, sizing, estimates."},
  {"name":"Ready for Planning","color":"GRAY","description":"Refinement is complete; eligible for JIT planning."},
  {"name":"Plan","color":"BLUE","description":"Items being deep-dived: design + caller analysis."},
  {"name":"Develop","color":"YELLOW","description":"Implementation in progress."},
  {"name":"Test","color":"ORANGE","description":"Agent verification in progress."},
  {"name":"Review","color":"BLUE","description":"All checks passed; awaiting human approval."},
  {"name":"Done","color":"PURPLE","description":""}
]'

# canon_color <state-name> → canonical color for that state (empty if unknown).
# Delegates to the tested parsers.mjs canonColor (@story #560).
canon_color() {
  node "$CONFIG_INIT_CLI" canon-color "$1"
}

apply_project_template() {
  local template="$1"
  # Status (kanban) is the ONLY field this bootstrap provisions. Every other
  # project property — Priority, Size, Estimate, Rank, the timing fields,
  # the "Started" start-time field, Blocked By — is owned by the
  # config-driven creation loop, which sources its full schema (names, types,
  # single-select option colors + descriptions) from
  # config/project-fields.default.json. Provisioning those fields here too
  # was both stale (timing fields as NUMBER, a DATE "Start date" — pre-#398)
  # and redundant, and it caused interactive type-conflict prompts when the
  # config loop then tried to create the canonical Text fields over them.
  # See #233.
  info "Applying ${template} project workflow..."
  create_project_field_if_missing "Status" "SINGLE_SELECT" "$CANONICAL_STATUS_PALETTE"
}

create_project() {
  local title="$1"
  local template="${2:-feature-release}"
  info "Creating project '$title'..."
  PROJECT_CREATE_OUT=$(gh project create --owner "$OWNER" --title "$title" --format json 2>/dev/null || echo '')
  if [[ -z "$PROJECT_CREATE_OUT" ]]; then
    err "Failed to create project."; exit 1
  fi
  PROJECT_NUMBER=$(echo "$PROJECT_CREATE_OUT" | jq -r '.number // empty')
  ok "Created project #$PROJECT_NUMBER: $title"

  # Resolve node ID
  PROJECT_NODE_ID=$(gh api graphql -f query="{ user(login: \"$OWNER\") { projectV2(number: $PROJECT_NUMBER) { id } } }" --jq '.data.user.projectV2.id' 2>/dev/null || \
    gh api graphql -f query="{ organization(login: \"$OWNER\") { projectV2(number: $PROJECT_NUMBER) { id } } }" --jq '.data.organization.projectV2.id' 2>/dev/null || echo '')
  if [[ -z "$PROJECT_NODE_ID" ]]; then err "Could not resolve project node ID."; exit 1; fi
  ok "Project node ID: $PROJECT_NODE_ID"

  PROJECT_TEMPLATE="$template"
  CREATED_PROJECT_PENDING="true"
  echo ""
}

if [[ -n "$PROJECT_INPUT" ]]; then
  if resolve_existing_project "$PROJECT_INPUT"; then
    ok "Using existing project #$PROJECT_NUMBER: $PROJECT_TITLE"
    EXISTING_PROJECT_LINK_PENDING="true"
  else
    err "Could not resolve project from: $PROJECT_INPUT"
    err "Use a URL like https://github.com/users/kburson/projects/5 or an owner:number value like kburson:5."
    exit 1
  fi
elif [[ "$PROJECT_COUNT" == "0" ]]; then
  warn "No GitHub Projects linked to $REPO."
  echo ""
  info "A GitHub Project board is required to track Kanban state."
  echo ""
  info "You can use an existing user/org project by entering its URL or number."
  echo ""
  DEFAULT_TITLE="$REPO_NAME Board"
  prompt "Project URL, owner:number, number, or 'new' [new]:"
  read -r PROJECT_CHOICE
  [[ -z "$PROJECT_CHOICE" ]] && PROJECT_CHOICE="new"
  if [[ "$PROJECT_CHOICE" != "new" ]]; then
    if resolve_existing_project "$PROJECT_CHOICE"; then
      ok "Using existing project #$PROJECT_NUMBER: $PROJECT_TITLE"
      EXISTING_PROJECT_LINK_PENDING="true"
    else
      err "Could not resolve project from: $PROJECT_CHOICE"
      exit 1
    fi
  else
    prompt "Project title [$DEFAULT_TITLE]:"
    read -r PROJECT_TITLE
    [[ -z "$PROJECT_TITLE" ]] && PROJECT_TITLE="$DEFAULT_TITLE"
    PROJECT_TEMPLATE=""
    prompt_project_template
    create_project "$PROJECT_TITLE" "$PROJECT_TEMPLATE"
  fi
else
  if [[ "$LINKED_PROJECT_COUNT" == "0" ]]; then
    warn "No GitHub Projects are currently linked to $REPO."
    info "You can link one of the projects below or create a new repo-linked project."
  fi
  echo ""
  info "Available GitHub Projects:"
  LINKED_COUNT=$(echo "$PROJECTS_JSON" | jq '[.[] | select(.linked == true)] | length')
  UNLINKED_COUNT=$(echo "$PROJECTS_JSON" | jq '[.[] | select(.linked == false)] | length')
  if [[ "$LINKED_COUNT" -gt 0 ]]; then
    echo ""
    echo "    ── Linked Projects ──────────────────────────"
    echo "$PROJECTS_JSON" | jq -r 'to_entries[] | select(.value.linked == true) | "    [\(.key+1)] \(.value.title) (#\(.value.number))"'
  fi
  if [[ "$UNLINKED_COUNT" -gt 0 ]]; then
    echo ""
    echo "    ── Other Projects ──────────────────────────"
    echo "$PROJECTS_JSON" | jq -r 'to_entries[] | select(.value.linked == false) | "    [\(.key+1)] \(.value.title) (#\(.value.number))"'
  fi
  echo ""
  echo "    ── Manual Options ──────────────────────────"
  echo "    [url] Use an existing project URL or owner:number"
  echo "    [new] Create a new project"
  PROJECT_COUNT_DISPLAY=$(echo "$PROJECTS_JSON" | jq 'length')
  echo ""
  while true; do
    prompt "Enter list number, project URL, owner:number, or 'new' [1]:"
    read -r PROJECT_NUMBER_INPUT
    [[ -z "$PROJECT_NUMBER_INPUT" ]] && PROJECT_NUMBER_INPUT="1"
    if [[ "$PROJECT_NUMBER_INPUT" == "new" ]]; then
      DEFAULT_TITLE="$REPO_NAME Board"
      prompt "Project title [$DEFAULT_TITLE]:"
      read -r PROJECT_TITLE
      [[ -z "$PROJECT_TITLE" ]] && PROJECT_TITLE="$DEFAULT_TITLE"
      PROJECT_TEMPLATE=""
      prompt_project_template
      create_project "$PROJECT_TITLE" "$PROJECT_TEMPLATE"
      break
    elif [[ "$PROJECT_NUMBER_INPUT" =~ ^[0-9]+$ && "$PROJECT_NUMBER_INPUT" -ge 1 && "$PROJECT_NUMBER_INPUT" -le "$PROJECT_COUNT_DISPLAY" ]]; then
      idx=$((PROJECT_NUMBER_INPUT - 1))
      PROJECT_NUMBER=$(echo "$PROJECTS_JSON" | jq -r --argjson i "$idx" '.[$i].number')
      PROJECT_NODE_ID=$(echo "$PROJECTS_JSON" | jq -r --argjson i "$idx" '.[$i].id')
      PROJECT_TITLE=$(echo "$PROJECTS_JSON" | jq -r --argjson i "$idx" '.[$i].title')
      PROJECT_LINKED=$(echo "$PROJECTS_JSON" | jq -r --argjson i "$idx" '.[$i].linked')
      if [[ "$PROJECT_LINKED" != "true" ]]; then
        EXISTING_PROJECT_LINK_PENDING="true"
      fi
      break
    elif [[ "$PROJECT_NUMBER_INPUT" == "url" ]]; then
      prompt "Project URL or owner:number:"
      read -r PROJECT_URL_INPUT
      if resolve_existing_project "$PROJECT_URL_INPUT"; then
        EXISTING_PROJECT_LINK_PENDING="true"
        break
      fi
      err "Could not resolve project from: $PROJECT_URL_INPUT"
    elif resolve_existing_project "$PROJECT_NUMBER_INPUT"; then
      EXISTING_PROJECT_LINK_PENDING="true"
      break
    fi
    err "Please enter a number 1-$PROJECT_COUNT_DISPLAY, a project URL, owner:number, or 'new'."
  done
fi

ok "Using project #$PROJECT_NUMBER${PROJECT_TITLE:+: $PROJECT_TITLE}"
echo ""

if [[ -z "$PROJECT_NODE_ID" ]]; then
  err "Could not resolve project node ID for #$PROJECT_NUMBER."
  err "Ensure the project is linked to $REPO and you have access."
  exit 1
fi
ok "Project node ID: $PROJECT_NODE_ID"
echo ""

workflow_compatibility_failure() {
  err "GitHub Project workflow compatibility could not be verified."
  err "No project fields, repository links, local config, or issue templates were changed."
  exit 1
}

inspect_project_workflows() {
  local workflows_json='[]'
  local cursor=''
  local seen_cursors='[]'
  local page_count=0
  local response page_nodes has_next end_cursor inventory inspection

  info "Checking GitHub Project workflow compatibility..."
  while true; do
    page_count=$((page_count + 1))
    if [[ "$page_count" -gt 100 ]]; then
      workflow_compatibility_failure
    fi

    if [[ -n "$cursor" ]]; then
      if ! response=$(gh api graphql -F id="$PROJECT_NODE_ID" -F cursor="$cursor" -f query='
query($id: ID!, $cursor: String) {
  node(id: $id) {
    ... on ProjectV2 {
      workflows(first: 100, after: $cursor) {
        nodes { name number enabled }
        pageInfo { hasNextPage endCursor }
      }
    }
  }
}'); then
        workflow_compatibility_failure
      fi
    else
      if ! response=$(gh api graphql -F id="$PROJECT_NODE_ID" -f query='
query($id: ID!, $cursor: String) {
  node(id: $id) {
    ... on ProjectV2 {
      workflows(first: 100, after: $cursor) {
        nodes { name number enabled }
        pageInfo { hasNextPage endCursor }
      }
    }
  }
}'); then
        workflow_compatibility_failure
      fi
    fi

    if ! printf '%s\n' "$response" | jq -e '
      (.data.node.workflows.nodes | type) == "array" and
      (.data.node.workflows.pageInfo | type) == "object" and
      (.data.node.workflows.pageInfo.hasNextPage | type) == "boolean" and
      (
        .data.node.workflows.pageInfo.hasNextPage == false or
        (
          (.data.node.workflows.pageInfo.endCursor | type) == "string" and
          (.data.node.workflows.pageInfo.endCursor | length) > 0
        )
      )
    ' >/dev/null 2>&1; then
      workflow_compatibility_failure
    fi

    page_nodes=$(printf '%s\n' "$response" | jq -c '.data.node.workflows.nodes')
    workflows_json=$(jq -nc \
      --argjson prior "$workflows_json" \
      --argjson page "$page_nodes" \
      '$prior + $page')
    has_next=$(printf '%s\n' "$response" | jq -r '.data.node.workflows.pageInfo.hasNextPage')
    if [[ "$has_next" != "true" ]]; then
      break
    fi

    end_cursor=$(printf '%s\n' "$response" | jq -r '.data.node.workflows.pageInfo.endCursor // empty')
    if [[ -z "$end_cursor" ]] || printf '%s\n' "$seen_cursors" | jq -e --arg cursor "$end_cursor" 'index($cursor) != null' >/dev/null; then
      workflow_compatibility_failure
    fi
    seen_cursors=$(printf '%s\n' "$seen_cursors" | jq -c --arg cursor "$end_cursor" '. + [$cursor]')
    cursor="$end_cursor"
  done

  inventory=$(jq -nc --argjson workflows "$workflows_json" '{workflows:$workflows,complete:true}')
  if ! inspection=$(PROJECT_WORKFLOWS_RAW="$inventory" node "$CONFIG_INIT_CLI" inspect-workflows); then
    workflow_compatibility_failure
  fi

  if [[ "$(printf '%s\n' "$inspection" | jq '.incompatible | length')" -gt 0 ]]; then
    err "Project #$PROJECT_NUMBER${PROJECT_TITLE:+ ($PROJECT_TITLE)} has workflows incompatible with AITM-owned task state and closure:"
    while IFS= read -r workflow_name; do
      printf '    - %s\n' "$workflow_name" >&2
    done < <(printf '%s\n' "$inspection" | jq -r '.incompatible[].name')
    err "Disable these workflows in the selected project's Workflows settings, then rerun \`npx ai-task-manager init\`."
    err "No project fields, repository links, local config, or issue templates were changed."
    exit 1
  fi
  ok "GitHub Project workflows are compatible with AITM."
}

inspect_project_workflows

# Seed or refresh local field definitions only after the selected project's
# complete workflow inventory has passed compatibility inspection.
if [[ ! -f "$FIELD_DEFS_FILE" && -f "$PKG_ROOT/config/project-fields.default.json" ]]; then
  cp "$PKG_ROOT/config/project-fields.default.json" "$FIELD_DEFS_FILE"
fi
if [[ ! -f "$FIELD_EVENTS_FILE" && -f "$PKG_ROOT/config/project-field-events.default.json" ]]; then
  cp "$PKG_ROOT/config/project-field-events.default.json" "$FIELD_EVENTS_FILE"
fi
check_field_defs_drift "$FIELD_DEFS_FILE" "$PKG_ROOT/config/project-fields.default.json" "project-fields.json"

if [[ "$CREATED_PROJECT_PENDING" == "true" ]]; then
  link_project_to_repo "$PROJECT_NODE_ID"
  apply_project_template "$PROJECT_TEMPLATE"
fi

# ── step 3: kanban field discovery ────────────────────────────────────────

step "📊" "Step 3 of 5" "Kanban Status Field"

info "Fetching project fields..."
FIELDS_JSON=$(gh api graphql -f query="
{
  node(id: \"$PROJECT_NODE_ID\") {
    ... on ProjectV2 {
      fields(first: 30) {
        nodes {
          ... on ProjectV2SingleSelectField {
            id name options { id name color description }
          }
          ... on ProjectV2Field {
            id name
          }
        }
      }
    }
  }
}" --jq '.data.node.fields.nodes' 2>/dev/null || echo '[]')

echo ""
info "Single-select fields found:"
echo "$FIELDS_JSON" | jq -r '.[] | select(.options) | "    [\(.name)]  options: \([.options[].name] | join(", "))"'
echo ""

KANBAN_FIELD_JSON=""
while [[ -z "$KANBAN_FIELD_JSON" ]]; do
  prompt "Which field is your Kanban status field? [Status]:"
  read -r KANBAN_FIELD_NAME
  [[ -z "$KANBAN_FIELD_NAME" ]] && KANBAN_FIELD_NAME="Status"

  KANBAN_FIELD_JSON=$(echo "$FIELDS_JSON" | jq -c --arg name "$KANBAN_FIELD_NAME" \
    'first(.[] | select((.name | ascii_downcase) == ($name | ascii_downcase) and has("options"))) // empty' \
    2>/dev/null || echo '')

  if [[ -z "$KANBAN_FIELD_JSON" ]]; then
    err "Field '$KANBAN_FIELD_NAME' not found or has no options. Try again."
  fi
done

KANBAN_FIELD_ID=$(echo "$KANBAN_FIELD_JSON" | jq -r '.id')
ok "Kanban field ID: $KANBAN_FIELD_ID"
echo ""

# Show current states and explain what's needed
info "Current states in this field:"
echo "$KANBAN_FIELD_JSON" | jq -r '.options[] | "    \(.name)"'
echo ""
info "Required task-tracker states: Backlog, Refine, Ready for Planning, Plan, Develop, Test, Review, Done"
info "You can also add custom unmanaged states."
echo ""

# Renaming/reordering a historical Assigned or On Deck option is owned by the
# explicit #1217 migration. Init may preserve one unambiguous legacy option id
# as the R4P config identity, but must not rename or reorder the live field.
LEGACY_ON_DECK_OPTION_COUNT=$(echo "$KANBAN_FIELD_JSON" | jq '
  [.options[]? | select((.name | ascii_downcase) == "on deck")] | length
' 2>/dev/null || echo '0')
LEGACY_ASSIGNED_OPTION_COUNT=$(echo "$KANBAN_FIELD_JSON" | jq '
  [.options[]? | select((.name | ascii_downcase) == "assigned")] | length
' 2>/dev/null || echo '0')
CANONICAL_READY_FOR_PLAN_OPTION_COUNT=$(echo "$KANBAN_FIELD_JSON" | jq '
  [.options[]? | select((.name | ascii_downcase) == "ready for planning")] | length
' 2>/dev/null || echo '0')
LEGACY_READY_FOR_PLAN_OPTION_ID=""

if [[ "$LEGACY_ON_DECK_OPTION_COUNT" -gt 1 ]]; then
  err "Status contains duplicate 'On Deck' options; init cannot choose a stable option id."
  info "Resolve the duplicate options explicitly, then rerun init."
  exit 1
fi
if [[ "$LEGACY_ASSIGNED_OPTION_COUNT" -gt 1 ]]; then
  err "Status contains duplicate 'Assigned' options; init cannot choose a stable option id."
  info "Resolve the duplicate options explicitly, then rerun init."
  exit 1
fi
if [[ "$CANONICAL_READY_FOR_PLAN_OPTION_COUNT" -gt 1 ]]; then
  err "Status contains duplicate 'Ready for Planning' options; init cannot choose a stable option id."
  info "Resolve the duplicate options explicitly, then rerun init."
  exit 1
fi
READY_FOR_PLAN_SPELLING_COUNT=$((LEGACY_ON_DECK_OPTION_COUNT + LEGACY_ASSIGNED_OPTION_COUNT + CANONICAL_READY_FOR_PLAN_OPTION_COUNT))
if [[ "$READY_FOR_PLAN_SPELLING_COUNT" -gt 1 ]]; then
  err "Status contains multiple Ready-for-Planning spellings; init will not choose or mutate an ambiguous option."
  info "Resolve the ambiguity before running the explicit #1217 migration."
  exit 1
fi
if [[ "$LEGACY_ON_DECK_OPTION_COUNT" -gt 0 || "$LEGACY_ASSIGNED_OPTION_COUNT" -gt 0 ]]; then
  LEGACY_READY_FOR_PLAN_OPTION_ID=$(echo "$KANBAN_FIELD_JSON" | jq -r '
    first(.options[] | select(((.name | ascii_downcase) == "on deck") or ((.name | ascii_downcase) == "assigned")) | .id) // empty
  ' 2>/dev/null || echo '')
  warn "Status still uses a legacy R4P spelling; init will preserve its option id and defer live migration to #1217."
fi

# Existing projects are linked only after the selected Status field has passed
# every Assigned-spelling ambiguity check above. A duplicate or coexistence
# refusal must leave repository/project linkage unchanged.
if [[ "$EXISTING_PROJECT_LINK_PENDING" == "true" ]]; then
  link_project_to_repo "$PROJECT_NODE_ID"
fi

# Global used for inter-function return value (avoids subshell scoping issues)
PICKED_ID=""

# Try auto-match by name; if no match, show numbered list for interactive selection.
# Sets PICKED_ID to an existing option ID, "__NEW__" (needs creation), or "" (skipped).
auto_or_pick() {
  local label="$1"
  local candidates="$2"   # comma-separated auto-match names
  local optional="$3"     # "required" or "optional"

  local matched
  matched=$(echo "$KANBAN_FIELD_JSON" | jq -r --arg names "$candidates" '
    ($names | split(",") | map(ltrimstr(" ") | rtrimstr(" ") | ascii_downcase)) as $targets |
    first(.options[] | select(.name | ascii_downcase | IN($targets[])) | .id) // empty
  ' 2>/dev/null || echo '')

  if [[ -n "$matched" ]]; then
    local mname
    mname=$(echo "$KANBAN_FIELD_JSON" | jq -r --arg id "$matched" '.options[] | select(.id == $id) | .name')
    ok "Auto-matched '$label' → '$mname'"
    PICKED_ID="$matched"
    return
  fi

  echo ""
  info "State '$label' ($optional) — no match found:"
  echo "$KANBAN_FIELD_JSON" | jq -r '.options | to_entries[] | "    [\(.key+1)] \(.value.name)"'
  echo "    [new] Create '$label' as a new option"
  [[ "$optional" == "optional" ]] && echo "    [skip] Don't use this state"
  echo ""

  local count
  count=$(echo "$KANBAN_FIELD_JSON" | jq '.options | length')

  while true; do
    prompt "Choice for '$label' [new]:"
    read -r choice
    [[ -z "$choice" ]] && choice="new"
    if [[ "$optional" == "optional" && "$choice" == "skip" ]]; then
      PICKED_ID=""; return
    elif [[ "$choice" == "new" ]]; then
      PICKED_ID="__NEW__"; return
    elif [[ "$choice" =~ ^[0-9]+$ && "$choice" -ge 1 && "$choice" -le "$count" ]]; then
      PICKED_ID=$(echo "$KANBAN_FIELD_JSON" | jq -r --argjson i "$((choice-1))" '.options[$i].id')
      local pname
      pname=$(echo "$KANBAN_FIELD_JSON" | jq -r --argjson i "$((choice-1))" '.options[$i].name')
      ok "Mapped '$label' → '$pname'"
      return
    fi
    local skip_hint=""
    [[ "$optional" == "optional" ]] && skip_hint=", or 'skip'"
    err "Enter a number 1-$count, 'new'${skip_hint}."
  done
}

# Auto-pick alias lists below are board-column-NAME candidates, not vocabulary.
# Each canonical state ("Refine", "Plan", "Develop", "Test", "Review") accepts a
# fallback list of column names a consumer's GitHub Project might still use from
# before the 2026-05 rename. Keep these aliases so init works against older
# boards; the canonical Scrum vocab is the first entry of each list.
# Backlog only auto-matches "backlog" — not "todo" (that belongs to Refine).
auto_or_pick "Backlog" "backlog"                                              "required"; OPTION_BACKLOG="$PICKED_ID"
auto_or_pick "Refine"  "refine,groom,grooming,refined,ready,todo,to do"       "required"; OPTION_REFINE="$PICKED_ID"
if [[ -n "$LEGACY_READY_FOR_PLAN_OPTION_ID" ]]; then
  OPTION_READY_FOR_PLAN="$LEGACY_READY_FOR_PLAN_OPTION_ID"
  ok "Mapped canonical config key kanbanOptionReadyForPlan to legacy option id '$OPTION_READY_FOR_PLAN'."
else
  auto_or_pick "Ready for Planning" "ready for planning,ready-for-planning,r4p" "required"; OPTION_READY_FOR_PLAN="$PICKED_ID"
fi
auto_or_pick "Plan"    "plan,analyze,analysis"                                "required"; OPTION_PLAN="$PICKED_ID"
auto_or_pick "Develop" "develop,development,in progress,in-progress,doing,wip" "required"; OPTION_DEVELOP="$PICKED_ID"
auto_or_pick "Test"    "test,validate,verify,in review,in-review,reviewing"   "required"; OPTION_TEST="$PICKED_ID"
auto_or_pick "Review"  "review,r4r,ready for release,ready-for-release"       "required"; OPTION_REVIEW="$PICKED_ID"
auto_or_pick "Done"    "done,closed,complete,completed"                       "required"; OPTION_DONE="$PICKED_ID"


# Build list of options that need to be created. Colors come from the single
# canonical palette (#415) so this list cannot drift from the fresh-field path.
STATES_TO_CREATE=()
[[ "$OPTION_BACKLOG" == "__NEW__" ]] && STATES_TO_CREATE+=("Backlog:$(canon_color Backlog)")
[[ "$OPTION_REFINE"  == "__NEW__" ]] && STATES_TO_CREATE+=("Refine:$(canon_color Refine)")
[[ "$OPTION_READY_FOR_PLAN" == "__NEW__" ]] && STATES_TO_CREATE+=("Ready for Planning:$(canon_color "Ready for Planning")")
[[ "$OPTION_PLAN"    == "__NEW__" ]] && STATES_TO_CREATE+=("Plan:$(canon_color Plan)")
[[ "$OPTION_DEVELOP" == "__NEW__" ]] && STATES_TO_CREATE+=("Develop:$(canon_color Develop)")
[[ "$OPTION_TEST"    == "__NEW__" ]] && STATES_TO_CREATE+=("Test:$(canon_color Test)")
[[ "$OPTION_REVIEW"  == "__NEW__" ]] && STATES_TO_CREATE+=("Review:$(canon_color Review)")
[[ "$OPTION_DONE"    == "__NEW__" ]] && STATES_TO_CREATE+=("Done:$(canon_color Done)")

# If any new options needed, append them via updateProjectV2Field
if [[ ${#STATES_TO_CREATE[@]} -gt 0 ]]; then
  echo ""
  local_names=()
  for s in "${STATES_TO_CREATE[@]}"; do local_names+=("${s%%:*}"); done
  info "Adding new states: $(IFS=', '; echo "${local_names[*]}")"

  # Existing options with their IDs (preserved) + new options (no id = created)
  EXISTING_OPTS_JSON=$(echo "$KANBAN_FIELD_JSON" | jq '[.options[] | {id, name, color, description}]')
  NEW_STATES_STR="$(IFS='|'; echo "${STATES_TO_CREATE[*]}")"
  NEW_OPTS_JSON=$(echo "$NEW_STATES_STR" | jq -R '
    split("|") | map(split(":") | {name: .[0], color: .[1], description: ""})
  ')
  ALL_OPTS_JSON=$(echo "$EXISTING_OPTS_JSON" "$NEW_OPTS_JSON" | jq -s 'add')

  MUTATION_OK=$(jq -n \
    --arg field "$KANBAN_FIELD_ID" \
    --argjson opts "$ALL_OPTS_JSON" \
    '{query:"mutation($field:ID!,$opts:[ProjectV2SingleSelectFieldOptionInput!]!){updateProjectV2Field(input:{fieldId:$field,singleSelectOptions:$opts}){projectV2Field{...on ProjectV2SingleSelectField{id}}}}",variables:{field:$field,opts:$opts}}' \
    | gh api graphql --input - --jq '.data.updateProjectV2Field.projectV2Field.id' 2>/dev/null || echo '')

  if [[ -z "$MUTATION_OK" ]]; then
    err "Failed to add new states. Check that you have 'write' access to the GitHub Project."
    exit 1
  fi

  ok "New states added."

  # Re-fetch the field to get fresh option IDs
  _REFETCH_RAW=$(gh api graphql -f query="
{
  node(id: \"$PROJECT_NODE_ID\") {
    ... on ProjectV2 {
      fields(first: 30) {
        nodes {
          ... on ProjectV2SingleSelectField { id name options { id name color description } }
        }
      }
    }
  }
}" 2>/dev/null || echo '{}')
  KANBAN_FIELD_JSON=$(echo "$_REFETCH_RAW" | jq --arg fid "$KANBAN_FIELD_ID" '
    (if type == "array" then . else (.data.node.fields.nodes // []) end)
    | map(select(.id == $fid)) | first // empty
  ' 2>/dev/null || echo '')

  # Resolve __NEW__ sentinels to actual option IDs from updated field
  remap_state() {
    echo "$KANBAN_FIELD_JSON" | jq -r --arg n "$1" '.options[] | select(.name == $n) | .id'
  }
  [[ "$OPTION_BACKLOG" == "__NEW__" ]] && OPTION_BACKLOG=$(remap_state "Backlog")
  [[ "$OPTION_REFINE"  == "__NEW__" ]] && OPTION_REFINE=$(remap_state "Refine")
  [[ "$OPTION_READY_FOR_PLAN" == "__NEW__" ]] && OPTION_READY_FOR_PLAN=$(remap_state "Ready for Planning")
  [[ "$OPTION_PLAN"    == "__NEW__" ]] && OPTION_PLAN=$(remap_state "Plan")
  [[ "$OPTION_DEVELOP" == "__NEW__" ]] && OPTION_DEVELOP=$(remap_state "Develop")
  [[ "$OPTION_TEST"    == "__NEW__" ]] && OPTION_TEST=$(remap_state "Test")
  [[ "$OPTION_REVIEW"  == "__NEW__" ]] && OPTION_REVIEW=$(remap_state "Review")
  [[ "$OPTION_DONE"    == "__NEW__" ]] && OPTION_DONE=$(remap_state "Done")
fi

# ── Normalize the 8 managed options to the canonical palette (#415) ────────
# A single updateProjectV2Field rewrite that, for each of the 8 managed states,
# forces the canonical name + color + description while PRESERVING the matched
# option's id (so items already sitting in that column are not orphaned). This
# is what renames GitHub's default "Todo"→"Refine" / "In Progress"→"Develop"
# and recolors any mismatched option. The 8 managed options are placed in
# canonical order; any unmanaged custom columns are preserved as-is and
# appended after, so this runs safely regardless of how many columns exist
# (the old logic only ran when exactly 8 existed, leaving renames undone on
# boards with extra columns).

if [[ -n "$LEGACY_READY_FOR_PLAN_OPTION_ID" ]]; then
  warn "Skipping Status palette normalization until the explicit #1217 R4P migration runs."
elif [[ -z "$OPTION_BACKLOG" || -z "$OPTION_REFINE" || -z "$OPTION_READY_FOR_PLAN" || -z "$OPTION_PLAN" || \
      -z "$OPTION_DEVELOP" || -z "$OPTION_TEST" || -z "$OPTION_REVIEW" || -z "$OPTION_DONE" ]]; then
  warn "One or more managed Status options did not resolve to an id — skipping palette normalization. Set names/colors manually in the GitHub Project board."
else
  info "Normalizing Status columns to canonical names + colors: Backlog → Refine → Ready for Planning → Plan → Develop → Test → Review → Done"
  NORMALIZED_OPTS=$(echo "$KANBAN_FIELD_JSON" | jq -c \
    --argjson canon "$CANONICAL_STATUS_PALETTE" \
    --arg b   "$OPTION_BACKLOG" \
    --arg rf  "$OPTION_REFINE" \
    --arg r4p "$OPTION_READY_FOR_PLAN" \
    --arg pl  "$OPTION_PLAN" \
    --arg dev "$OPTION_DEVELOP" \
    --arg t   "$OPTION_TEST" \
    --arg rv  "$OPTION_REVIEW" \
    --arg d   "$OPTION_DONE" \
    '
    [{name:"Backlog",id:$b},{name:"Refine",id:$rf},{name:"Ready for Planning",id:$r4p},{name:"Plan",id:$pl},
     {name:"Develop",id:$dev},{name:"Test",id:$t},{name:"Review",id:$rv},
     {name:"Done",id:$d}] as $managed |
    ($managed | map(.id)) as $managedIds |
    ($managed | map(. as $m | ($canon[] | select(.name == $m.name)) as $c |
       {id:$m.id, name:$c.name, color:$c.color, description:$c.description})) as $managedOpts |
    (.options | map(select((.id as $oid | $managedIds | index($oid)) | not))
              | map({id, name, color, description})) as $extraOpts |
    $managedOpts + $extraOpts' \
    2>/dev/null || echo '')

  if [[ -n "$NORMALIZED_OPTS" && "$NORMALIZED_OPTS" != "null" ]]; then
    NORMALIZE_OK=$(jq -n \
      --arg field "$KANBAN_FIELD_ID" \
      --argjson opts "$NORMALIZED_OPTS" \
      '{query:"mutation($field:ID!,$opts:[ProjectV2SingleSelectFieldOptionInput!]!){updateProjectV2Field(input:{fieldId:$field,singleSelectOptions:$opts}){projectV2Field{...on ProjectV2SingleSelectField{id}}}}",variables:{field:$field,opts:$opts}}' \
      | gh api graphql --input - --jq '.data.updateProjectV2Field.projectV2Field.id' 2>/dev/null || echo '')
    if [[ -n "$NORMALIZE_OK" ]]; then
      ok "Status names, colors, and order normalized to canonical palette."
      info "WIP limits cannot be set via API — set them manually in the GitHub Project board:"
      info "  Develop: 3   |   Test: 5   |   Review: 10"
    else
      warn "Could not normalize Status columns — set names/colors/order manually in the GitHub Project board."
    fi
  fi
fi
echo ""

# ── verify a Board view exists (view config is not writable via API) ──────

BOARD_VIEW_NAME=$(gh api graphql -f query="
{
  node(id: \"$PROJECT_NODE_ID\") {
    ... on ProjectV2 {
      views(first: 20) { nodes { name layout } }
    }
  }
}" --jq '[.data.node.views.nodes[] | select(.layout == "BOARD_LAYOUT")][0].name' 2>/dev/null || echo '')

if [[ -n "$BOARD_VIEW_NAME" && "$BOARD_VIEW_NAME" != "null" ]]; then
  ok "Board view exists: '$BOARD_VIEW_NAME' (Review column visible once Status options are populated)."
else
  warn "No Board-layout view found on this project."
  info "GitHub Projects v2 does not expose view configuration via API. Create one manually:"
  info "  1. Open the project in the GitHub web UI"
  info "  2. Click 'New view' → choose 'Board' layout"
  info "  3. Group by 'Status'"
  info "  4. Confirm columns: Backlog → Refine → Ready for Planning → Plan → Develop → Test → Review → Done"
fi
echo ""

# ── step 4: project management fields ─────────────────────────────────────

step "⚙️ " "Step 4 of 5" "Project Management Fields"
info "For each field: if a matching field exists it will be used automatically."
info "Otherwise you can map to an existing field or create a new one (default)."
echo ""

# Re-fetch with dataType so we can identify number vs text fields.
FIELDS_JSON=$(gh api graphql -f query="
{
  node(id: \"$PROJECT_NODE_ID\") {
    ... on ProjectV2 {
      fields(first: 50) {
        nodes {
          ... on ProjectV2SingleSelectField { id name options { id name } }
          ... on ProjectV2Field { id name dataType }
          ... on ProjectV2IterationField { id name }
        }
      }
    }
  }
}" --jq '.data.node.fields.nodes' 2>/dev/null || echo '[]')

refresh_fields() {
  FIELDS_JSON=$(gh api graphql -f query="
{
  node(id: \"$PROJECT_NODE_ID\") {
    ... on ProjectV2 {
      fields(first: 50) {
        nodes {
          ... on ProjectV2SingleSelectField { id name options { id name } }
          ... on ProjectV2Field { id name dataType }
          ... on ProjectV2IterationField { id name }
        }
      }
    }
  }
}" --jq '.data.node.fields.nodes' 2>/dev/null || echo '[]')
}

# Return values (globals — avoids subshell scoping)
RESULT_FIELD_ID=""
RESULT_FIELD_JSON=""

# map_or_create_select <field-name> <options-json>
# Auto-matches by exact name; otherwise prompts to map existing or create new.
# Sets RESULT_FIELD_ID and RESULT_FIELD_JSON.
map_or_create_select() {
  local fname="$1"
  local create_opts_json="$2"
  local aliases_json="${3:-[]}"

  # Check by name first (any type) to detect conflicts before the type-filtered lookup
  local name_match name_match_type
  name_match=$(echo "$FIELDS_JSON" | jq -c --arg n "$fname" --argjson aliases "$aliases_json" \
    '([$n] + $aliases | map(ascii_downcase)) as $names |
     first(.[] | select((.name | ascii_downcase) as $fieldName | ($names | index($fieldName) != null))) // empty' \
    2>/dev/null || echo '')
  name_match_type=$(echo "$name_match" | jq -r 'if has("options") then "SINGLE_SELECT" elif .dataType then .dataType else "" end' 2>/dev/null || echo '')

  if [[ -n "$name_match" && "$name_match_type" == "SINGLE_SELECT" ]]; then
    ok "Found field '$fname'."
    RESULT_FIELD_ID=$(echo "$name_match" | jq -r '.id')
    RESULT_FIELD_JSON="$name_match"
    return
  fi

  local create_name="$fname"

  if [[ -n "$name_match" ]]; then
    echo ""
    err "Field '$fname' exists on this project but is type ${name_match_type:-unknown}, not SINGLE_SELECT."
    info "You must choose a different name for a new single-select field."
    while true; do
      prompt "New field name for '$fname' (SINGLE_SELECT):"; read -r create_name
      [[ -z "$create_name" ]] && { err "Name required."; continue; }
      local alt_match
      alt_match=$(echo "$FIELDS_JSON" | jq -c --arg n "$create_name" \
        'first(.[] | select((.name | ascii_downcase) == ($n | ascii_downcase))) // empty' \
        2>/dev/null || echo '')
      if [[ -n "$alt_match" ]]; then
        local alt_type
        alt_type=$(echo "$alt_match" | jq -r 'if has("options") then "SINGLE_SELECT" elif .dataType then .dataType else "" end')
        if [[ "$alt_type" == "SINGLE_SELECT" ]]; then
          ok "Using existing field '$create_name'."
          RESULT_FIELD_ID=$(echo "$alt_match" | jq -r '.id')
          RESULT_FIELD_JSON="$alt_match"
          return
        fi
        err "Field '$create_name' also exists as type ${alt_type}. Choose a different name."
        continue
      fi
      break
    done
  fi

  if [[ -z "$name_match" ]]; then
    echo ""
    info "Field '$fname' not found on project."
    local select_fields count
    select_fields=$(echo "$FIELDS_JSON" | jq '[.[] | select(has("options"))]')
    count=$(echo "$select_fields" | jq 'length')
    if [[ "$count" -gt 0 ]]; then
      echo "$select_fields" | jq -r 'to_entries[] | "    [\(.key+1)] \(.value.name)"'
    fi
    echo "    [new] Create '$fname' with standard options (default)"
    echo ""

    while true; do
      prompt "Choice for '$fname' [new]:"
      read -r choice
      [[ -z "$choice" ]] && choice="new"
      if [[ "$choice" == "new" ]]; then
        break
      elif [[ "$choice" =~ ^[0-9]+$ && "$choice" -ge 1 && "$choice" -le "$count" ]]; then
        local picked pname
        picked=$(echo "$select_fields" | jq -c --argjson i "$((choice-1))" '.[$i]')
        pname=$(echo "$picked" | jq -r '.name')
        RESULT_FIELD_ID=$(echo "$picked" | jq -r '.id')
        RESULT_FIELD_JSON="$picked"
        ok "Mapped '$fname' → '$pname'"
        return
      fi
      err "Enter a number 1-$count or 'new'."
    done
  fi

  local new_id
  new_id=$(jq -n \
    --arg proj "$PROJECT_NODE_ID" \
    --arg name "$create_name" \
    --argjson opts "$create_opts_json" \
    '{query:"mutation($proj:ID!,$name:String!,$opts:[ProjectV2SingleSelectFieldOptionInput!]!){createProjectV2Field(input:{projectId:$proj,dataType:SINGLE_SELECT,name:$name,singleSelectOptions:$opts}){projectV2Field{...on ProjectV2SingleSelectField{id}}}}",variables:{proj:$proj,name:$name,opts:$opts}}' \
    | gh api graphql --input - --jq '.data.createProjectV2Field.projectV2Field.id' 2>/dev/null || echo '')
  if [[ -n "$new_id" ]]; then
    ok "Created '$create_name' field."
    refresh_fields
    RESULT_FIELD_ID="$new_id"
    RESULT_FIELD_JSON=$(echo "$FIELDS_JSON" | jq -c --arg id "$new_id" \
      'first(.[] | select(.id == $id)) // empty')
  else
    warn "Could not create '$create_name'. Add it manually to your GitHub Project."
    RESULT_FIELD_ID=""
    RESULT_FIELD_JSON=""
  fi
}

# map_or_create_number <field-name>
# Auto-matches by exact name; otherwise prompts to map existing number field or create new.
# Sets RESULT_FIELD_ID.
map_or_create_number() {
  local fname="$1"
  local aliases_json="${2:-[]}"

  local name_match name_match_type
  name_match=$(echo "$FIELDS_JSON" | jq -c --arg n "$fname" --argjson aliases "$aliases_json" \
    '([$n] + $aliases | map(ascii_downcase)) as $names |
     first(.[] | select((.name | ascii_downcase) as $fieldName | ($names | index($fieldName) != null))) // empty' \
    2>/dev/null || echo '')
  name_match_type=$(echo "$name_match" | jq -r 'if has("options") then "SINGLE_SELECT" elif .dataType then .dataType else "" end' 2>/dev/null || echo '')

  if [[ -n "$name_match" && ( "$name_match_type" == "NUMBER" || -z "$name_match_type" ) ]]; then
    ok "Found field '$fname'."
    RESULT_FIELD_ID=$(echo "$name_match" | jq -r '.id')
    return
  fi

  local create_name="$fname"

  if [[ -n "$name_match" ]]; then
    echo ""
    err "Field '$fname' exists on this project but is type ${name_match_type:-unknown}, not NUMBER."
    info "You must choose a different name for a new number field."
    while true; do
      prompt "New field name for '$fname' (NUMBER):"; read -r create_name
      [[ -z "$create_name" ]] && { err "Name required."; continue; }
      local alt_match
      alt_match=$(echo "$FIELDS_JSON" | jq -c --arg n "$create_name" \
        'first(.[] | select((.name | ascii_downcase) == ($n | ascii_downcase))) // empty' \
        2>/dev/null || echo '')
      if [[ -n "$alt_match" ]]; then
        local alt_type
        alt_type=$(echo "$alt_match" | jq -r 'if has("options") then "SINGLE_SELECT" elif .dataType then .dataType else "" end')
        if [[ "$alt_type" == "NUMBER" || -z "$alt_type" ]]; then
          ok "Using existing field '$create_name'."
          RESULT_FIELD_ID=$(echo "$alt_match" | jq -r '.id')
          return
        fi
        err "Field '$create_name' also exists as type ${alt_type}. Choose a different name."
        continue
      fi
      break
    done
  fi

  if [[ -z "$name_match" ]]; then
    echo ""
    info "Field '$fname' not found on project."
    local num_fields count
    num_fields=$(echo "$FIELDS_JSON" | jq '[.[] | select(.dataType == "NUMBER")]')
    count=$(echo "$num_fields" | jq 'length')
    if [[ "$count" -gt 0 ]]; then
      echo "$num_fields" | jq -r 'to_entries[] | "    [\(.key+1)] \(.value.name)"'
    fi
    echo "    [new] Create '$fname' number field (default)"
    echo ""

    while true; do
      prompt "Choice for '$fname' [new]:"
      read -r choice
      [[ -z "$choice" ]] && choice="new"
      if [[ "$choice" == "new" ]]; then
        break
      elif [[ "$choice" =~ ^[0-9]+$ && "$choice" -ge 1 && "$choice" -le "$count" ]]; then
        RESULT_FIELD_ID=$(echo "$num_fields" | jq -r --argjson i "$((choice-1))" '.[$i].id')
        local pname
        pname=$(echo "$num_fields" | jq -r --argjson i "$((choice-1))" '.[$i].name')
        ok "Mapped '$fname' → '$pname'"
        return
      fi
      err "Enter a number 1-$count or 'new'."
    done
  fi

  local new_id
  new_id=$(gh api graphql -f query='
mutation($proj:ID!,$name:String!){
  createProjectV2Field(input:{projectId:$proj,dataType:NUMBER,name:$name}){
    projectV2Field{...on ProjectV2Field{id}}
  }
}' -f proj="$PROJECT_NODE_ID" -f name="$create_name" \
    --jq '.data.createProjectV2Field.projectV2Field.id' 2>/dev/null || echo '')
  if [[ -n "$new_id" ]]; then
    ok "Created '$create_name' field."
    refresh_fields
    RESULT_FIELD_ID="$new_id"
  else
    warn "Could not create '$create_name'. Add it manually to your GitHub Project."
    RESULT_FIELD_ID=""
  fi
}

map_or_create_date() {
  local fname="$1"
  local aliases_json="${2:-[]}"

  local name_match name_match_type
  name_match=$(echo "$FIELDS_JSON" | jq -c --arg n "$fname" --argjson aliases "$aliases_json" \
    '([$n] + $aliases | map(ascii_downcase)) as $names |
     first(.[] | select((.name | ascii_downcase) as $fieldName | ($names | index($fieldName) != null))) // empty' \
    2>/dev/null || echo '')
  name_match_type=$(echo "$name_match" | jq -r 'if has("options") then "SINGLE_SELECT" elif .dataType then .dataType else "" end' 2>/dev/null || echo '')

  if [[ -n "$name_match" && ( "$name_match_type" == "DATE" || -z "$name_match_type" ) ]]; then
    ok "Found field '$fname'."
    RESULT_FIELD_ID=$(echo "$name_match" | jq -r '.id')
    return
  fi

  local create_name="$fname"

  if [[ -n "$name_match" ]]; then
    echo ""
    err "Field '$fname' exists on this project but is type ${name_match_type:-unknown}, not DATE."
    info "You must choose a different name for a new date field."
    while true; do
      prompt "New field name for '$fname' (DATE):"; read -r create_name
      [[ -z "$create_name" ]] && { err "Name required."; continue; }
      local alt_match
      alt_match=$(echo "$FIELDS_JSON" | jq -c --arg n "$create_name" \
        'first(.[] | select((.name | ascii_downcase) == ($n | ascii_downcase))) // empty' \
        2>/dev/null || echo '')
      if [[ -n "$alt_match" ]]; then
        local alt_type
        alt_type=$(echo "$alt_match" | jq -r 'if has("options") then "SINGLE_SELECT" elif .dataType then .dataType else "" end')
        if [[ "$alt_type" == "DATE" || -z "$alt_type" ]]; then
          ok "Using existing field '$create_name'."
          RESULT_FIELD_ID=$(echo "$alt_match" | jq -r '.id')
          return
        fi
        err "Field '$create_name' also exists as type ${alt_type}. Choose a different name."
        continue
      fi
      break
    done
  fi

  if [[ -z "$name_match" ]]; then
    echo ""
    info "Field '$fname' not found on project."
    local date_fields count
    date_fields=$(echo "$FIELDS_JSON" | jq '[.[] | select(.dataType == "DATE")]')
    count=$(echo "$date_fields" | jq 'length')
    if [[ "$count" -gt 0 ]]; then
      echo "$date_fields" | jq -r 'to_entries[] | "    [\(.key+1)] \(.value.name)"'
    fi
    echo "    [new] Create '$fname' date field (default)"
    echo ""

    while true; do
      prompt "Choice for '$fname' [new]:"
      read -r choice
      [[ -z "$choice" ]] && choice="new"
      if [[ "$choice" == "new" ]]; then
        break
      elif [[ "$choice" =~ ^[0-9]+$ && "$choice" -ge 1 && "$choice" -le "$count" ]]; then
        RESULT_FIELD_ID=$(echo "$date_fields" | jq -r --argjson i "$((choice-1))" '.[$i].id')
        local pname
        pname=$(echo "$date_fields" | jq -r --argjson i "$((choice-1))" '.[$i].name')
        ok "Mapped '$fname' → '$pname'"
        return
      fi
      err "Enter a number 1-$count or 'new'."
    done
  fi

  local new_id
  new_id=$(gh api graphql -f query='
mutation($proj:ID!,$name:String!){
  createProjectV2Field(input:{projectId:$proj,dataType:DATE,name:$name}){
    projectV2Field{...on ProjectV2Field{id}}
  }
}' -f proj="$PROJECT_NODE_ID" -f name="$create_name" \
    --jq '.data.createProjectV2Field.projectV2Field.id' 2>/dev/null || echo '')
  if [[ -n "$new_id" ]]; then
    ok "Created '$create_name' field."
    refresh_fields
    RESULT_FIELD_ID="$new_id"
  else
    warn "Could not create '$create_name'. Add it manually to your GitHub Project."
    RESULT_FIELD_ID=""
  fi
}

map_or_create_text() {
  local fname="$1"
  local aliases_json="${2:-[]}"

  local name_match name_match_type
  name_match=$(echo "$FIELDS_JSON" | jq -c --arg n "$fname" --argjson aliases "$aliases_json" \
    '([$n] + $aliases | map(ascii_downcase)) as $names |
     first(.[] | select((.name | ascii_downcase) as $fieldName | ($names | index($fieldName) != null))) // empty' \
    2>/dev/null || echo '')
  name_match_type=$(echo "$name_match" | jq -r 'if has("options") then "SINGLE_SELECT" elif .dataType then .dataType else "" end' 2>/dev/null || echo '')

  if [[ -n "$name_match" && ( "$name_match_type" == "TEXT" || -z "$name_match_type" ) ]]; then
    ok "Found field '$fname'."
    RESULT_FIELD_ID=$(echo "$name_match" | jq -r '.id')
    return
  fi

  local create_name="$fname"
  if [[ -n "$name_match" ]]; then
    echo ""
    err "Field '$fname' exists on this project but is type ${name_match_type:-unknown}, not TEXT."
    info "You must choose a different name for a new text field."
    while true; do
      prompt "New field name for '$fname' (TEXT):"; read -r create_name
      [[ -z "$create_name" ]] && { err "Name required."; continue; }
      local alt_match
      alt_match=$(echo "$FIELDS_JSON" | jq -c --arg n "$create_name" \
        'first(.[] | select((.name | ascii_downcase) == ($n | ascii_downcase))) // empty' \
        2>/dev/null || echo '')
      if [[ -n "$alt_match" ]]; then
        local alt_type
        alt_type=$(echo "$alt_match" | jq -r 'if has("options") then "SINGLE_SELECT" elif .dataType then .dataType else "" end')
        if [[ "$alt_type" == "TEXT" || -z "$alt_type" ]]; then
          ok "Using existing field '$create_name'."
          RESULT_FIELD_ID=$(echo "$alt_match" | jq -r '.id')
          return
        fi
        err "Field '$create_name' also exists as type ${alt_type}. Choose a different name."
        continue
      fi
      break
    done
  fi

  local new_id
  new_id=$(gh api graphql -f query='
mutation($proj:ID!,$name:String!){
  createProjectV2Field(input:{projectId:$proj,dataType:TEXT,name:$name}){
    projectV2Field{...on ProjectV2Field{id}}
  }
}' -f proj="$PROJECT_NODE_ID" -f name="$create_name" \
    --jq '.data.createProjectV2Field.projectV2Field.id' 2>/dev/null || echo '')
  if [[ -n "$new_id" ]]; then
    ok "Created '$create_name' field."
    refresh_fields
    RESULT_FIELD_ID="$new_id"
  else
    warn "Could not create '$create_name'. Add it manually to your GitHub Project."
    RESULT_FIELD_ID=""
  fi
}

# ── Custom fields from definitions ─────────────────────────────────────────

info "Custom fields from .ai-task-manager/project-fields.json..."
echo ""
FIELD_IDS_JSON="{}"
PRIORITY_FIELD_ID="" OPTION_P0="" OPTION_P1="" OPTION_P2="" OPTION_P3=""
SIZE_FIELD_ID=""
FIELD_ESTIMATE=""
FIELD_ENGAGED_TIME=""
FIELD_SESSION_TIME=""
FIELD_RANK=""
FIELD_START_TIME=""
FIELD_BLOCKED_BY=""
FIELD_DISPOSITION=""

set_field_id_json() {
  FIELD_IDS_JSON=$(printf '%s\n' "$FIELD_IDS_JSON" | jq -c --arg key "$1" --arg val "$2" '. + {($key): $val}')
}

while IFS= read -r FIELD_DEF <&3; do
  FIELD_KEY=$(echo "$FIELD_DEF" | jq -r '.key')
  FIELD_NAME=$(echo "$FIELD_DEF" | jq -r '.name')
  FIELD_TYPE=$(echo "$FIELD_DEF" | jq -r '.type')
  FIELD_ALIASES=$(echo "$FIELD_DEF" | jq -c '.aliases // []')
  RESULT_FIELD_ID=""
  RESULT_FIELD_JSON=""
  case "$FIELD_TYPE" in
    single_select)
      FIELD_OPTIONS=$(echo "$FIELD_DEF" | jq -c '.options // []')
      info "$FIELD_NAME (single-select)..."
      map_or_create_select "$FIELD_NAME" "$FIELD_OPTIONS" "$FIELD_ALIASES"
      ;;
    number)
      info "$FIELD_NAME (number)..."
      map_or_create_number "$FIELD_NAME" "$FIELD_ALIASES"
      ;;
    date)
      info "$FIELD_NAME (date)..."
      map_or_create_date "$FIELD_NAME" "$FIELD_ALIASES"
      ;;
    text)
      info "$FIELD_NAME (text)..."
      map_or_create_text "$FIELD_NAME" "$FIELD_ALIASES"
      ;;
    *)
      warn "Skipping unsupported field type '$FIELD_TYPE' for '$FIELD_NAME'."
      ;;
  esac

  if [[ -n "$RESULT_FIELD_ID" ]]; then
    set_field_id_json "$FIELD_KEY" "$RESULT_FIELD_ID"
    case "$FIELD_KEY" in
      priority)
        PRIORITY_FIELD_ID="$RESULT_FIELD_ID"
        if [[ -n "$RESULT_FIELD_JSON" ]]; then
          KANBAN_FIELD_JSON="$RESULT_FIELD_JSON"
          auto_or_pick "P0 (critical)" "p0,critical,urgent"   "optional"; OPTION_P0="$PICKED_ID"
          auto_or_pick "P1 (high)"     "p1,high,important"    "optional"; OPTION_P1="$PICKED_ID"
          auto_or_pick "P2 (normal)"   "p2,normal,medium,low" "optional"; OPTION_P2="$PICKED_ID"
          auto_or_pick "P3 (chore)"    "p3,chore"             "optional"; OPTION_P3="$PICKED_ID"

          # P0/P1/P2 are GitHub's default Priority options, so they always
          # auto-match above. P3 ("Chore") is NOT a GitHub default — on an
          # existing Priority field it is absent and auto_or_pick returns the
          # __NEW__ sentinel. Create-and-append it (preserving the existing
          # options with their ids so items already set are not orphaned), then
          # re-fetch the field and remap to the real id. Mirrors the Status
          # STATES_TO_CREATE path (#404).
          if [[ "$OPTION_P3" == "__NEW__" ]]; then
            info "Adding new priority option: P3 (Chore)"
            EXISTING_PRI_OPTS=$(echo "$KANBAN_FIELD_JSON" | jq '[.options[] | {id, name, color, description}]')
            ALL_PRI_OPTS=$(echo "$EXISTING_PRI_OPTS" | jq '. + [{name:"P3", color:"GRAY", description:"Chore"}]')
            PRI_MUT_OK=$(jq -n \
              --arg field "$PRIORITY_FIELD_ID" \
              --argjson opts "$ALL_PRI_OPTS" \
              '{query:"mutation($field:ID!,$opts:[ProjectV2SingleSelectFieldOptionInput!]!){updateProjectV2Field(input:{fieldId:$field,singleSelectOptions:$opts}){projectV2Field{...on ProjectV2SingleSelectField{id}}}}",variables:{field:$field,opts:$opts}}' \
              | gh api graphql --input - --jq '.data.updateProjectV2Field.projectV2Field.id' 2>/dev/null || echo '')
            if [[ -z "$PRI_MUT_OK" ]]; then
              warn "Failed to add P3 priority option — set it manually in the GitHub Project (name 'P3', color GRAY, description 'Chore')."
              OPTION_P3=""
            else
              _PRI_REFETCH=$(gh api graphql -f query="
{
  node(id: \"$PROJECT_NODE_ID\") {
    ... on ProjectV2 {
      fields(first: 30) {
        nodes {
          ... on ProjectV2SingleSelectField { id name options { id name color description } }
        }
      }
    }
  }
}" 2>/dev/null || echo '{}')
              KANBAN_FIELD_JSON=$(echo "$_PRI_REFETCH" | jq --arg fid "$PRIORITY_FIELD_ID" '
                (if type == "array" then . else (.data.node.fields.nodes // []) end)
                | map(select(.id == $fid)) | first // empty
              ' 2>/dev/null || echo '')
              OPTION_P3=$(echo "$KANBAN_FIELD_JSON" | jq -r '.options[] | select(.name == "P3") | .id')
              ok "Priority option P3 (Chore) added."
            fi
          fi

          KANBAN_FIELD_JSON=""
        fi
        ;;
      size) SIZE_FIELD_ID="$RESULT_FIELD_ID" ;;
      estimate) FIELD_ESTIMATE="$RESULT_FIELD_ID" ;;
      engagedTime) FIELD_ENGAGED_TIME="$RESULT_FIELD_ID" ;;
      sessionTime) FIELD_SESSION_TIME="$RESULT_FIELD_ID" ;;
      rank) FIELD_RANK="$RESULT_FIELD_ID" ;;
      startTime) FIELD_START_TIME="$RESULT_FIELD_ID" ;;
      blockedBy) FIELD_BLOCKED_BY="$RESULT_FIELD_ID" ;;
      disposition) FIELD_DISPOSITION="$RESULT_FIELD_ID" ;;
      reviewTime) FIELD_REVIEW_TIME="$RESULT_FIELD_ID" ;;
      planTime) FIELD_PLAN_TIME="$RESULT_FIELD_ID" ;;
    esac
  fi
  echo ""
done 3< <(jq -c '.[]' "$FIELD_DEFS_FILE")
echo ""

# ── step 5: write config + issue templates ─────────────────────────────────

step "💾" "Step 5 of 5" "Writing Config & Issue Templates"

# Write .ai-task-manager/task-tracker.json — merge with existing config
CONFIG_FILE="$CONFIG_FILE" \
REPO="$REPO" \
PROJECT_NODE_ID="$PROJECT_NODE_ID" \
KANBAN_FIELD_ID="$KANBAN_FIELD_ID" \
OPTION_BACKLOG="$OPTION_BACKLOG" \
OPTION_REFINE="$OPTION_REFINE" \
OPTION_READY_FOR_PLAN="$OPTION_READY_FOR_PLAN" \
OPTION_PLAN="$OPTION_PLAN" \
OPTION_DEVELOP="$OPTION_DEVELOP" \
OPTION_TEST="$OPTION_TEST" \
OPTION_REVIEW="$OPTION_REVIEW" \
OPTION_DONE="$OPTION_DONE" \
PRIORITY_FIELD_ID="$PRIORITY_FIELD_ID" \
OPTION_P0="$OPTION_P0" \
OPTION_P1="$OPTION_P1" \
OPTION_P2="$OPTION_P2" \
OPTION_P3="$OPTION_P3" \
SIZE_FIELD_ID="$SIZE_FIELD_ID" \
FIELD_ESTIMATE="$FIELD_ESTIMATE" \
FIELD_ENGAGED_TIME="$FIELD_ENGAGED_TIME" \
FIELD_SESSION_TIME="$FIELD_SESSION_TIME" \
FIELD_RANK="$FIELD_RANK" \
FIELD_START_TIME="$FIELD_START_TIME" \
FIELD_BLOCKED_BY="$FIELD_BLOCKED_BY" \
FIELD_DISPOSITION="$FIELD_DISPOSITION" \
FIELD_REVIEW_TIME="$FIELD_REVIEW_TIME" \
FIELD_PLAN_TIME="$FIELD_PLAN_TIME" \
FIELD_IDS_JSON="$FIELD_IDS_JSON" \
node "$CONFIG_INIT_CLI" write-config --file "$CONFIG_FILE"
ok "Config written: $CONFIG_FILE"
echo ""

# Write GitHub issue templates (task.yml + bug.yml, content owned by the node CLI)
TEMPLATE_DIR="$TARGET_DIR/.github/ISSUE_TEMPLATE"
node "$CONFIG_INIT_CLI" write-templates --target "$TARGET_DIR"
ok "Issue templates written: $TEMPLATE_DIR/"
echo ""

# ── done ───────────────────────────────────────────────────────────────────

success_banner "Setup complete!"
ok "Config           $(dim "$CONFIG_FILE")"
ok "Issue templates  $(dim "$TEMPLATE_DIR/")"
echo ""
divider
echo ""
printf "  \033[1m🚀 Next steps\033[0m\n"
echo ""
printf "    \033[32m1.\033[0m Commit the issue templates \033[2m(config is gitignored)\033[0m:\n"
printf "       \033[36mgit add .github/ISSUE_TEMPLATE/\033[0m\n"
printf "       \033[36mgit commit -m 'chore: add ai-task-manager issue templates'\033[0m\n"
echo ""
printf "    \033[32m2.\033[0m Start Claude Code and type: \033[35m/task #<issue-number>\033[0m\n"
echo ""
divider
echo ""
printf "  \033[36m🔹\033[0m To reconfigure at any time, run: \033[36mnpx ai-task-manager init\033[0m\n"
echo ""
