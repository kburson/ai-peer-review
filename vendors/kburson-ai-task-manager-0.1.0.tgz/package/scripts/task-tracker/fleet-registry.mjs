import {
  existsSync,
  readFileSync,
  writeFileSync,
  mkdirSync,
  renameSync,
  rmdirSync,
  statSync,
} from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { legacyPathFor, fleetPath } from './paths.mjs';
import { GIT_TIMEOUT_MS } from './lib/process-timeouts.mjs';

const LOCK_STALE_MS = 30_000;
const LOCK_RETRY_MS = 25;
const LOCK_MAX_WAIT_MS = 5_000;

export function withLock(registryPath, fn) {
  const lockDir = registryPath + '.lock';
  mkdirSync(path.dirname(registryPath), { recursive: true });
  const deadline = Date.now() + LOCK_MAX_WAIT_MS;
  let held = false;
  while (!held) {
    try {
      mkdirSync(lockDir);
      held = true;
    } catch (err) {
      if (err.code !== 'EEXIST') throw err;
      try {
        const age = Date.now() - statSync(lockDir).mtimeMs;
        if (age > LOCK_STALE_MS) {
          try {
            rmdirSync(lockDir);
          } catch {
            /* best-effort: cleanup; failure is non-fatal */
          }
          continue;
        }
      } catch {
        /* best-effort: cleanup; failure is non-fatal */
      }
      if (Date.now() > deadline) throw new Error(`fleet-registry: lock timeout on ${lockDir}`);
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, LOCK_RETRY_MS);
    }
  }
  try {
    return fn();
  } finally {
    try {
      rmdirSync(lockDir);
    } catch {
      /* best-effort: cleanup; failure is non-fatal */
    }
  }
}

export function findMainWorktreePath(projectDir) {
  try {
    const out = execFileSync('git', ['worktree', 'list', '--porcelain'], {
      cwd: projectDir,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: GIT_TIMEOUT_MS,
    });
    const firstBlock = out.split(/\n\n/)[0];
    const match = firstBlock.match(/^worktree (.+)$/m);
    if (match) return match[1].trim();
  } catch {
    /* best-effort: failure must not abort the primary operation */
  }
  return projectDir;
}

export function fleetRegistryPath(mainWorktreePath) {
  return fleetPath(mainWorktreePath);
}

export function currentBranch(projectDir) {
  try {
    return execFileSync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], {
      cwd: projectDir,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: GIT_TIMEOUT_MS,
    }).trim();
  } catch {
    return 'unknown';
  }
}

// #441 — default 24h staleness horizon for active entries. Exported so callers
// (fleet prune, guard-time reap) and tests share one constant.
export const STALE_MS_DEFAULT = 24 * 60 * 60 * 1000;

// #441 — discriminate a main-thread bind from a worktree sub-agent bind. The
// robust test is "is this worktreePath the main worktree?", which stays correct
// whether the caller runs on the main thread or inside a sub-agent's worktree.
export function classifyBindKind(projectDir, worktreePath) {
  return worktreePath === findMainWorktreePath(projectDir) ? 'main' : 'worktree';
}

// #441 — effective kind for any entry: honor a stored `kind`, else infer from
// path (legacy/migration entries lacking the tag). When mainWorktreePath is
// unknown, inference is skipped and anything untagged is treated as a worktree.
export function effectiveKind(entry, mainWorktreePath) {
  if (entry?.kind === 'main' || entry?.kind === 'worktree') return entry.kind;
  if (mainWorktreePath && entry?.worktreePath === mainWorktreePath) return 'main';
  return 'worktree';
}

// #441 — pure, injectable staleness predicate. Evicts when: the entry is
// malformed; a `main`-kind bind that is not the currently-active issue; a
// worktree whose directory no longer exists; or an active worktree older than
// the staleness horizon. Clock + fs are injected via ctx so it unit-tests
// without touching the real clock or disk.
export function isStaleEntry(ref, entry, ctx = {}) {
  if (!entry || typeof entry !== 'object') return true;
  const {
    nowMs = Date.now(),
    staleMs = STALE_MS_DEFAULT,
    activeRef,
    mainWorktreePath,
    dirExists = existsSync,
  } = ctx;
  const kind = effectiveKind(entry, mainWorktreePath);
  if (kind === 'main') {
    // A live main bind is owned by the main-thread state. A *paused* main bind
    // is intentional (the user paused and will resume) — keep it. Only an
    // `active` main bind that is not the currently-active issue is leaked
    // garbage (the #405@trunk-class entry).
    if (entry.status !== 'active') return false;
    return ref !== activeRef;
  }
  // worktree kind
  if (typeof entry.worktreePath !== 'string' || !entry.worktreePath) return true;
  if (!dirExists(entry.worktreePath)) return true;
  if (entry.status === 'active') {
    const started = Date.parse(entry.startedAt);
    if (!Number.isNaN(started) && nowMs - started > staleMs) return true;
  }
  return false;
}

// #441 — pure partition of a fleet into kept vs evicted refs.
export function reapStaleEntries(fleet, ctx = {}) {
  const kept = {};
  const evicted = [];
  for (const [ref, entry] of Object.entries(fleet || {})) {
    if (isStaleEntry(ref, entry, ctx)) evicted.push(ref);
    else kept[ref] = entry;
  }
  return { kept, evicted };
}

export function readFleet(registryPath, opts) {
  let fleet;
  try {
    let readPath = registryPath;
    if (!existsSync(readPath)) {
      const legacy = legacyPathFor(registryPath);
      if (legacy && existsSync(legacy)) readPath = legacy;
    }
    fleet = !existsSync(readPath) ? {} : JSON.parse(readFileSync(readPath, 'utf8'));
  } catch {
    fleet = {};
  }
  // #441 — opt-in lazy auto-reap. Default (one-arg) call stays pure: no lock,
  // no write — every hot path is unaffected. With opts.reap we compute the
  // stale set and only take the lock + rewrite when at least one entry is
  // stale, so a clean registry costs one extra in-memory scan and nothing more.
  if (!opts?.reap) return fleet;
  const ctx = { staleMs: STALE_MS_DEFAULT, dirExists: existsSync, ...(opts.reapCtx || {}) };
  const { kept, evicted } = reapStaleEntries(fleet, ctx);
  if (evicted.length === 0) return fleet;
  withLock(registryPath, () => {
    const fresh = readFleet(registryPath);
    const recomputed = reapStaleEntries(fresh, ctx);
    writeFleet(registryPath, recomputed.kept);
  });
  return kept;
}

// #1085 — fleet data is an explicitly observational local view. Consumers may
// render it for diagnostics, but this tagged snapshot cannot satisfy an
// authority, assignment, lifecycle, evidence, or integration gate.
export function fleetObservation(fleet = {}) {
  const entries = Object.entries(fleet || {})
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([ref, entry]) =>
      Object.freeze({
        ref,
        branch: typeof entry?.branch === 'string' ? entry.branch : null,
        kind: effectiveKind(entry),
        startedAt: typeof entry?.startedAt === 'string' ? entry.startedAt : null,
        status: typeof entry?.status === 'string' ? entry.status : null,
        worktreePath: typeof entry?.worktreePath === 'string' ? entry.worktreePath : null,
      })
    );
  return Object.freeze({
    schema: 'aitm.fleet-observation/v1',
    authoritative: false,
    entries: Object.freeze(entries),
  });
}

// #441 — operator-facing prune. Shares isStaleEntry with the guard-time reap so
// `fleet prune` and lazy auto-reap never diverge. dryRun computes without
// writing; otherwise evicts under lock and returns the plan either way.
export function pruneFleet(registryPath, ctx = {}, { dryRun = false } = {}) {
  const fullCtx = { staleMs: STALE_MS_DEFAULT, dirExists: existsSync, ...ctx };
  const fleet = readFleet(registryPath);
  const { kept, evicted } = reapStaleEntries(fleet, fullCtx);
  if (!dryRun && evicted.length > 0) {
    withLock(registryPath, () => {
      const fresh = readFleet(registryPath);
      const recomputed = reapStaleEntries(fresh, fullCtx);
      writeFleet(registryPath, recomputed.kept);
    });
  }
  return { kept, evicted };
}

export function writeFleet(registryPath, data) {
  mkdirSync(path.dirname(registryPath), { recursive: true });
  const tmp = registryPath + '.tmp';
  writeFileSync(tmp, JSON.stringify(data, null, 2) + '\n', 'utf8');
  renameSync(tmp, registryPath);
}

function testRmwDelay() {
  const ms = Number(process.env.FLEET_REGISTRY_TEST_DELAY_MS || 0);
  if (ms > 0) Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

export function registerTask(projectDir, issueRef, worktreePath, branch, kind) {
  const mainPath = findMainWorktreePath(projectDir);
  const rPath = fleetRegistryPath(mainPath);
  // #441 — derive kind when the caller omits it (back-compat): a bind whose
  // worktreePath is the main worktree is a `main` bind, everything else is a
  // `worktree` sub-agent bind. An explicit kind arg always wins.
  const effKind = kind ?? (worktreePath === mainPath ? 'main' : 'worktree');
  withLock(rPath, () => {
    const fleet = readFleet(rPath);
    testRmwDelay();
    const existing = fleet[issueRef];
    fleet[issueRef] = {
      worktreePath,
      branch,
      kind: effKind,
      startedAt: existing?.startedAt ?? new Date().toISOString(),
      status: 'active',
    };
    writeFleet(rPath, fleet);
  });
}

export function deregisterTask(projectDir, issueRef) {
  const mainPath = findMainWorktreePath(projectDir);
  const rPath = fleetRegistryPath(mainPath);
  withLock(rPath, () => {
    const fleet = readFleet(rPath);
    testRmwDelay();
    delete fleet[issueRef];
    writeFleet(rPath, fleet);
  });
}

export function setTaskStatus(projectDir, issueRef, status) {
  const mainPath = findMainWorktreePath(projectDir);
  const rPath = fleetRegistryPath(mainPath);
  withLock(rPath, () => {
    const fleet = readFleet(rPath);
    testRmwDelay();
    if (!fleet[issueRef]) return;
    fleet[issueRef].status = status;
    writeFleet(rPath, fleet);
  });
}
