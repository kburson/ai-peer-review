// @story #939
// Review-stage, re-entrant delivery-intent orchestration.

import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

import { gql, splitRepo } from '../../gh/lib/github-projects.mjs';
import { loadState } from '../state.mjs';
import { currentSessionId, aiAppName, jsonlPath } from '../word-counter.mjs';
import { getProvider } from '../../providers/index.mjs';
import { fetchParentIssueStrict } from '../lib/fetch-parent-issue.mjs';
import { GH_API_TIMEOUT_MS, GIT_TIMEOUT_MS } from '../lib/process-timeouts.mjs';
import { isAgentReviewComplete } from '../lib/agent-review/review-gate.mjs';
import { parseReviewApprovedMarker, parseTestStartedMarker } from '../lib/markers.mjs';
import { parseVerificationReceipt } from '../lib/verification-receipt.mjs';
import { createRecordId } from '../lib/github-records/record-envelope.mjs';
import { canonicalRecordJson } from '../lib/github-records/canonical-json.mjs';
import { createDeliveryWaiverJournal } from '../lib/delivery-waiver-journal.mjs';
import { runDeliveryWaiverTransaction } from '../lib/delivery-waiver-transaction.mjs';
import { DeliveryVerificationError } from '../lib/delivery-verification.mjs';
import { normalizeGitHubInstant } from '../lib/github-records/github-comment-store.mjs';
import { resolveGate, resolveReviewAuthorization } from '../lib/gate-resolve.mjs';
import {
  evaluateManualCodeReview,
  resolveManualCodeReviewer as resolveManualCodeReviewerPolicy,
} from '../lib/manual-code-review.mjs';
import { locateAuthoritySource } from '../lib/github-records/authority-locator.mjs';
import {
  hasAcceptedApprovalEvidence,
  hasAcceptedReviewEvidence,
  resolveLifecycleGateEvidence,
} from '../lib/github-records/lifecycle-gate-source.mjs';
import { loadSession } from '../lib/session-store.mjs';
import { rawProjectConfig } from '../config.mjs';
import {
  authorizedIntentBytes,
  buildDeliveryIntent,
  buildDeliveryReceipt,
  parseDeliveryComment,
  parseDeliveryCommentForPullRequest,
  projectDeliveryRecords,
  renderDeliveryIntentComment,
  renderDeliveryReceiptComment,
} from '../lib/delivery-records.mjs';
import {
  canonicalSourceInventory,
  verifyLocalSourceInventory,
} from '../lib/delivery-attribution-exception.mjs';
import {
  parseDeliveryAttributionExceptionComment,
  resolveActiveDeliveryAttributionException,
} from '../lib/delivery-attribution-exception-record.mjs';
import { verifyDeliveryAttributionRecordAuthority } from './delivery-attribution-exception.mjs';
import {
  resolveLiveDeliveryReviewAuthority,
  validateDeliveryPreflight,
  validateHistoricalReconstructionPreflight,
  validateHistoricalRecoveryPreflight,
  validateMergedDeliveryPreflight,
  validateNoCommitDeliveryPreflight,
} from '../lib/delivery-preflight.mjs';
import {
  DeliveryAuthorityError,
  resolveAcceptedDeliveryAuthority,
} from '../lib/delivery-authority.mjs';
import {
  buildProviderAction,
  serializeProviderActionRequired,
} from '../lib/delivery-provider-action.mjs';
import {
  verifyDeliveredPullRequest,
  verifyExternalDeliveredPullRequest,
  observeMergeMethod,
} from '../lib/delivery-verification.mjs';
import { attributingCommits as defaultAttributingCommits } from '../lib/commit-attribution.mjs';
import {
  isIssueResidentDeliveryKind,
  parseDeliverablePosted,
  parseIssueKind,
} from '../lib/issue-kind.mjs';
import {
  buildNoCommitDeliveryRecord,
  parseNoCommitDeliveryComment,
  projectNoCommitDeliveryRecords,
  renderNoCommitDeliveryComment,
  sameNoCommitDeliveryAuthority,
} from '../lib/no-commit-delivery-record.mjs';
import { selectEvidenceProtocol } from '../lib/evidence-v2/protocol.mjs';
import {
  buildMethodReconciliation,
  METHOD_RECONCILIATION_V2_SCHEMA,
  parseMethodReconciliationComment,
  renderMethodReconciliationComment,
  resolveReconciledMergeMethod,
} from '../lib/delivery-method-reconciliation.mjs';

const pexec = promisify(execFile);
const SHA_RE = /^[0-9a-f]{40}$/;
const MAX_PULL_REQUEST_SOURCE_COMMITS = 10_000;

function deliverError(category, cause) {
  return new TypeError(`deliver:${category}`, cause === undefined ? undefined : { cause });
}

function issueTarget(rest = []) {
  for (const token of rest) {
    const match = String(token).match(/^#?([1-9][0-9]*)$/);
    if (match) return Number(match[1]);
  }
  return null;
}

// @story #1562 — argument surface for the merge-method reconciliation lane.
//
// Both parts are mandatory together: the flag without a reason leaves the ledger
// unable to say WHY a divergence was accepted, and a reason without the flag
// would be silently discarded. Repeats refuse rather than resolving to one, so a
// mistyped invocation never quietly reconciles to something the operator did not
// intend.
const RECONCILE_MERGE_METHODS = new Set(['merge', 'squash', 'rebase']);
const RECONCILE_PLACEHOLDER_RE = /^(?:tbd|todo|placeholder|n\/a|none|\.\.\.)$/i;
const RECONCILE_MIN_REASON = 8;

function singleFlagValue(rest, flag, category) {
  const values = [];
  for (let i = 0; i < rest.length; i += 1) {
    const token = String(rest[i]);
    if (token === flag) {
      const next = rest[i + 1];
      if (next === undefined || String(next).startsWith('--')) throw deliverError(category);
      values.push(String(next));
      i += 1;
      continue;
    }
    if (token.startsWith(`${flag}=`)) values.push(token.slice(flag.length + 1));
  }
  if (values.length > 1) throw deliverError(category);
  return values.length === 1 ? values[0] : null;
}

export function parseReconcileArgs(rest = []) {
  const declaredMergeMethod = singleFlagValue(
    rest,
    '--reconcile-merge-method',
    'reconcile-merge-method'
  );
  const reason = singleFlagValue(rest, '--reason', 'reason');
  if (declaredMergeMethod === null) {
    if (reason !== null) throw deliverError('reason');
    return null;
  }
  if (!RECONCILE_MERGE_METHODS.has(declaredMergeMethod)) {
    throw deliverError('reconcile-merge-method');
  }
  const trimmed = (reason ?? '').trim();
  if (trimmed.length < RECONCILE_MIN_REASON || RECONCILE_PLACEHOLDER_RE.test(trimmed)) {
    throw deliverError('reconcile-reason');
  }
  return { declaredMergeMethod, reason: trimmed };
}

function baseRefFrom(cfg) {
  const value = String(cfg?.trunkRef || '');
  return value.split('/').at(-1) || '';
}

function bindingFromState({ branch, state }) {
  const active = Number(String(state?.active || '').replace(/^#/, ''));
  return {
    issueNumber: Number.isSafeInteger(active) && active > 0 ? active : 0,
    branch,
    timerState: state?.entryStartTs ? 'running' : 'paused',
  };
}

function isStructurallyInspectableSourceCommits(pullRequest) {
  const subjects = pullRequest?.sourceCommitSubjects;
  const commits = pullRequest?.sourceCommits;
  return (
    Array.isArray(subjects) &&
    Array.isArray(commits) &&
    commits.length > 0 &&
    subjects.length === commits.length &&
    pullRequest.sourceCommitsHeadSha === pullRequest.headRefOid &&
    commits.at(-1)?.oid === pullRequest.headRefOid &&
    commits.every((commit, index) => {
      if (commit === null || typeof commit !== 'object' || Array.isArray(commit)) return false;
      const keys = Object.keys(commit).sort();
      return (
        keys.length === 2 &&
        keys[0] === 'messageHeadline' &&
        keys[1] === 'oid' &&
        SHA_RE.test(commit.oid) &&
        commit.messageHeadline === subjects[index]
      );
    })
  );
}

function isUnattributedMergeCandidate(subject) {
  return typeof subject === 'string' && !subject.includes('[') && !subject.includes('#');
}

function matchesInspectedCommitTitle(observed, inspected) {
  if (observed === inspected) return true;
  if (typeof observed !== 'string' || typeof inspected !== 'string' || !observed.endsWith('…')) {
    return false;
  }
  const prefix = observed.slice(0, -1);
  return prefix.length >= 64 && inspected.length > prefix.length && inspected.startsWith(prefix);
}

export async function classifySourceCommitSubjects(pullRequest, inspectSourceCommit) {
  const strictSubjects = pullRequest?.sourceCommitSubjects;
  if (!Array.isArray(strictSubjects)) {
    return {
      attributableSubjects: strictSubjects,
      attributableCommits: null,
      verifiedMergeTitles: [],
      verifiedMergeShas: [],
    };
  }
  if (pullRequest?.sourceCommitsComplete !== true) {
    return {
      attributableSubjects: null,
      attributableCommits: null,
      verifiedMergeTitles: [],
      verifiedMergeShas: [],
    };
  }
  if (!isStructurallyInspectableSourceCommits(pullRequest)) {
    return {
      attributableSubjects: null,
      attributableCommits: null,
      verifiedMergeTitles: [],
      verifiedMergeShas: [],
    };
  }
  if (!strictSubjects.some(isUnattributedMergeCandidate)) {
    return {
      attributableSubjects: strictSubjects,
      attributableCommits: pullRequest.sourceCommits,
      verifiedMergeTitles: [],
      verifiedMergeShas: [],
    };
  }

  const attributableSubjects = [];
  const attributableCommits = [];
  const verifiedMergeTitles = [];
  const verifiedMergeShas = [];
  for (const commit of pullRequest.sourceCommits) {
    if (!isUnattributedMergeCandidate(commit.messageHeadline)) {
      attributableSubjects.push(commit.messageHeadline);
      attributableCommits.push(commit);
      continue;
    }
    let inspection = null;
    try {
      inspection = await inspectSourceCommit({ commitSha: commit.oid });
    } catch {
      // Preserve the subject so the existing attribution parser fails closed.
    }
    const parents = inspection?.parents;
    const verifiedMerge =
      matchesInspectedCommitTitle(commit.messageHeadline, inspection?.commitTitle) &&
      Array.isArray(parents) &&
      parents.length >= 2 &&
      parents.every((parent) => SHA_RE.test(parent)) &&
      new Set(parents).size === parents.length;
    if (verifiedMerge) {
      verifiedMergeTitles.push(inspection.commitTitle);
      verifiedMergeShas.push(commit.oid);
    } else {
      attributableSubjects.push(commit.messageHeadline);
      attributableCommits.push(commit);
    }
  }
  return { attributableSubjects, attributableCommits, verifiedMergeTitles, verifiedMergeShas };
}

export async function mergedSourceCommitSubjects(pullRequest, inspectSourceCommit) {
  return (await classifySourceCommitSubjects(pullRequest, inspectSourceCommit))
    .attributableSubjects;
}

export async function openSourceCommitSubjects(localSubjects, pullRequest, inspectSourceCommit) {
  if (!Array.isArray(localSubjects)) return localSubjects;
  const { verifiedMergeTitles } = await classifySourceCommitSubjects(
    pullRequest,
    inspectSourceCommit
  );
  const remaining = new Map();
  for (const title of verifiedMergeTitles) {
    remaining.set(title, (remaining.get(title) ?? 0) + 1);
  }
  return localSubjects.filter((subject) => {
    const count = remaining.get(subject) ?? 0;
    if (count === 0) return true;
    remaining.set(subject, count - 1);
    return false;
  });
}

function validateLineageResult(lineage) {
  const parent = lineage?.parentIssueNumber;
  if (
    lineage === null ||
    typeof lineage !== 'object' ||
    Array.isArray(lineage) ||
    !Object.hasOwn(lineage, 'parentIssueNumber') ||
    !Object.hasOwn(lineage, 'deliveryTarget') ||
    (parent !== null && (!Number.isSafeInteger(parent) || parent <= 0)) ||
    typeof lineage.deliveryTarget !== 'string' ||
    lineage.deliveryTarget.length === 0
  ) {
    throw deliverError('lineage');
  }
  return lineage;
}

export function parsedDeliveryRecords(comments, context) {
  if (!Array.isArray(comments)) throw deliverError('comments');
  return comments
    .map(({ id, body, createdAt }) =>
      parseDeliveryCommentForPullRequest({ id, body, createdAt }, context)
    )
    .filter((record) => record !== null);
}

async function resolveOpenAttributionException({ comments, now, deps }) {
  const candidates = comments.filter(
    ({ body }) =>
      typeof body === 'string' &&
      (body.startsWith('### Delivery attribution exception') ||
        body.includes('aitm-delivery-attribution-exception/'))
  );
  if (candidates.length === 0) return null;
  const active = resolveActiveDeliveryAttributionException(comments, undefined, now);
  const runtime = { resolveTranscriptPath: requiredDependency(deps, 'resolveTranscriptPath') };
  const scopeKeys = [
    'operationId',
    'repository',
    'issueNumber',
    'prNumber',
    'baseRef',
    'headRef',
    'headSha',
    'sourceDigest',
  ];
  for (const comment of candidates) {
    const record = parseDeliveryAttributionExceptionComment(comment);
    if (scopeKeys.some((key) => record.proposal[key] !== active.proposal[key])) {
      throw deliverError('attribution-exception-chain-scope');
    }
    await verifyDeliveryAttributionRecordAuthority(record, runtime);
  }
  return active;
}

async function classifiedOpenInventory(pullRequest, deps, localHeadSha) {
  const classified = await classifySourceCommitSubjects(
    pullRequest,
    requiredDependency(deps, 'inspectSourceCommit')
  );
  const inventory = canonicalSourceInventory(pullRequest.sourceCommits, localHeadSha);
  await verifyLocalSourceInventory({
    commits: inventory.commits,
    headSha: localHeadSha,
    inspectLocalCommit: requiredDependency(deps, 'inspectLocalSourceCommit'),
  });
  return {
    commits: inventory.commits,
    attributableSubjects: classified.attributableSubjects,
    attributableCommits: classified.attributableCommits,
    verifiedMergeShas: classified.verifiedMergeShas,
  };
}

function matchingReconstruction(comments, expected) {
  const records = comments
    .map(parseMethodReconciliationComment)
    .filter((record) => record?.schema === METHOD_RECONCILIATION_V2_SCHEMA);
  if (records.length === 0) return null;
  const keys = [
    'issueNumber',
    'repository',
    'prNumber',
    'acceptedSha',
    'mergeCommitSha',
    'configuredMergeMethod',
    'observedMergeMethod',
    'reason',
    'intentOrigin',
  ];
  if (records.length !== 1 || keys.some((key) => records[0][key] !== expected[key])) {
    throw deliverError('historical-reconstruction-provenance');
  }
  return records[0];
}

function buildIntentFromPreflight({
  preflight,
  cfg,
  intentId,
  supersedesIntentId,
  provider,
  sessionId,
  clientCreatedAt,
  commitTitle = preflight.commitText.commitTitle,
  commitMessage = preflight.commitText.commitMessage,
}) {
  return buildDeliveryIntent({
    intentId,
    supersedesIntentId,
    issueNumber: preflight.issue.number,
    repository: cfg.repo,
    prNumber: preflight.pr.number,
    baseRef: preflight.pr.baseRefName,
    headRef: preflight.pr.headRefName,
    expectedHeadSha: preflight.expectedHeadSha,
    mergeMethod: preflight.mergeMethod,
    attributionTokens: preflight.commitText.attributionTokens,
    commitTitle,
    commitMessage,
    provider,
    sessionId,
    clientCreatedAt,
    ...(preflight.exceptionDisposition ?? {}),
  });
}

function buildExternalIntentInput({
  preflight,
  cfg,
  intentId,
  sessionId,
  clientCreatedAt,
  mergeMethodOverride = null,
}) {
  return {
    intentId,
    supersedesIntentId: null,
    issueNumber: preflight.issue.number,
    repository: cfg.repo,
    prNumber: preflight.pr.number,
    baseRef: preflight.pr.baseRefName,
    headRef: preflight.pr.headRefName,
    expectedHeadSha: preflight.expectedHeadSha,
    // #1562 — the reconciliation lane restates the intent to the OBSERVED method
    // after proving observation agrees with the operator's declaration. Absent
    // the lane this is the configured method exactly as before.
    mergeMethod: mergeMethodOverride ?? preflight.mergeMethod,
    attributionTokens: preflight.commitText.attributionTokens,
    provider: 'external',
    sessionId,
    clientCreatedAt,
  };
}

async function readProjection({ deps, issueNumber, context }) {
  const comments = await deps.listIssueComments({
    issueNumber,
    repository: context.repository,
  });
  const records = parsedDeliveryRecords(comments, context);
  return { comments, projection: projectDeliveryRecords(records) };
}

function exactReadback(comments, intent, body) {
  return comments.some((comment) => {
    if (comment?.body !== body) return false;
    const parsed = parseDeliveryComment(
      { id: comment.id, body: comment.body, createdAt: comment.createdAt },
      {
        repository: intent.repository,
        issueNumber: intent.issueNumber,
        prNumber: intent.prNumber,
      }
    );
    return parsed?.record?.intentId === intent.intentId;
  });
}

function exactReceiptReadback(comments, receipt, body) {
  return comments.some((comment) => {
    if (comment?.body !== body) return false;
    const parsed = parseDeliveryComment(
      { id: comment.id, body: comment.body, createdAt: comment.createdAt },
      {
        repository: receipt.repository,
        issueNumber: receipt.record.issueNumber,
        prNumber: receipt.record.prNumber,
      }
    );
    return parsed?.record?.intentId === receipt.record.intentId;
  });
}

function pullRequestMerged(pullRequest) {
  return (
    pullRequest?.merged === true || String(pullRequest?.state || '').toUpperCase() === 'MERGED'
  );
}

async function appendIntent({ deps, issueNumber, repository, context, intent }) {
  const body = renderDeliveryIntentComment(intent);
  let createError = null;
  try {
    await requiredDependency(deps, 'createIssueComment')({ issueNumber, repository, body });
  } catch (error) {
    createError = error;
  }
  const readback = await readProjection({ deps, issueNumber, context });
  if (
    readback.projection.liveIntent?.record.intentId !== intent.intentId ||
    !exactReadback(readback.comments, intent, body)
  ) {
    if (createError !== null) throw deliverError('comment-create-ambiguous', createError);
    throw deliverError('comment-readback');
  }
  if (
    authorizedIntentBytes(readback.projection.liveIntent.record) !== authorizedIntentBytes(intent)
  ) {
    throw deliverError('intent-divergence');
  }
  return readback.projection.liveIntent;
}

async function verifyAndFinalize({
  deps,
  issueNumber,
  repository,
  context,
  liveIntent,
  matchingReceipt,
  pullRequest,
  recovery,
  mode,
  acceptedSha,
  localHeadSha,
  testReceiptSha,
  acceptedReviewSha,
  verified,
  metadataWarnings = [],
  beforeReceiptWrite = null,
}) {
  const waived = liveIntent?.record.schema === 'aitm.delivery-intent/v2';
  let verifiedPullRequest = pullRequest;
  let waivedEvidence;
  if (waived) {
    verifiedPullRequest = await requiredDependency(
      deps,
      'fetchPullRequest'
    )({
      repository,
      prNumber: liveIntent.record.prNumber,
    });
    if (!pullRequestMerged(verifiedPullRequest)) throw deliverError('post-merge-pr');
    const freshComments = await readProjection({ deps, issueNumber, context });
    if (
      freshComments.projection.liveIntent?.record.intentId !== liveIntent.record.intentId ||
      authorizedIntentBytes(freshComments.projection.liveIntent.record) !==
        authorizedIntentBytes(liveIntent.record)
    )
      throw deliverError('post-merge-intent');
    const exceptionRecord = await resolveOpenAttributionException({
      comments: freshComments.comments,
      now: requiredDependency(deps, 'now')(),
      deps,
    });
    if (exceptionRecord === null) throw deliverError('post-merge-exception');
    const sourceInventory = await classifiedOpenInventory(
      verifiedPullRequest,
      deps,
      liveIntent.record.expectedHeadSha
    );
    waivedEvidence = {
      exceptionRecord,
      sourceInventory: {
        commits: sourceInventory.commits,
        attributableCommits: sourceInventory.attributableCommits,
        verifiedMergeShas: sourceInventory.verifiedMergeShas,
      },
    };
  }
  const verification =
    verified ??
    (await verifyDeliveredPullRequest({
      acceptedSha,
      intent: liveIntent.record,
      intentCreatedAt: liveIntent.createdAt,
      pullRequest: verifiedPullRequest,
      recovery,
      localHeadSha,
      testReceiptSha,
      acceptedReviewSha,
      fetchOriginTrunk: requiredDependency(deps, 'fetchOriginTrunk'),
      isAncestor: requiredDependency(deps, 'isAncestor'),
      inspectMergeCommit: requiredDependency(deps, 'inspectMergeCommit'),
      attributingCommits: requiredDependency(deps, 'attributingCommits'),
      ...(liveIntent.record.schema === 'aitm.delivery-intent/v1' &&
      (matchingReceipt === null || matchingReceipt.record.schema === 'aitm.delivery-receipt/v5') &&
      typeof deps.compareDeliveryContent === 'function' &&
      typeof deps.resolveLocalTrunkHeadSha === 'function' &&
      Array.isArray(verifiedPullRequest.sourceCommitEvidence)
        ? {
            compareDeliveryContent: deps.compareDeliveryContent,
            resolveTrunkHeadSha: deps.resolveLocalTrunkHeadSha,
          }
        : {}),
      ...(waived ? { waivedEvidence } : {}),
    }));
  const combinedWarnings = Object.hasOwn(verification.receiptInput, 'observedIntegration')
    ? (verification.receiptInput.metadataWarnings ?? [])
    : combinedMetadataWarnings(metadataWarnings, verification.receiptInput.metadataWarnings ?? []);
  const receipt = buildDeliveryReceipt({
    ...verification.receiptInput,
    ...(combinedWarnings.length > 0 ? { metadataWarnings: combinedWarnings } : {}),
  });
  if (matchingReceipt !== null) {
    if (canonicalRecordJson(matchingReceipt.record) !== canonicalRecordJson(receipt)) {
      throw deliverError('receipt-divergence');
    }
    return {
      status: 'already-delivered',
      mode,
      intent: liveIntent.record,
      receipt: matchingReceipt.record,
      action: null,
      recovery,
      branchDisposition: verification.branchDisposition,
    };
  }

  const receiptBody = renderDeliveryReceiptComment(receipt);
  if (beforeReceiptWrite) await beforeReceiptWrite();
  // Verification may have preceded an external intent write. Re-observe trunk
  // reachability at the receipt boundary so that proof cannot be reused after
  // the merge commit disappears from the authoritative trunk ref.
  await requiredDependency(
    deps,
    'fetchOriginTrunk'
  )({ remote: 'origin', branch: liveIntent.record.baseRef });
  const mergeCommitSha = pullRequest.mergeCommitSha ?? pullRequest.mergeCommit?.oid;
  if (
    !SHA_RE.test(mergeCommitSha ?? '') ||
    (await requiredDependency(
      deps,
      'isAncestor'
    )({
      ancestor: mergeCommitSha,
      descendant: `origin/${liveIntent.record.baseRef}`,
    })) !== true
  ) {
    throw deliverError('trunk-reachability-drift');
  }
  let createError = null;
  try {
    await requiredDependency(
      deps,
      'createIssueComment'
    )({ issueNumber, repository, body: receiptBody });
  } catch (error) {
    createError = error;
  }
  const readback = await readProjection({ deps, issueNumber, context });
  const readbackReceipt = readback.projection.matchingReceipt;
  const receiptWithContext = { repository, record: receipt };
  if (
    readbackReceipt === null ||
    canonicalRecordJson(readbackReceipt.record) !== canonicalRecordJson(receipt) ||
    !exactReceiptReadback(readback.comments, receiptWithContext, receiptBody)
  ) {
    if (createError !== null) throw deliverError('receipt-create-ambiguous', createError);
    throw deliverError('receipt-readback');
  }
  return {
    status: 'delivered',
    mode,
    intent: liveIntent.record,
    receipt: readbackReceipt.record,
    action: null,
    recovery,
    branchDisposition: verification.branchDisposition,
  };
}

function combinedMetadataWarnings(...lists) {
  return [...new Set(lists.flat().filter(Boolean))].sort();
}

function requiredDependency(deps, name) {
  const dependency = deps?.[name];
  if (typeof dependency !== 'function') throw deliverError(`missing-dependency:${name}`);
  return dependency;
}

async function checkManualCodeReview({ deps, cfg, prNumber, expectedHeadSha, merged }) {
  const enabled = await (deps.resolvePullRequestReviewGate ?? (async () => false))();
  if (enabled !== true) return { status: 'authorized' };
  const reviewerLogin = await requiredDependency(
    deps,
    'resolveManualCodeReviewer'
  )({
    configuredReviewer: cfg.manualCodeReviewer,
  });
  const reviewEvidence = await requiredDependency(
    deps,
    'fetchManualCodeReviewEvidence'
  )({
    repository: cfg.repo,
    prNumber,
    expectedHeadSha,
  });
  const decision = evaluateManualCodeReview({
    gateEnabled: true,
    expectedHeadSha,
    reviewerLogin,
    pullRequest: reviewEvidence,
  });
  if (decision.status === 'refused') {
    throw new TypeError(`delivery-preflight:manual-code-review-${decision.reason}`);
  }
  if (merged && decision.status !== 'authorized') {
    throw new TypeError('delivery-preflight:manual-code-review-approval-missing');
  }
  return decision;
}

async function deliverNoCommit({ deps, issue, issueNumber, cfg, lineage, pullRequests }) {
  const deliverable = parseDeliverablePosted(issue.body);
  if (!deliverable) throw new TypeError('delivery-preflight:no-commit-deliverable');
  if (String(issue.projectState || '').toLowerCase() !== 'review') {
    throw new TypeError('delivery-preflight:issue-state');
  }
  const getLocalHeadSha = requiredDependency(deps, 'getLocalHeadSha');
  const resolveTestReceiptSha = requiredDependency(deps, 'resolveTestReceiptSha');
  const [localHeadSha, testReceiptSha] = await Promise.all([
    getLocalHeadSha(),
    resolveTestReceiptSha({ issue, issueNumber }),
  ]);
  const reviewAuthority = await resolveLiveDeliveryReviewAuthority({
    deps,
    cfg,
    issue,
    issueNumber,
    testReceiptSha,
  });
  const acceptedReviewSha = reviewAuthority.acceptedSha;
  if (
    !SHA_RE.test(localHeadSha || '') ||
    !SHA_RE.test(testReceiptSha || '') ||
    testReceiptSha !== acceptedReviewSha
  ) {
    throw new TypeError('delivery-preflight:no-commit-review-evidence');
  }
  const authorization = await requiredDependency(
    deps,
    'resolveReviewAuthorization'
  )({
    issue,
    issueNumber,
    expectedHeadSha: acceptedReviewSha,
    acceptedReviewSha,
  });
  if (!authorization || authorization.mode === 'missing') {
    throw new TypeError('delivery-preflight:review-authorization');
  }
  validateNoCommitDeliveryPreflight({
    issue: { ...issue, reviewAuthorization: authorization },
    lineage,
    pullRequests,
    localHeadSha,
    testReceiptSha,
    acceptedReviewSha,
  });
  const expected = buildNoCommitDeliveryRecord({
    recordId: requiredDependency(deps, 'createIntentId')(),
    repository: cfg.repo,
    issueNumber,
    issueKind: parseIssueKind(issue.body),
    deliverableUrl: deliverable.url,
    acceptedSha: acceptedReviewSha,
    provider: requiredDependency(deps, 'providerId')(),
    sessionId: requiredDependency(deps, 'sessionId')(),
    verifiedAt: requiredDependency(deps, 'now')(),
  });
  const listRecords = async () => {
    const comments = await requiredDependency(
      deps,
      'listIssueComments'
    )({
      issueNumber,
      repository: cfg.repo,
    });
    if (!Array.isArray(comments)) throw deliverError('comments');
    return {
      comments,
      projection: projectNoCommitDeliveryRecords(
        comments.map(parseNoCommitDeliveryComment).filter(Boolean)
      ),
    };
  };
  const initial = await listRecords();
  if (initial.projection.record) {
    if (!sameNoCommitDeliveryAuthority(initial.projection.record.record, expected)) {
      throw deliverError('no-commit-record-conflict');
    }
    return {
      status: 'already-delivered',
      mode: 'no-commit',
      intent: null,
      receipt: initial.projection.record.record,
      action: null,
    };
  }
  const body = renderNoCommitDeliveryComment(expected);
  const freshIssue = await requiredDependency(
    deps,
    'fetchIssue'
  )({
    issueNumber,
    repository: cfg.repo,
  });
  const freshPullRequests = await requiredDependency(
    deps,
    'listPullRequests'
  )({
    repository: cfg.repo,
    headRef: await requiredDependency(deps, 'getCurrentBranch')(),
  });
  const freshLineage = validateLineageResult(
    await requiredDependency(
      deps,
      'resolveLineage'
    )({
      issueNumber,
      repository: cfg.repo,
      issue: freshIssue,
    })
  );
  const freshLocalHeadSha = await getLocalHeadSha();
  const freshTestReceiptSha = await resolveTestReceiptSha({ issue: freshIssue, issueNumber });
  const freshReviewAuthority = await resolveLiveDeliveryReviewAuthority({
    deps,
    cfg,
    issue: freshIssue,
    issueNumber,
    testReceiptSha: freshTestReceiptSha,
  });
  const freshAuthorization = await requiredDependency(
    deps,
    'resolveReviewAuthorization'
  )({
    issue: freshIssue,
    issueNumber,
    expectedHeadSha: freshReviewAuthority.acceptedSha,
    acceptedReviewSha: freshReviewAuthority.acceptedSha,
  });
  validateNoCommitDeliveryPreflight({
    issue: { ...freshIssue, reviewAuthorization: freshAuthorization },
    lineage: freshLineage,
    pullRequests: freshPullRequests,
    localHeadSha: freshLocalHeadSha,
    testReceiptSha: freshTestReceiptSha,
    acceptedReviewSha: freshReviewAuthority.acceptedSha,
  });
  if (
    freshIssue.body !== issue.body ||
    freshLocalHeadSha !== localHeadSha ||
    freshTestReceiptSha !== testReceiptSha ||
    JSON.stringify(freshReviewAuthority) !== JSON.stringify(reviewAuthority) ||
    JSON.stringify(freshAuthorization) !== JSON.stringify(authorization) ||
    JSON.stringify(freshLineage) !== JSON.stringify(lineage) ||
    freshPullRequests.length !== pullRequests.length
  ) {
    throw new TypeError('delivery-preflight:authority-drift');
  }
  const freshRecords = await listRecords();
  if (freshRecords.projection.record !== null) {
    throw new TypeError('delivery-preflight:delivery-record-drift');
  }
  let createError = null;
  try {
    await requiredDependency(
      deps,
      'createIssueComment'
    )({
      issueNumber,
      repository: cfg.repo,
      body,
    });
  } catch (error) {
    createError = error;
  }
  const readback = await listRecords();
  const record = readback.projection.record;
  const exact = readback.comments.some(
    (comment) =>
      comment.body === body &&
      parseNoCommitDeliveryComment(comment)?.record.recordId === expected.recordId
  );
  if (!record || !sameNoCommitDeliveryAuthority(record.record, expected) || !exact) {
    if (createError) throw deliverError('comment-create-ambiguous', createError);
    throw deliverError('comment-readback');
  }
  return {
    status: 'delivered',
    mode: 'no-commit',
    intent: null,
    receipt: record.record,
    action: null,
  };
}

async function runAdvancedGenericWaiver({
  deps,
  cfg,
  state,
  issueNumber,
  issue,
  lineage,
  branch,
  authority,
  selectedPullRequest,
  initial,
  live,
  preflightInput,
  deliveryConfig,
  historical,
  testReceiptSha,
  acceptedReviewSha,
}) {
  const context = { repository: cfg.repo, issueNumber, prNumber: selectedPullRequest.number };
  const originalIntent = initial.projection.intents.find(
    ({ record }) => record.intentId === live.record.originalIntentId
  );
  if (originalIntent?.record.schema !== 'aitm.delivery-intent/v1') {
    throw deliverError('delivery-waiver-original-intent');
  }
  const verify = ({ intent, originalIntent: original, pullRequest, evidence }) =>
    verifyDeliveredPullRequest({
      acceptedSha: authority.acceptedSha,
      intent,
      intentCreatedAt: original.createdAt,
      pullRequest,
      recovery: true,
      localHeadSha: historical.observedLocalHeadSha,
      testReceiptSha,
      acceptedReviewSha,
      fetchOriginTrunk: requiredDependency(deps, 'fetchOriginTrunk'),
      isAncestor: requiredDependency(deps, 'isAncestor'),
      inspectMergeCommit: requiredDependency(deps, 'inspectMergeCommit'),
      attributingCommits: requiredDependency(deps, 'attributingCommits'),
      genericWaiverEvidence: {
        originalIntent: { record: original.record, createdAt: original.createdAt },
        ...evidence,
      },
    });
  const readFresh = async (expectedIntent) => {
    const freshIssue = await deps.fetchIssue({ issueNumber, repository: cfg.repo });
    const freshLineage = validateLineageResult(
      await deps.resolveLineage({ issueNumber, repository: cfg.repo, issue: freshIssue })
    );
    const freshBranch = await deps.getCurrentBranch();
    const freshLocalHead = await deps.getLocalHeadSha();
    const freshTestSha = await deps.resolveTestReceiptSha({ issue: freshIssue, issueNumber });
    const freshReview = await resolveLiveDeliveryReviewAuthority({
      deps,
      cfg,
      issue: freshIssue,
      issueNumber,
      testReceiptSha: freshTestSha,
    });
    const freshRefs = await deps.listPullRequests({ repository: cfg.repo, headRef: freshBranch });
    const freshPrs = await Promise.all(
      freshRefs.map(({ number }) =>
        deps.fetchPullRequest({ repository: cfg.repo, prNumber: Number(number) })
      )
    );
    const freshReviewAuthorization = await deps.resolveReviewAuthorization({
      issue: freshIssue,
      issueNumber,
      expectedHeadSha: freshReview.acceptedSha,
      acceptedReviewSha: freshReview.acceptedSha,
    });
    const freshInput = {
      ...preflightInput,
      issue: {
        ...freshIssue,
        agentReviewPassed: freshReview.outcome === 'passed',
        reviewAuthority: freshReview,
        reviewAuthorization: freshReviewAuthorization,
      },
      binding: bindingFromState({ branch: freshBranch, state }),
      lineage: freshLineage,
      pullRequests: freshPrs,
      localHeadSha: freshLocalHead,
      testReceiptSha: freshTestSha,
      acceptedReviewSha: freshReview.acceptedSha,
      dirtyPaths: await deps.listDirtyPaths({ issueNumber }),
      config: {
        ...deliveryConfig,
        repositoryMergeMethods: await deps.fetchRepositoryMergeMethods({ repository: cfg.repo }),
      },
      commitSubjects: await mergedSourceCommitSubjects(
        freshPrs.find(({ number }) => number === selectedPullRequest.number),
        deps.inspectSourceCommit
      ),
      intent: expectedIntent.record,
    };
    const freshHistorical = validateHistoricalRecoveryPreflight(freshInput);
    const freshProjection = await readProjection({ deps, issueNumber, context });
    const manualDecision = await checkManualCodeReview({
      deps,
      cfg,
      prNumber: selectedPullRequest.number,
      expectedHeadSha: authority.acceptedSha,
      merged: true,
    });
    if (
      freshIssue.body !== issue.body ||
      !equalJson(freshLineage, lineage) ||
      freshBranch !== branch ||
      freshLocalHead !== historical.observedLocalHeadSha ||
      freshTestSha !== testReceiptSha ||
      freshReview.acceptedSha !== acceptedReviewSha ||
      freshHistorical.pr.number !== selectedPullRequest.number ||
      freshHistorical.acceptedSha !== authority.acceptedSha ||
      manualDecision.status !== 'authorized' ||
      freshProjection.projection.liveIntent === null ||
      canonicalRecordJson(freshProjection.projection.liveIntent.record) !==
        canonicalRecordJson(expectedIntent.record)
    )
      throw deliverError('delivery-waiver-scope-drift');
    return { issue: freshIssue, pullRequest: freshHistorical.pr, ...freshProjection };
  };
  return runDeliveryWaiverTransaction({
    context: {
      ...context,
      issue,
      pullRequest: historical.pr,
      liveIntent: live,
      matchingReceipt: initial.projection.matchingReceipt,
      failure: null,
      mode: 'historical-recovery',
      recovery: true,
    },
    originalIntent,
    records: initial.comments,
    deps: {
      now: requiredDependency(deps, 'now'),
      createIntentId: requiredDependency(deps, 'createIntentId'),
      createRunId: createRecordId,
      resolveTranscriptPath: deps.resolveTranscriptPath,
      resolveDeliveryWaiver: deps.resolveDeliveryWaiver,
      verifyStoredDeliveryWaiverAuthority: deps.verifyStoredDeliveryWaiverAuthority,
      journal: deps.createDeliveryWaiverJournal?.({ repository: cfg.repo, issue: issueNumber }),
      comments: {
        list: () => deps.listIssueComments({ issueNumber, repository: cfg.repo }),
        post: (body) => deps.createIssueComment({ issueNumber, repository: cfg.repo, body }),
      },
      readFresh,
      verifyWaived: ({ intent, originalIntent: original, waiver, pullRequest }) =>
        verify({ intent, originalIntent: original, pullRequest, evidence: { waiver } }),
      verifyPinned: ({
        intent,
        originalIntent: original,
        grant,
        burn,
        burnOid,
        receipt,
        pullRequest,
      }) =>
        verify({
          intent,
          originalIntent: original,
          pullRequest,
          evidence: { grant, burn, burnOid, receipt },
        }),
    },
  });
}

function equalJson(left, right) {
  return canonicalRecordJson(left) === canonicalRecordJson(right);
}

export async function runDeliver({ issueNumber, cfg, state, reconcile = null, deps = {} } = {}) {
  // #1562 — carries the reconciliation record from the recovery path out to the
  // caller so it can be appended to the issue ledger beside the receipt.
  let methodReconciliation = null;
  if (!Number.isSafeInteger(Number(issueNumber)) || Number(issueNumber) <= 0) {
    throw deliverError('issue-number');
  }
  if (!cfg || typeof cfg.repo !== 'string' || cfg.repo.length === 0) {
    throw deliverError('configuration');
  }
  issueNumber = Number(issueNumber);

  const fetchIssue = requiredDependency(deps, 'fetchIssue');
  const resolveLineage = requiredDependency(deps, 'resolveLineage');
  const issue = await fetchIssue({ issueNumber, repository: cfg.repo });
  const lineage = validateLineageResult(
    await resolveLineage({ issueNumber, repository: cfg.repo, issue })
  );
  if (lineage?.parentIssueNumber !== null) {
    return {
      status: 'not-provider-delivery',
      reason: 'child-lineage',
      intent: null,
      receipt: null,
      action: null,
    };
  }

  const protocol = selectEvidenceProtocol({ body: issue.body, context: deps.executionContext });
  if (protocol.protocol === 'v2') {
    return requiredDependency(
      deps,
      'runEvidenceV2Delivery'
    )({
      issue,
      issueNumber,
      repository: cfg.repo,
      lineage,
      protocol,
      state,
    });
  }

  const getCurrentBranch = requiredDependency(deps, 'getCurrentBranch');
  const listPullRequests = requiredDependency(deps, 'listPullRequests');
  const branch = await getCurrentBranch();
  const pullRequestRefs = await listPullRequests({
    repository: cfg.repo,
    headRef: branch,
  });
  if (!Array.isArray(pullRequestRefs)) throw deliverError('pull-requests');

  // A root epic delivers aggregate child commits to trunk. Although it remains
  // a no-commit kind for Develop/Test, provider delivery must not replace that
  // branch delivery with an issue-comment-only receipt (#1632).
  if (isIssueResidentDeliveryKind(issue.body) && pullRequestRefs.length === 0) {
    return deliverNoCommit({
      deps,
      issue,
      issueNumber,
      cfg,
      lineage,
      pullRequests: pullRequestRefs,
    });
  }

  const getLocalHeadSha = requiredDependency(deps, 'getLocalHeadSha');
  const resolveTestReceiptSha = requiredDependency(deps, 'resolveTestReceiptSha');
  const fetchPullRequest = requiredDependency(deps, 'fetchPullRequest');
  const fetchRequiredChecks = requiredDependency(deps, 'fetchRequiredChecks');
  const fetchRepositoryMergeMethods = requiredDependency(deps, 'fetchRepositoryMergeMethods');
  const listCommitSubjects = requiredDependency(deps, 'listCommitSubjects');
  const listDirtyPaths = requiredDependency(deps, 'listDirtyPaths');
  const providerId = requiredDependency(deps, 'providerId');
  const sessionId = requiredDependency(deps, 'sessionId');
  const now = requiredDependency(deps, 'now');
  const createIntentId = requiredDependency(deps, 'createIntentId');

  const localHeadSha = await getLocalHeadSha();
  const testReceiptSha = await resolveTestReceiptSha({ issue, issueNumber });
  const reviewAuthority = await resolveLiveDeliveryReviewAuthority({
    deps,
    cfg,
    issue,
    issueNumber,
    testReceiptSha,
  });
  const acceptedReviewSha = reviewAuthority.acceptedSha;
  const agentReviewPassed = reviewAuthority.outcome === 'passed';
  const pullRequests = await Promise.all(
    pullRequestRefs.map(({ number }) =>
      fetchPullRequest({ repository: cfg.repo, prNumber: Number(number) })
    )
  );
  let authority;
  try {
    authority = resolveAcceptedDeliveryAuthority({
      issueNumber,
      branch,
      localHeadSha,
      testReceiptSha,
      reviewReceiptSha: acceptedReviewSha,
      agentReviewPassed,
      reviewAuthority,
      pullRequests,
    });
  } catch (error) {
    if (!(error instanceof DeliveryAuthorityError)) throw error;
    const category =
      error.category === 'ambiguous-pr'
        ? 'pull-request-count'
        : error.category === 'branch-mismatch'
          ? 'pull-request-head'
          : error.category === 'accepted-evidence'
            ? 'head-mismatch'
            : 'input';
    throw new TypeError(`delivery-preflight:${category}`, { cause: error });
  }
  const selectedPullRequest = authority.pullRequest;
  const mergedPullRequest = pullRequestMerged(selectedPullRequest);
  const [repositoryMergeMethods, dirtyPaths] = await Promise.all([
    fetchRepositoryMergeMethods({ repository: cfg.repo }),
    listDirtyPaths({ issueNumber }),
  ]);
  const reviewAuthorization = await requiredDependency(
    deps,
    'resolveReviewAuthorization'
  )({
    issue,
    issueNumber,
    expectedHeadSha: authority.acceptedSha,
    acceptedReviewSha,
  });
  const assignee =
    typeof cfg.assignee === 'string' && cfg.assignee !== '@me' && cfg.assignee.length > 0
      ? cfg.assignee
      : await requiredDependency(deps, 'getAuthenticatedLogin')();
  const deliveryConfig = {
    ...cfg,
    assignee,
    repositoryMergeMethods,
  };
  const context = {
    repository: cfg.repo,
    issueNumber,
    prNumber: selectedPullRequest.number,
  };
  const initial = await readProjection({ deps, issueNumber, context });
  const live = initial.projection.liveIntent;
  const recordedAttributionException =
    mergedPullRequest || authority.headRelation !== 'current'
      ? null
      : await resolveOpenAttributionException({ comments: initial.comments, now: now(), deps });
  // A grant authorizes one PR. Keep verifying the historical record, but do
  // not route a later, normally attributed PR through that prior waiver.
  const activeAttributionException =
    recordedAttributionException?.proposal.prNumber === selectedPullRequest.number
      ? recordedAttributionException
      : null;
  const sourceInventory =
    activeAttributionException === null
      ? null
      : await classifiedOpenInventory(selectedPullRequest, deps, localHeadSha);
  const commitSubjects =
    sourceInventory !== null
      ? sourceInventory.attributableSubjects
      : mergedPullRequest
        ? await mergedSourceCommitSubjects(selectedPullRequest, deps.inspectSourceCommit)
        : await openSourceCommitSubjects(
            await listCommitSubjects({ range: 'origin/trunk..HEAD' }),
            selectedPullRequest,
            deps.inspectSourceCommit
          );
  const preflightInput = {
    issue: { ...issue, agentReviewPassed, reviewAuthority, reviewAuthorization },
    binding: bindingFromState({ branch, state }),
    lineage,
    pullRequests,
    localHeadSha,
    testReceiptSha,
    acceptedReviewSha,
    dirtyPaths,
    config: deliveryConfig,
    commitSubjects,
  };
  if (sourceInventory !== null) {
    preflightInput.sourceInventory = sourceInventory;
    preflightInput.attributionException = activeAttributionException;
  }
  if (authority.headRelation === 'advanced') {
    if (reconcile !== null && (live === null || live.record.provider === 'external')) {
      const historical = validateHistoricalReconstructionPreflight(preflightInput);
      await checkManualCodeReview({
        deps,
        cfg,
        prNumber: historical.pr.number,
        expectedHeadSha: authority.acceptedSha,
        merged: true,
      });
      const mergeCommitSha =
        typeof historical.pr.mergeCommitSha === 'string'
          ? historical.pr.mergeCommitSha
          : historical.pr.mergeCommit?.oid;
      const observed = await observeMergeMethod({
        mergeCommitSha,
        expectedHeadSha: historical.expectedHeadSha,
        inspectMergeCommit: requiredDependency(deps, 'inspectMergeCommit'),
      });
      const mergeMethod = resolveReconciledMergeMethod({
        declared: reconcile.declaredMergeMethod,
        observed,
        configured: historical.mergeMethod,
      });
      const reconstruction = buildMethodReconciliation({
        issueNumber,
        repository: cfg.repo,
        prNumber: historical.pr.number,
        acceptedSha: historical.acceptedSha,
        mergeCommitSha,
        configuredMergeMethod: historical.mergeMethod,
        observedMergeMethod: mergeMethod,
        reason: reconcile.reason,
        operator: reconcile.operator,
        clientCreatedAt: normalizeGitHubInstant(historical.pr.mergedAt),
        intentOrigin: 'retroactively-reconstructed',
      });
      const priorReconstruction = matchingReconstruction(initial.comments, reconstruction);
      if (live !== null) {
        if (priorReconstruction === null)
          throw deliverError('historical-reconstruction-provenance');
        const expected = buildIntentFromPreflight({
          preflight: { ...historical, mergeMethod },
          cfg,
          intentId: live.record.intentId,
          supersedesIntentId: null,
          provider: 'external',
          sessionId: live.record.sessionId,
          clientCreatedAt: live.record.clientCreatedAt,
          commitTitle: live.record.commitTitle,
          commitMessage: live.record.commitMessage,
        });
        if (canonicalRecordJson(expected) !== canonicalRecordJson(live.record)) {
          throw deliverError('intent-divergence');
        }
        return verifyAndFinalize({
          deps,
          issueNumber,
          repository: cfg.repo,
          context,
          liveIntent: live,
          matchingReceipt: initial.projection.matchingReceipt,
          pullRequest: historical.pr,
          recovery: true,
          mode: 'historical-reconstruction',
          acceptedSha: historical.acceptedSha,
          localHeadSha: historical.observedLocalHeadSha,
          testReceiptSha,
          acceptedReviewSha,
          metadataWarnings: historical.metadataWarnings ?? [],
        });
      }
      const verified = await verifyExternalDeliveredPullRequest({
        intentInput: buildExternalIntentInput({
          preflight: historical,
          cfg,
          intentId: createIntentId(),
          sessionId: sessionId(),
          clientCreatedAt: historical.pr.mergedAt,
          mergeMethodOverride: mergeMethod,
        }),
        pullRequest: historical.pr,
        acceptedSha: historical.acceptedSha,
        localHeadSha: historical.observedLocalHeadSha,
        testReceiptSha,
        acceptedReviewSha,
        fetchOriginTrunk: requiredDependency(deps, 'fetchOriginTrunk'),
        isAncestor: requiredDependency(deps, 'isAncestor'),
        inspectMergeCommit: requiredDependency(deps, 'inspectMergeCommit'),
        attributingCommits: requiredDependency(deps, 'attributingCommits'),
      });
      // #1574 — establish provider/Git proof before the first ledger write.
      if (priorReconstruction === null) {
        await requiredDependency(
          deps,
          'createIssueComment'
        )({
          issueNumber,
          repository: cfg.repo,
          body: renderMethodReconciliationComment(reconstruction),
        });
      }
      const liveIntent = await appendIntent({
        deps,
        issueNumber,
        repository: cfg.repo,
        context,
        intent: verified.intent,
      });
      return verifyAndFinalize({
        deps,
        issueNumber,
        repository: cfg.repo,
        context,
        liveIntent,
        matchingReceipt: null,
        pullRequest: historical.pr,
        recovery: true,
        mode: 'historical-reconstruction',
        acceptedSha: historical.acceptedSha,
        localHeadSha: historical.observedLocalHeadSha,
        testReceiptSha,
        acceptedReviewSha,
        verified,
        metadataWarnings: historical.metadataWarnings ?? [],
      });
    }
    const historical = validateHistoricalRecoveryPreflight({
      ...preflightInput,
      intent: live?.record ?? null,
    });
    if (live?.record.schema === 'aitm.delivery-intent/v3') {
      return runAdvancedGenericWaiver({
        deps,
        cfg,
        state,
        issueNumber,
        issue,
        lineage,
        branch,
        authority,
        selectedPullRequest,
        initial,
        live,
        preflightInput,
        deliveryConfig,
        historical,
        testReceiptSha,
        acceptedReviewSha,
      });
    }
    return verifyAndFinalize({
      deps,
      issueNumber,
      repository: cfg.repo,
      context,
      liveIntent: live,
      matchingReceipt: initial.projection.matchingReceipt,
      pullRequest: historical.pr,
      recovery: true,
      mode: 'historical-recovery',
      acceptedSha: historical.acceptedSha,
      localHeadSha: historical.observedLocalHeadSha,
      testReceiptSha,
      acceptedReviewSha,
    });
  }

  const checks = await fetchRequiredChecks({
    repository: cfg.repo,
    prNumber: selectedPullRequest.number,
    expectedHeadSha: authority.acceptedSha,
  });
  const preflight = mergedPullRequest
    ? validateMergedDeliveryPreflight({
        ...preflightInput,
        checks,
        // A pending v2 intent already fixes the authorized token set. The merged
        // preflight still checks lifecycle, head, CI, and configuration; the
        // live source inventory is independently re-read and proved below before
        // any receipt is emitted.
        ...(live?.record.schema === 'aitm.delivery-intent/v2'
          ? {
              commitSubjects: live.record.attributionTokens.map(
                (token) => `[${token}] Authorized pending waiver`
              ),
            }
          : {}),
      })
    : validateDeliveryPreflight({ ...preflightInput, checks });
  const revalidateBeforeProviderAction = async (intent) => {
    if (preflight.exceptionDisposition === undefined) return;
    try {
      const freshPr = await fetchPullRequest({
        repository: cfg.repo,
        prNumber: selectedPullRequest.number,
      });
      const freshHead = await getLocalHeadSha();
      const freshComments = await readProjection({ deps, issueNumber, context });
      const freshException = await resolveOpenAttributionException({
        comments: freshComments.comments,
        now: now(),
        deps,
      });
      if (
        freshException === null ||
        freshComments.projection.liveIntent?.record.intentId !== intent.intentId ||
        freshPr.state !== 'OPEN'
      )
        throw deliverError('late-attribution');
      const freshInventory = await classifiedOpenInventory(freshPr, deps, freshHead);
      const freshChecks = await fetchRequiredChecks({
        repository: cfg.repo,
        prNumber: selectedPullRequest.number,
        expectedHeadSha: authority.acceptedSha,
      });
      const freshPreflight = validateDeliveryPreflight({
        ...preflightInput,
        pullRequests: pullRequests.map((pr) => (pr.number === freshPr.number ? freshPr : pr)),
        localHeadSha: freshHead,
        dirtyPaths: await listDirtyPaths({ issueNumber }),
        checks: freshChecks,
        commitSubjects: freshInventory.attributableSubjects,
        sourceInventory: freshInventory,
        attributionException: freshException,
      });
      const expected = buildIntentFromPreflight({
        preflight: freshPreflight,
        cfg,
        intentId: intent.intentId,
        supersedesIntentId: intent.supersedesIntentId,
        provider: intent.provider,
        sessionId: intent.sessionId,
        clientCreatedAt: intent.clientCreatedAt,
      });
      if (
        authorizedIntentBytes(expected) !== authorizedIntentBytes(intent) ||
        authorizedIntentBytes(freshComments.projection.liveIntent.record) !==
          authorizedIntentBytes(intent)
      )
        throw deliverError('late-attribution');
    } catch (error) {
      throw deliverError('late-attribution', error);
    }
  };
  // A preflight (or a prior explanation) is not a capability. Re-read the
  // mutable sources immediately before an external effect and refuse drift.
  let acceptedScopeBody = issue.body;
  const assertFreshDeliveryAuthority = async ({
    expectedLiveIntent = null,
    allowMatchingReceipt = false,
    allowScopeRefresh = false,
  } = {}) => {
    const freshIssue = await fetchIssue({ issueNumber, repository: cfg.repo });
    const freshLineage = validateLineageResult(
      await resolveLineage({ issueNumber, repository: cfg.repo, issue: freshIssue })
    );
    const freshBranch = await getCurrentBranch();
    const freshLocalHeadSha = await getLocalHeadSha();
    const freshTestReceiptSha = await resolveTestReceiptSha({ issue: freshIssue, issueNumber });
    const freshReviewAuthority = await resolveLiveDeliveryReviewAuthority({
      deps,
      cfg,
      issue: freshIssue,
      issueNumber,
      testReceiptSha: freshTestReceiptSha,
    });
    const freshRefs = await listPullRequests({ repository: cfg.repo, headRef: freshBranch });
    const freshPullRequests = await Promise.all(
      freshRefs.map(({ number }) =>
        fetchPullRequest({ repository: cfg.repo, prNumber: Number(number) })
      )
    );
    let freshAcceptedAuthority;
    try {
      freshAcceptedAuthority = resolveAcceptedDeliveryAuthority({
        issueNumber,
        branch: freshBranch,
        localHeadSha: freshLocalHeadSha,
        testReceiptSha: freshTestReceiptSha,
        reviewReceiptSha: freshReviewAuthority.acceptedSha,
        agentReviewPassed: freshReviewAuthority.outcome === 'passed',
        reviewAuthority: freshReviewAuthority,
        pullRequests: freshPullRequests,
      });
    } catch (error) {
      if (!(error instanceof DeliveryAuthorityError)) throw error;
      throw new TypeError('delivery-preflight:authority-drift', { cause: error });
    }
    if (freshAcceptedAuthority.pullRequest.number !== selectedPullRequest.number) {
      throw new TypeError('delivery-preflight:pull-request-drift');
    }
    const freshReviewAuthorization = await requiredDependency(
      deps,
      'resolveReviewAuthorization'
    )({
      issue: freshIssue,
      issueNumber,
      expectedHeadSha: freshReviewAuthority.acceptedSha,
      acceptedReviewSha: freshReviewAuthority.acceptedSha,
    });
    const freshChecks = await fetchRequiredChecks({
      repository: cfg.repo,
      prNumber: selectedPullRequest.number,
      expectedHeadSha: authority.acceptedSha,
    });
    const freshProjection = await readProjection({ deps, issueNumber, context });
    const freshException = preflight.exceptionDisposition
      ? await resolveOpenAttributionException({
          comments: freshProjection.comments,
          now: now(),
          deps,
        })
      : null;
    const freshInventory = freshException
      ? await classifiedOpenInventory(freshAcceptedAuthority.pullRequest, deps, freshLocalHeadSha)
      : null;
    const freshCommitSubjects = freshInventory
      ? freshInventory.attributableSubjects
      : mergedPullRequest
        ? await mergedSourceCommitSubjects(
            freshAcceptedAuthority.pullRequest,
            deps.inspectSourceCommit
          )
        : await openSourceCommitSubjects(
            await listCommitSubjects({ range: 'origin/trunk..HEAD' }),
            freshAcceptedAuthority.pullRequest,
            deps.inspectSourceCommit
          );
    const freshInput = {
      ...preflightInput,
      issue: {
        ...freshIssue,
        agentReviewPassed: freshReviewAuthority.outcome === 'passed',
        reviewAuthority: freshReviewAuthority,
        reviewAuthorization: freshReviewAuthorization,
      },
      binding: bindingFromState({ branch: freshBranch, state }),
      lineage: freshLineage,
      pullRequests: freshPullRequests,
      localHeadSha: freshLocalHeadSha,
      testReceiptSha: freshTestReceiptSha,
      acceptedReviewSha: freshReviewAuthority.acceptedSha,
      dirtyPaths: await listDirtyPaths({ issueNumber }),
      config: {
        ...deliveryConfig,
        repositoryMergeMethods: await fetchRepositoryMergeMethods({ repository: cfg.repo }),
      },
      commitSubjects:
        mergedPullRequest && live?.record.schema === 'aitm.delivery-intent/v2'
          ? live.record.attributionTokens.map((token) => `[${token}] Authorized pending waiver`)
          : freshCommitSubjects,
      ...(preflight.exceptionDisposition
        ? { sourceInventory: freshInventory, attributionException: freshException }
        : {}),
      checks: freshChecks,
    };
    const freshPreflight = mergedPullRequest
      ? validateMergedDeliveryPreflight(freshInput)
      : validateDeliveryPreflight(freshInput);
    const comparableFreshPreflight =
      allowScopeRefresh || acceptedScopeBody !== issue.body
        ? { ...freshPreflight, issue: { ...freshPreflight.issue, body: issue.body } }
        : freshPreflight;
    if (
      (!allowScopeRefresh && freshIssue.body !== acceptedScopeBody) ||
      JSON.stringify(freshLineage) !== JSON.stringify(lineage) ||
      freshBranch !== branch ||
      freshLocalHeadSha !== localHeadSha ||
      freshTestReceiptSha !== testReceiptSha ||
      JSON.stringify(freshReviewAuthority) !== JSON.stringify(reviewAuthority) ||
      JSON.stringify(freshReviewAuthorization) !== JSON.stringify(reviewAuthorization) ||
      JSON.stringify(comparableFreshPreflight) !== JSON.stringify(preflight)
    ) {
      throw new TypeError('delivery-preflight:authority-drift');
    }
    if (allowScopeRefresh) acceptedScopeBody = freshIssue.body;
    const projectionMatches = expectedLiveIntent
      ? freshProjection.projection.liveIntent !== null &&
        canonicalRecordJson(freshProjection.projection.liveIntent.record) ===
          canonicalRecordJson(expectedLiveIntent.record) &&
        (allowMatchingReceipt || freshProjection.projection.matchingReceipt === null)
      : JSON.stringify(freshProjection.projection) === JSON.stringify(initial.projection);
    if (!projectionMatches) {
      throw new TypeError('delivery-preflight:delivery-record-drift');
    }
    const freshManualDecision = await checkManualCodeReview({
      deps,
      cfg,
      prNumber: selectedPullRequest.number,
      expectedHeadSha: authority.acceptedSha,
      merged: mergedPullRequest,
    });
    if (freshManualDecision.status !== decision.status) {
      throw new TypeError('delivery-preflight:manual-review-drift');
    }
    return freshPreflight;
  };
  const decision = await checkManualCodeReview({
    deps,
    cfg,
    prNumber: selectedPullRequest.number,
    expectedHeadSha: authority.acceptedSha,
    merged: mergedPullRequest,
  });
  if (decision.status !== 'authorized') {
    const reviewerLogin = decision.reviewerLogin;
    let reviewRequested = false;
    if (decision.status === 'request-review') {
      await assertFreshDeliveryAuthority();
      await requiredDependency(
        deps,
        'requestPullRequestReview'
      )({
        repository: cfg.repo,
        prNumber: selectedPullRequest.number,
        reviewerLogin,
      });
      reviewRequested = true;
    }
    return {
      status: 'manual-review-required',
      reason: decision.reason,
      prNumber: selectedPullRequest.number,
      reviewerLogin,
      expectedHeadSha: authority.acceptedSha,
      reviewRequested,
    };
  }
  if (mergedPullRequest) {
    await assertFreshDeliveryAuthority();
    let liveIntent = live;
    let recovery = liveIntent?.record.provider === 'external';
    const runGenericWaiver = (failure = null) => {
      const originalIntent =
        liveIntent?.record.schema === 'aitm.delivery-intent/v3'
          ? initial.projection.intents.find(
              ({ record }) => record.intentId === liveIntent.record.originalIntentId
            )
          : liveIntent;
      if (!originalIntent || originalIntent.record.schema !== 'aitm.delivery-intent/v1') {
        throw deliverError('delivery-waiver-original-intent');
      }
      const verifyWaived = ({ intent, originalIntent: original, waiver, pullRequest: pr }) =>
        verifyDeliveredPullRequest({
          acceptedSha: authority.acceptedSha,
          intent,
          intentCreatedAt: original.createdAt,
          pullRequest: pr,
          recovery,
          localHeadSha,
          testReceiptSha,
          acceptedReviewSha,
          fetchOriginTrunk: requiredDependency(deps, 'fetchOriginTrunk'),
          isAncestor: requiredDependency(deps, 'isAncestor'),
          inspectMergeCommit: requiredDependency(deps, 'inspectMergeCommit'),
          attributingCommits: requiredDependency(deps, 'attributingCommits'),
          genericWaiverEvidence: {
            originalIntent: { record: original.record, createdAt: original.createdAt },
            waiver,
          },
        });
      return runDeliveryWaiverTransaction({
        context: {
          ...context,
          issue,
          pullRequest: selectedPullRequest,
          liveIntent,
          matchingReceipt: initial.projection.matchingReceipt,
          failure,
          mode: 'current-head',
          recovery,
        },
        originalIntent,
        records: initial.comments,
        deps: {
          now,
          createIntentId,
          createRunId: createRecordId,
          resolveTranscriptPath: deps.resolveTranscriptPath,
          resolveDeliveryWaiver: deps.resolveDeliveryWaiver,
          verifyStoredDeliveryWaiverAuthority: deps.verifyStoredDeliveryWaiverAuthority,
          journal: deps.createDeliveryWaiverJournal?.({ repository: cfg.repo, issue: issueNumber }),
          comments: {
            list: () => deps.listIssueComments({ issueNumber, repository: cfg.repo }),
            post: (body) => deps.createIssueComment({ issueNumber, repository: cfg.repo, body }),
          },
          readFresh: async (expectedIntent, { allowScopeRefresh = false } = {}) => {
            await assertFreshDeliveryAuthority({
              expectedLiveIntent: expectedIntent,
              allowMatchingReceipt: expectedIntent.record.schema === 'aitm.delivery-intent/v3',
              allowScopeRefresh,
            });
            const [freshIssue, freshPr, freshProjection] = await Promise.all([
              fetchIssue({ issueNumber, repository: cfg.repo }),
              fetchPullRequest({ repository: cfg.repo, prNumber: selectedPullRequest.number }),
              readProjection({ deps, issueNumber, context }),
            ]);
            if (
              !pullRequestMerged(freshPr) ||
              (!allowScopeRefresh && freshIssue.body !== acceptedScopeBody) ||
              freshPr.number !== selectedPullRequest.number
            )
              throw deliverError('delivery-waiver-scope-drift');
            return { issue: freshIssue, pullRequest: freshPr, ...freshProjection };
          },
          verifyWaived,
          verifyPinned: ({
            intent,
            originalIntent: original,
            grant,
            burn,
            burnOid,
            receipt,
            pullRequest: pr,
          }) =>
            verifyDeliveredPullRequest({
              acceptedSha: authority.acceptedSha,
              intent,
              intentCreatedAt: original.createdAt,
              pullRequest: pr,
              recovery,
              localHeadSha,
              testReceiptSha,
              acceptedReviewSha,
              fetchOriginTrunk: requiredDependency(deps, 'fetchOriginTrunk'),
              isAncestor: requiredDependency(deps, 'isAncestor'),
              inspectMergeCommit: requiredDependency(deps, 'inspectMergeCommit'),
              attributingCommits: requiredDependency(deps, 'attributingCommits'),
              genericWaiverEvidence: {
                originalIntent: { record: original.record, createdAt: original.createdAt },
                grant,
                burn,
                burnOid,
                receipt,
              },
            }),
        },
      });
    };
    if (liveIntent?.record.schema === 'aitm.delivery-intent/v3') {
      return runGenericWaiver();
    }
    if (liveIntent !== null && liveIntent.record.schema !== 'aitm.delivery-intent/v2') {
      const expected = buildIntentFromPreflight({
        preflight,
        cfg,
        intentId: liveIntent.record.intentId,
        supersedesIntentId: liveIntent.record.supersedesIntentId,
        provider: liveIntent.record.provider,
        sessionId: liveIntent.record.sessionId,
        clientCreatedAt: liveIntent.record.clientCreatedAt,
        ...(recovery
          ? {
              commitTitle: liveIntent.record.commitTitle,
              commitMessage: liveIntent.record.commitMessage,
            }
          : {}),
      });
      if (authorizedIntentBytes(expected) !== authorizedIntentBytes(liveIntent.record)) {
        throw deliverError('intent-divergence');
      }
    }
    if (liveIntent === null) {
      recovery = true;
      // #1562 — merge-method reconciliation. The configured method is the only
      // intent this path can otherwise produce, so a pull request merged by a
      // different method strands the issue. When the operator opts in, observe
      // the real topology, refuse unless their declaration agrees with it, and
      // restate the intent to the observed method. `verifyLiveDelivery`'s
      // equality check is untouched — it now compares against a reconciled
      // intent instead of an unreachable one.
      let reconciledMergeMethod = null;
      if (reconcile !== null) {
        const observed = await observeMergeMethod({
          mergeCommitSha: selectedPullRequest.mergeCommitSha,
          expectedHeadSha: preflight.expectedHeadSha,
          inspectMergeCommit: requiredDependency(deps, 'inspectMergeCommit'),
        });
        reconciledMergeMethod = resolveReconciledMergeMethod({
          declared: reconcile.declaredMergeMethod,
          observed,
          configured: preflight.mergeMethod,
        });
        methodReconciliation = buildMethodReconciliation({
          issueNumber,
          repository: cfg.repo,
          prNumber: selectedPullRequest.number,
          acceptedSha: authority.acceptedSha,
          mergeCommitSha: selectedPullRequest.mergeCommitSha,
          configuredMergeMethod: preflight.mergeMethod,
          observedMergeMethod: reconciledMergeMethod,
          reason: reconcile.reason,
          operator: reconcile.operator,
          clientCreatedAt: normalizeGitHubInstant(selectedPullRequest.mergedAt),
        });
        // Append the divergence BEFORE the intent, so the authorization for the
        // restatement is on the ledger even if verification later refuses.
        await assertFreshDeliveryAuthority();
        await requiredDependency(
          deps,
          'createIssueComment'
        )({
          issueNumber,
          repository: cfg.repo,
          body: renderMethodReconciliationComment(methodReconciliation),
        });
      }
      const verified = await verifyExternalDeliveredPullRequest({
        intentInput: buildExternalIntentInput({
          preflight,
          cfg,
          intentId: createIntentId(),
          sessionId: sessionId(),
          clientCreatedAt: selectedPullRequest.mergedAt,
          mergeMethodOverride: reconciledMergeMethod,
        }),
        pullRequest: selectedPullRequest,
        acceptedSha: authority.acceptedSha,
        localHeadSha,
        testReceiptSha,
        acceptedReviewSha,
        fetchOriginTrunk: requiredDependency(deps, 'fetchOriginTrunk'),
        isAncestor: requiredDependency(deps, 'isAncestor'),
        inspectMergeCommit: requiredDependency(deps, 'inspectMergeCommit'),
        attributingCommits: requiredDependency(deps, 'attributingCommits'),
      });
      const recoveryIntent = verified.intent;
      await assertFreshDeliveryAuthority();
      liveIntent = await appendIntent({
        deps,
        issueNumber,
        repository: cfg.repo,
        context,
        intent: recoveryIntent,
      });
      return verifyAndFinalize({
        deps,
        issueNumber,
        repository: cfg.repo,
        context,
        liveIntent,
        matchingReceipt: null,
        pullRequest: selectedPullRequest,
        recovery,
        mode: 'current-head',
        acceptedSha: authority.acceptedSha,
        localHeadSha,
        testReceiptSha,
        acceptedReviewSha,
        verified,
        metadataWarnings: preflight.metadataWarnings ?? [],
        beforeReceiptWrite: () => assertFreshDeliveryAuthority({ expectedLiveIntent: liveIntent }),
      });
    }
    try {
      return await verifyAndFinalize({
        deps,
        issueNumber,
        repository: cfg.repo,
        context,
        liveIntent,
        matchingReceipt: initial.projection.matchingReceipt,
        pullRequest: selectedPullRequest,
        recovery,
        mode: 'current-head',
        acceptedSha: authority.acceptedSha,
        localHeadSha,
        testReceiptSha,
        acceptedReviewSha,
        metadataWarnings: preflight.metadataWarnings ?? [],
        beforeReceiptWrite: () => assertFreshDeliveryAuthority(),
      });
    } catch (error) {
      if (
        !(error instanceof DeliveryVerificationError) ||
        !error.requirementId?.startsWith('delivery.verification.') ||
        initial.projection.matchingReceipt !== null ||
        liveIntent?.record.schema !== 'aitm.delivery-intent/v1'
      )
        throw error;
      return runGenericWaiver(error);
    }
  }
  if (initial.projection.matchingReceipt !== null) {
    throw deliverError('receipt-on-open-pr');
  }

  if (live?.record.expectedHeadSha === preflight.expectedHeadSha) {
    const expected = buildIntentFromPreflight({
      preflight,
      cfg,
      intentId: live.record.intentId,
      supersedesIntentId: live.record.supersedesIntentId,
      provider: live.record.provider,
      sessionId: live.record.sessionId,
      clientCreatedAt: live.record.clientCreatedAt,
    });
    if (authorizedIntentBytes(expected) !== authorizedIntentBytes(live.record)) {
      throw deliverError('intent-divergence');
    }
    await revalidateBeforeProviderAction(live.record);
    await assertFreshDeliveryAuthority();
    return {
      status: 'action-required',
      mode: 'current-head',
      intent: live.record,
      action: buildProviderAction(live.record),
    };
  }

  const intent = buildIntentFromPreflight({
    preflight,
    cfg,
    intentId: createIntentId(),
    supersedesIntentId: live?.record.intentId ?? null,
    provider: providerId(),
    sessionId: sessionId(),
    clientCreatedAt: now(),
  });
  await assertFreshDeliveryAuthority();
  const readbackIntent = await appendIntent({
    deps,
    issueNumber,
    repository: cfg.repo,
    context,
    intent,
  });
  await revalidateBeforeProviderAction(readbackIntent.record);
  await assertFreshDeliveryAuthority({ expectedLiveIntent: readbackIntent });

  return {
    status: 'action-required',
    mode: 'current-head',
    intent: readbackIntent.record,
    action: buildProviderAction(readbackIntent.record),
  };
}

function normalizeIssue(issue, projectState) {
  const body = String(issue?.body || '');
  return {
    number: Number(issue?.number),
    state: issue?.state,
    projectState: String(projectState || '').toLowerCase() === 'review' ? 'Review' : projectState,
    assignees: Array.isArray(issue?.assignees)
      ? issue.assignees.map(({ login }) => login).filter(Boolean)
      : [],
    agentReviewPassed: isAgentReviewComplete(body),
    body,
  };
}

function checkRollup(rollup, expectedHeadSha) {
  if (!Array.isArray(rollup)) return { readable: false, required: [] };
  return {
    readable: true,
    required: rollup.map((check) => {
      const state = String(check?.state || '').toUpperCase();
      return {
        name: String(check?.name || ''),
        headSha: expectedHeadSha,
        status: state === 'SUCCESS' ? 'COMPLETED' : state,
        conclusion: state,
      };
    }),
  };
}

export function resolveDeliveryProviderCapability(providerName, cfg) {
  if (cfg?.fullAutoMerge?.mechanism !== 'provider-action') return false;
  try {
    const capability = getProvider(providerName).externalActions?.['github.merge-pull-request'];
    return capability?.adapterContract === 'skill' && capability?.expectedHeadSha === true;
  } catch {
    return null;
  }
}

export function createDefaultDeliverDeps(ctx, { exec = pexec } = {}) {
  const run = async (command, args, options = {}) =>
    exec(command, args, {
      cwd: ctx.projectDir,
      encoding: 'utf8',
      timeout: command === 'git' ? GIT_TIMEOUT_MS : GH_API_TIMEOUT_MS,
      maxBuffer: 8 * 1024 * 1024,
      ...options,
    });
  const json = async (command, args, options) => {
    const { stdout } = await run(command, args, options);
    return JSON.parse(String(stdout || 'null'));
  };
  const requiredChecksJson = async (args) => {
    try {
      return await json('gh', args);
    } catch (error) {
      const exitCode = Number(error?.code);
      if (exitCode === 8 && typeof error?.stdout === 'string') {
        return JSON.parse(error.stdout);
      }
      const diagnostic = `${String(error?.stderr || '')}\n${String(error?.message || '')}`;
      if (
        exitCode === 1 &&
        /(?:^|\n)no required checks reported on the '[^'\r\n]+' branch(?:\r?\n|$)/i.test(diagnostic)
      ) {
        return [];
      }
      throw error;
    }
  };
  const { owner, repoName } = splitRepo(ctx.cfg.repo);
  const fetchCompletePullRequestCommits = async (prNumber, expectedHeadSha) => {
    const query = `query($owner:String!,$repo:String!,$pr:Int!,$cursor:String){repository(owner:$owner,name:$repo){pullRequest(number:$pr){headRefOid commits(first:100,after:$cursor){totalCount nodes{commit{oid messageHeadline message parents(first:100){totalCount nodes{oid} pageInfo{hasNextPage}} tree{oid}}} pageInfo{hasNextPage endCursor}}}}}`;
    const commits = [];
    const evidence = [];
    const seenCommitShas = new Set();
    const seenCursors = new Set();
    let cursor = null;
    let expectedTotal = null;
    for (;;) {
      const args = [
        'api',
        'graphql',
        '-f',
        `query=${query}`,
        '-f',
        `owner=${owner}`,
        '-f',
        `repo=${repoName}`,
        '-F',
        `pr=${prNumber}`,
      ];
      if (cursor !== null) args.push('-f', `cursor=${cursor}`);
      const payload = await json('gh', args);
      const pullRequest = payload?.data?.repository?.pullRequest;
      const connection = pullRequest?.commits;
      const totalCount = connection?.totalCount;
      const nodes = connection?.nodes;
      const pageInfo = connection?.pageInfo;
      if (
        !Number.isSafeInteger(totalCount) ||
        totalCount < 1 ||
        totalCount > MAX_PULL_REQUEST_SOURCE_COMMITS ||
        !Array.isArray(nodes) ||
        nodes.length > 100 ||
        typeof pageInfo?.hasNextPage !== 'boolean' ||
        !SHA_RE.test(expectedHeadSha || '') ||
        pullRequest?.headRefOid !== expectedHeadSha
      ) {
        throw deliverError('pull-request-commits');
      }
      if (expectedTotal === null) expectedTotal = totalCount;
      else if (expectedTotal !== totalCount) throw deliverError('pull-request-commits');
      for (const node of nodes) {
        const commit = node?.commit;
        const parents = commit?.parents;
        const parentNodes = parents?.nodes;
        const messageSubject =
          typeof commit?.message === 'string' ? commit.message.split(/\r?\n/, 1)[0] : '';
        if (
          !SHA_RE.test(commit?.oid || '') ||
          typeof commit?.messageHeadline !== 'string' ||
          commit.messageHeadline.length === 0 ||
          typeof commit?.message !== 'string' ||
          commit.message.length === 0 ||
          messageSubject.length === 0 ||
          !Number.isSafeInteger(parents?.totalCount) ||
          parents.totalCount < 0 ||
          parents.totalCount > 100 ||
          !Array.isArray(parentNodes) ||
          parentNodes.length !== parents.totalCount ||
          parents?.pageInfo?.hasNextPage !== false ||
          parentNodes.some((parent) => !SHA_RE.test(parent?.oid || '')) ||
          !SHA_RE.test(commit?.tree?.oid || '') ||
          seenCommitShas.has(commit.oid)
        ) {
          throw deliverError('pull-request-commits');
        }
        seenCommitShas.add(commit.oid);
        commits.push({ oid: commit.oid, messageHeadline: messageSubject });
        evidence.push({
          oid: commit.oid,
          message: commit.message,
          parents: parentNodes.map(({ oid }) => oid),
          tree: commit.tree.oid,
        });
      }
      if (commits.length > expectedTotal) throw deliverError('pull-request-commits');
      if (!pageInfo.hasNextPage) {
        if (commits.length !== expectedTotal || commits.at(-1)?.oid !== expectedHeadSha) {
          throw deliverError('pull-request-commits');
        }
        return { commits, evidence };
      }
      const nextCursor = pageInfo.endCursor;
      if (
        nodes.length === 0 ||
        typeof nextCursor !== 'string' ||
        nextCursor.length === 0 ||
        seenCursors.has(nextCursor)
      ) {
        throw deliverError('pull-request-commits');
      }
      seenCursors.add(nextCursor);
      cursor = nextCursor;
    }
  };
  const directoryEvidence = new Map();
  const resolveDirectoryEvidence = async ({ issue, issueNumber, expectedHeadSha }) => {
    const source = (ctx.locateAuthoritySource || locateAuthoritySource)({
      issueBody: issue.body,
    });
    if (source.kind !== 'github-records/v1') return null;
    const key = `${issueNumber}:${expectedHeadSha}`;
    if (!directoryEvidence.has(key)) {
      directoryEvidence.set(
        key,
        (ctx.resolveLifecycleEvidence || resolveLifecycleGateEvidence)({
          repository: ctx.cfg.repo,
          issue: Number(issueNumber),
          issueBody: issue.body,
          expectedSha: expectedHeadSha,
          graphql:
            ctx.graphql ||
            (({ query, variables }) => gql(query, variables).then((data) => ({ data }))),
          readContractRecord: ctx.readContractRecord,
          deps: ctx.listIssueRecords ? { listIssueRecords: ctx.listIssueRecords } : undefined,
        })
      );
    }
    return directoryEvidence.get(key);
  };
  const inspectCommitObject = async (commitSha) => {
    const { stdout } = await run('git', ['cat-file', 'commit', commitSha]);
    const raw = String(stdout || '');
    const separator = raw.indexOf('\n\n');
    if (separator < 0) throw deliverError('commit-object');
    const headers = raw.slice(0, separator).split('\n');
    const trees = headers
      .filter((line) => line.startsWith('tree '))
      .map((line) => line.slice('tree '.length));
    if (trees.length !== 1 || !SHA_RE.test(trees[0])) throw deliverError('commit-object');
    const message = raw.slice(separator + 2).replace(/\n$/, '');
    const [commitTitle, ...bodyLines] = message.split('\n');
    const commitMessage =
      bodyLines[0] === '' ? bodyLines.slice(1).join('\n') : bodyLines.join('\n');
    return {
      parents: headers
        .filter((line) => line.startsWith('parent '))
        .map((line) => line.slice('parent '.length)),
      tree: trees[0],
      commitTitle,
      commitMessage,
    };
  };

  const inspectLocalSourceCommit = async ({ commitSha, headSha }) => {
    const { stdout: localHead } = await run('git', ['rev-parse', 'HEAD']);
    const localHeadSha = String(localHead || '').trim();
    if (localHeadSha !== headSha) throw deliverError('source-head-mismatch');
    const { stdout } = await run('git', ['cat-file', 'commit', commitSha]);
    const raw = String(stdout || '');
    const separator = raw.indexOf('\n\n');
    if (separator < 0) throw deliverError('commit-object');
    const message = raw.slice(separator + 2);
    let reachable = false;
    try {
      await run('git', ['merge-base', '--is-ancestor', commitSha, 'HEAD']);
      reachable = true;
    } catch (error) {
      if (error?.code !== 1) throw error;
    }
    return { oid: commitSha, message, reachable, localHeadSha };
  };

  return {
    createDeliveryWaiverJournal({ repository, issue }) {
      return createDeliveryWaiverJournal({ cwd: ctx.projectDir, repository, issue });
    },
    resolveTranscriptPath(sessionId) {
      return jsonlPath(sessionId);
    },
    providerActionAvailable: resolveDeliveryProviderCapability(aiAppName(), ctx.cfg),
    async resolvePullRequestReviewGate() {
      return resolveGate('pullRequestReview', {
        session: (ctx.loadCurrentSession || (() => loadSession(currentSessionId())))(),
        projectConfig: (ctx.loadRawProjectConfig || rawProjectConfig)(),
      });
    },
    async resolveManualCodeReviewer({ configuredReviewer }) {
      const authenticatedLogin = await (async () => {
        const { stdout } = await run('gh', ['api', 'user', '--jq', '.login']);
        return String(stdout || '').trim();
      })();
      const reviewerLogin = resolveManualCodeReviewerPolicy({
        configuredReviewer,
        authenticatedLogin,
      });
      const account = await json('gh', ['api', `users/${encodeURIComponent(reviewerLogin)}`]);
      if (
        String(account?.login || '').toLowerCase() !== reviewerLogin.toLowerCase() ||
        account?.type !== 'User'
      ) {
        throw new TypeError(
          `manual-code-review:${account?.type === 'Bot' ? 'reviewer-bot' : 'reviewer-unresolved'}`
        );
      }
      return reviewerLogin;
    },
    async fetchManualCodeReviewEvidence({ prNumber, expectedHeadSha }) {
      const query = `query($owner:String!,$repo:String!,$pr:Int!){repository(owner:$owner,name:$repo){pullRequest(number:$pr){headRefOid author{login __typename} reviewRequests(first:100){nodes{requestedReviewer{__typename ... on User{login}}} pageInfo{hasNextPage}} reviews(first:100){nodes{author{login __typename} state submittedAt commit{oid}} pageInfo{hasNextPage}}}}}`;
      const payload = await json('gh', [
        'api',
        'graphql',
        '-f',
        `query=${query}`,
        '-f',
        `owner=${owner}`,
        '-f',
        `repo=${repoName}`,
        '-F',
        `pr=${prNumber}`,
      ]);
      const pr = payload?.data?.repository?.pullRequest;
      if (
        pr?.headRefOid !== expectedHeadSha ||
        pr?.reviewRequests?.pageInfo?.hasNextPage !== false ||
        pr?.reviews?.pageInfo?.hasNextPage !== false
      ) {
        return null;
      }
      return {
        number: Number(prNumber),
        author: {
          login: pr.author?.login,
          isBot: pr.author?.__typename === 'Bot',
        },
        reviewRequests: (pr.reviewRequests?.nodes ?? []).map(({ requestedReviewer }) => ({
          login: requestedReviewer?.login,
          isBot: requestedReviewer?.__typename === 'Bot',
        })),
        reviews: (pr.reviews?.nodes ?? []).map((review) => ({
          authorLogin: review?.author?.login,
          authorIsBot: review?.author?.__typename === 'Bot',
          state: review?.state,
          commitOid: review?.commit?.oid,
          submittedAt: review?.submittedAt,
        })),
      };
    },
    async requestPullRequestReview({ prNumber, reviewerLogin }) {
      await run('gh', [
        'api',
        '--method',
        'POST',
        `repos/${owner}/${repoName}/pulls/${prNumber}/requested_reviewers`,
        '-f',
        `reviewers[]=${reviewerLogin}`,
      ]);
    },
    async resolveReviewAuthorization({ issue, issueNumber, expectedHeadSha, acceptedReviewSha }) {
      const lifecycleEvidence = await resolveDirectoryEvidence({
        issue,
        issueNumber,
        expectedHeadSha,
      });
      const approval = parseReviewApprovedMarker(issue.body);
      const directoryLane = lifecycleEvidence !== null;
      return resolveReviewAuthorization({
        session: (ctx.loadCurrentSession || (() => loadSession(currentSessionId())))(),
        projectConfig: (ctx.loadRawProjectConfig || rawProjectConfig)(),
        acceptedHeadSha: acceptedReviewSha === expectedHeadSha ? expectedHeadSha : null,
        humanApprovalEvidence:
          directoryLane && hasAcceptedApprovalEvidence(lifecycleEvidence, { provenance: 'human' })
            ? {
                accepted: true,
                approvedSha: lifecycleEvidence.expectedSha,
                source: 'directory-human-evidence',
              }
            : !directoryLane && approval && !approval.fullAuto
              ? { accepted: true, approvedSha: approval.approvedSha }
              : null,
        fullAutoApprovalEvidence:
          directoryLane &&
          hasAcceptedApprovalEvidence(lifecycleEvidence, { provenance: 'full-auto' })
            ? { accepted: true, approvedSha: lifecycleEvidence.expectedSha }
            : !directoryLane && approval?.fullAuto
              ? { accepted: true, approvedSha: approval.approvedSha }
              : null,
      });
    },
    async fetchIssue({ issueNumber }) {
      const [issue, projectState] = await Promise.all([
        json('gh', [
          'issue',
          'view',
          String(issueNumber),
          '-R',
          ctx.cfg.repo,
          '--json',
          'number,state,body,assignees',
        ]),
        ctx.getIssueBoardState(issueNumber),
      ]);
      return normalizeIssue(issue, projectState);
    },
    async resolveLineage({ issueNumber }) {
      const parentIssueNumber = await fetchParentIssueStrict({
        issueNumber,
        repo: ctx.cfg.repo,
        deps: {
          gql: async (query, variables) => {
            const args = ['api', 'graphql', '-f', `query=${query}`];
            for (const [key, value] of Object.entries(variables)) {
              args.push(Number.isInteger(value) ? '-F' : '-f', `${key}=${value}`);
            }
            const payload = await json('gh', args);
            const issue = payload?.data?.repository?.issue;
            const parent = issue?.parent;
            if (
              payload?.errors ||
              !issue ||
              !Object.hasOwn(issue, 'parent') ||
              (parent !== null && (!Number.isSafeInteger(parent?.number) || parent.number <= 0))
            ) {
              throw deliverError('lineage');
            }
            return payload?.data;
          },
        },
      });
      return {
        parentIssueNumber,
        deliveryTarget:
          parentIssueNumber === null ? baseRefFrom(ctx.cfg) : `epic/${parentIssueNumber}`,
      };
    },
    async getCurrentBranch() {
      const { stdout } = await run('git', ['branch', '--show-current']);
      return String(stdout || '').trim();
    },
    async getLocalHeadSha() {
      const { stdout } = await run('git', ['rev-parse', 'HEAD']);
      return String(stdout || '').trim();
    },
    async resolveTestReceiptSha({ issue }) {
      return parseVerificationReceipt(issue.body, 'test')?.commitSha ?? null;
    },
    async resolveAcceptedReviewSha({ issue, issueNumber, expectedHeadSha }) {
      const lifecycleEvidence = await resolveDirectoryEvidence({
        issue,
        issueNumber,
        expectedHeadSha,
      });
      if (lifecycleEvidence) {
        return hasAcceptedReviewEvidence(lifecycleEvidence) ? lifecycleEvidence.expectedSha : null;
      }
      const reviewReceipt = parseVerificationReceipt(issue.body, 'review');
      if (reviewReceipt?.commitSha) return reviewReceipt.commitSha;
      if (!isAgentReviewComplete(issue.body)) return null;
      const markerSha = parseTestStartedMarker(issue.body)?.sha;
      return SHA_RE.test(markerSha || '') ? markerSha : null;
    },
    async resolveAgentReviewPassed({ issue, issueNumber, expectedHeadSha }) {
      const lifecycleEvidence = await resolveDirectoryEvidence({
        issue,
        issueNumber,
        expectedHeadSha,
      });
      return lifecycleEvidence
        ? hasAcceptedReviewEvidence(lifecycleEvidence)
        : isAgentReviewComplete(issue.body);
    },
    async listPullRequests({ headRef }) {
      return json('gh', [
        'pr',
        'list',
        '-R',
        ctx.cfg.repo,
        '--head',
        headRef,
        '--state',
        'all',
        '--json',
        'number',
      ]);
    },
    async fetchPullRequest({ prNumber }) {
      const pr = await json('gh', [
        'pr',
        'view',
        String(prNumber),
        '-R',
        ctx.cfg.repo,
        '--json',
        'number,state,isDraft,baseRefName,headRefName,headRefOid,headRepository,headRepositoryOwner,mergeable,mergedAt,mergeCommit',
      ]);
      const sourceHistory = await fetchCompletePullRequestCommits(prNumber, pr.headRefOid);
      pr.sourceCommits = sourceHistory.commits;
      pr.sourceCommitEvidence = sourceHistory.evidence;
      pr.sourceCommitSubjects = pr.sourceCommits.map(({ messageHeadline }) => messageHeadline);
      pr.sourceCommitsComplete = true;
      pr.sourceCommitsHeadSha = pr.headRefOid;
      pr.merged = String(pr.state || '').toUpperCase() === 'MERGED';
      if (pr.merged) {
        const mergedAt = normalizeGitHubInstant(pr.mergedAt);
        if (mergedAt === null) throw deliverError('pull-request-merged-at');
        pr.mergedAt = mergedAt;
      }
      pr.headRefDeleted = false;
      if (pr.merged && typeof pr.headRefName === 'string' && pr.headRefName.length > 0) {
        const headOwner = pr.headRepositoryOwner?.login || owner;
        const headRepo = pr.headRepository?.name || repoName;
        const encodedRef = pr.headRefName.split('/').map(encodeURIComponent).join('/');
        try {
          await run('gh', ['api', `repos/${headOwner}/${headRepo}/git/ref/heads/${encodedRef}`]);
        } catch (error) {
          if (!/\b404\b/.test(`${error?.message || ''}\n${error?.stderr || ''}`)) throw error;
          pr.headRefDeleted = true;
        }
      }
      return pr;
    },
    async fetchRequiredChecks({ prNumber, expectedHeadSha }) {
      const required = await requiredChecksJson([
        'pr',
        'checks',
        String(prNumber),
        '-R',
        ctx.cfg.repo,
        '--required',
        '--json',
        'name,state',
      ]);
      const head = await json('gh', [
        'pr',
        'view',
        String(prNumber),
        '-R',
        ctx.cfg.repo,
        '--json',
        'headRefOid',
      ]);
      const liveHeadSha = String(head?.headRefOid || '');
      if (Array.isArray(required) && required.length === 0 && liveHeadSha !== expectedHeadSha) {
        return { readable: false, required: [] };
      }
      return checkRollup(required, liveHeadSha);
    },
    async fetchRepositoryMergeMethods() {
      const repository = await json('gh', ['api', `repos/${owner}/${repoName}`]);
      return [
        repository.allow_merge_commit ? 'merge' : null,
        repository.allow_squash_merge ? 'squash' : null,
        repository.allow_rebase_merge ? 'rebase' : null,
      ].filter(Boolean);
    },
    async listCommitSubjects({ range }) {
      const { stdout } = await run('git', ['log', '--format=%s', range]);
      return String(stdout || '')
        .split('\n')
        .map((subject) => subject.trim())
        .filter(Boolean);
    },
    async listDirtyPaths() {
      const { stdout } = await run('git', ['status', '--porcelain']);
      return String(stdout || '')
        .split('\n')
        .map((line) => line.slice(3).trim())
        .filter(Boolean);
    },
    async listIssueComments({ issueNumber }) {
      const pages = await json('gh', [
        'api',
        '--paginate',
        '--slurp',
        `repos/${owner}/${repoName}/issues/${issueNumber}/comments`,
      ]);
      return (Array.isArray(pages) ? pages.flat() : []).map((comment) => {
        const createdAt = normalizeGitHubInstant(comment.created_at);
        const updatedAt = normalizeGitHubInstant(comment.updated_at);
        if (createdAt === null) throw deliverError('comment-created-at');
        if (updatedAt === null) throw deliverError('comment-updated-at');
        return {
          id: String(comment.id),
          createdAt,
          updatedAt,
          body: comment.body,
        };
      });
    },
    async createIssueComment({ issueNumber, body }) {
      return json('gh', [
        'api',
        '--method',
        'POST',
        `repos/${owner}/${repoName}/issues/${issueNumber}/comments`,
        '-f',
        `body=${body}`,
      ]);
    },
    async fetchOriginTrunk({ remote, branch }) {
      await run('git', ['fetch', remote, branch]);
    },
    async fetchRemoteTrunkHeadSha({ branch }) {
      if (
        typeof branch !== 'string' ||
        !/^[A-Za-z0-9._/-]+$/.test(branch) ||
        branch.includes('..')
      ) {
        throw deliverError('trunk-branch');
      }
      const { stdout } = await run('git', ['ls-remote', '--heads', 'origin', branch]);
      const line = String(stdout || '').trim();
      const match = line.match(
        new RegExp(`^([0-9a-f]{40})\\trefs/heads/${branch.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`)
      );
      if (!match) throw deliverError('remote-trunk-head');
      return match[1];
    },
    async resolveLocalTrunkHeadSha({ branch }) {
      if (
        typeof branch !== 'string' ||
        !/^[A-Za-z0-9._/-]+$/.test(branch) ||
        branch.includes('..')
      ) {
        throw deliverError('trunk-branch');
      }
      const { stdout } = await run('git', ['rev-parse', `refs/remotes/origin/${branch}`]);
      const sha = String(stdout || '').trim();
      if (!SHA_RE.test(sha)) throw deliverError('local-trunk-head');
      return sha;
    },
    async isAncestor({ ancestor, descendant }) {
      try {
        await run('git', ['merge-base', '--is-ancestor', ancestor, descendant]);
        return true;
      } catch (error) {
        if (error?.code === 1) return false;
        throw error;
      }
    },
    async inspectMergeCommit({ mergeCommitSha }) {
      return inspectCommitObject(mergeCommitSha);
    },
    async compareDeliveryContent({
      method,
      sourceBase,
      sourceHead,
      integrationBase,
      integrationHead,
    }) {
      if (
        ![sourceBase, sourceHead, integrationBase, integrationHead].every((value) =>
          SHA_RE.test(value)
        )
      ) {
        throw deliverError('integration-content-input');
      }
      // Git's virtual merge computes the tree obtained by applying the complete
      // accepted source onto the observed integration base. Comparing trees
      // proves content even when trunk advanced in unrelated files.
      if (!['merge', 'squash', 'rebase-step', 'rebase-total'].includes(method)) {
        throw deliverError('integration-content-method');
      }
      if (method !== 'rebase-step') {
        try {
          await run('git', ['merge-base', '--is-ancestor', sourceBase, integrationBase]);
        } catch (error) {
          if (Number(error?.code) === 1) return false;
          throw deliverError('integration-content-ancestry', error);
        }
      }
      let expectedTree;
      try {
        const { stdout } = await run('git', [
          'merge-tree',
          '--write-tree',
          '--merge-base',
          sourceBase,
          integrationBase,
          sourceHead,
        ]);
        expectedTree = String(stdout || '').trim();
      } catch (error) {
        if (Number(error?.code) === 1) return false;
        throw deliverError('integration-content-merge', error);
      }
      if (!SHA_RE.test(expectedTree)) throw deliverError('integration-content-tree');
      const observed = await inspectCommitObject(integrationHead);
      return observed.tree === expectedTree;
    },
    async inspectSourceCommit({ commitSha }) {
      return inspectCommitObject(commitSha);
    },
    inspectLocalSourceCommit,
    async attributingCommits(issueNumber, options) {
      return defaultAttributingCommits(issueNumber, { cwd: ctx.projectDir, ...options });
    },
    async getAuthenticatedLogin() {
      const { stdout } = await run('gh', ['api', 'user', '--jq', '.login']);
      return String(stdout || '').trim();
    },
    now: () => new Date().toISOString(),
    createIntentId: () => createRecordId(),
    providerId: () => aiAppName(),
    sessionId: () => currentSessionId(),
  };
}

export async function verbDeliver(ctx, injected = {}) {
  const issueNumber = issueTarget(ctx.rest);
  const setExitCode = injected.setExitCode ?? ((code) => (process.exitCode = code));
  const writeOutput = injected.writeOutput ?? ((line) => console.log(line));
  if (issueNumber === null) {
    writeOutput('Usage: /task deliver #N');
    setExitCode(2);
    return;
  }
  const state = (injected.loadTrackerState ?? loadState)(ctx.statePath);
  let reconcile = null;
  try {
    const parsed = parseReconcileArgs(ctx.rest);
    // #1562 — the operator identity on the record is the authenticated GitHub
    // login, never anything the flags can assert.
    reconcile = parsed === null ? null : { ...parsed, operator: ctx.cfg?.assignee ?? '' };
  } catch (error) {
    writeOutput(`deliver: ${error.message}`);
    setExitCode(2);
    return;
  }
  const result = await runDeliver({
    issueNumber,
    cfg: ctx.cfg,
    state,
    reconcile,
    deps: injected.deliverDeps ?? createDefaultDeliverDeps(ctx),
  });
  if (result.status === 'action-required') {
    writeOutput(serializeProviderActionRequired(result.action));
    setExitCode(20);
    return result;
  }
  if (result.status === 'manual-review-required') {
    writeOutput(
      `PROMPT_REQUIRED: manual-code-review #${issueNumber} pr=${result.prNumber} reviewer=${result.reviewerLogin} head=${result.expectedHeadSha}`
    );
    setExitCode(21);
    return result;
  }
  writeOutput(`AITM_DELIVERY_RESULT: ${canonicalRecordJson(result)}`);
  return result;
}
