// scripts/task-tracker/activity-policy.mjs
//
// Pure classifier for "activity classes" used by the activity-guard hook
// (epic #61, W2.2). Decides whether a tool invocation is WRITE_CODE,
// WRITE_DOCS, WRITE_ISSUE, COMMIT_CODE, RUN_TESTS, RUN_BUILD, READ_*, or
// WRITE_OTHER, based on path globs and command patterns from a policy file.
//
// Exports:
//   DEFAULT_POLICY   — shipped defaults, mirrored in `.ai-task-manager/activity-policy.json`.
//   STATE_MATRIX     — kanban state → array of allowed activity classes.
//   classifyEdit(filePath, policy?)  → string activity class.
//   classifyBash(command,  policy?)  → string activity class.
//   isAllowed(state, activityClass)  → boolean.
//   loadPolicy(cwd)                  → policy object (file or fallback).
//
// Pure module: classifiers do no I/O. `loadPolicy` reads the filesystem once
// per call and falls back to defaults on missing/invalid file.
//
// Git mutation discovery is shared with the hook consumers by #1830.
// Broader shell write-target extraction (redirect / tee / heredoc /
// touch|mkdir|rm) remains deferred under Epic W2 (#67).

import { readFileSync } from 'node:fs';
import path from 'node:path';
import { splitCommandSegments } from './lib/gh-edit-guard.mjs';
import { discoverBashActivity, inspectQuotedHeredocs } from './lib/mutation-context.mjs';

// ---------------------------------------------------------------------------
// Defaults
// ---------------------------------------------------------------------------

export const DEFAULT_POLICY = Object.freeze({
  codeGlobs: ['src/**', 'lib/**', 'bin/**', 'scripts/**'],
  codeGlobExcludes: [],
  codeGlobReincludes: [],
  docGlobs: ['docs/**', '.claude/plans/**', 'docs/plans/**', '**/*.md', 'CLAUDE.md'],
  // Repo-root and tooling config files that ARE part of the project's code
  // surface (ignore lists, formatter/linter configs, TS/JS configs, package
  // manifests, Claude/editor settings). Without these, every edit to
  // `.gitignore`, `package.json`, `eslint.config.*`, etc. classifies as
  // WRITE_OTHER — which no kanban state permits, locking out routine
  // config maintenance under any active task. Classified as WRITE_CODE.
  configGlobs: [
    '.gitignore',
    '.prettierignore',
    '.eslintignore',
    '.editorconfig',
    '.npmrc',
    '.nvmrc',
    '.node-version',
    '.markdownlintignore',
    'eslint.config.*',
    'prettier.config.*',
    '.prettierrc',
    '.prettierrc.*',
    'cspell.json',
    'cspell.config.*',
    'tsconfig.json',
    'tsconfig.*.json',
    'jsconfig.json',
    'jsconfig.*.json',
    'package.json',
    'package-lock.json',
    'pnpm-lock.yaml',
    'yarn.lock',
    'markdownlint.json',
    'markdownlint.*.json',
    '.markdownlint.json',
    '.markdownlint.*.json',
    '.markdownlint-cli2.jsonc',
    '.markdownlint-cli2.*',
    '.claude/settings.json',
    '.claude/settings.*.json',
    // The activity-policy file itself is part of the project's config surface.
    // Without this, editing it classifies as WRITE_OTHER (permitted in no
    // state), so the very first policy edit needs a chore-mode escape hatch.
    '.ai-task-manager/activity-policy.json',
  ],
  // Repo-root container / deployment files that ARE a first-class code
  // deliverable when shipping an image (Dockerfiles, compose stacks, the
  // container web-server config). They live at repo root, so they match no
  // `src/**`/`scripts/**` code glob and none of the tooling `configGlobs` —
  // without this list every such edit falls through to WRITE_OTHER (permitted
  // in no kanban state), blocking a legitimate `develop`-stage build file.
  // Classified as WRITE_CODE. See DEFAULT_POLICY.configGlobs for the sibling
  // pattern this mirrors (#712).
  deployGlobs: [
    'Dockerfile',
    'Dockerfile.*',
    '*.dockerfile',
    '.dockerignore',
    'Containerfile',
    'compose.y*ml',
    'docker-compose.y*ml',
    'nginx.conf',
  ],
  testRunners: ['npm test', 'npm run test', 'node --test', 'pytest', 'cargo test', 'go test'],
  buildCommands: ['npm run build', 'tsc', 'cargo build', 'go build'],
});

export const DRAFTING_STATES = Object.freeze(['backlog', 'refine', 'ready-for-plan', 'plan']);

export const STATE_MATRIX = Object.freeze({
  backlog: ['WRITE_ISSUE', 'WRITE_DOCS', 'COMMIT_DOCS', 'READ_*'],
  refine: ['WRITE_ISSUE', 'WRITE_DOCS', 'COMMIT_DOCS', 'READ_*'],
  'ready-for-plan': ['WRITE_ISSUE', 'WRITE_DOCS', 'COMMIT_DOCS', 'READ_*'],
  plan: ['WRITE_ISSUE', 'WRITE_DOCS', 'COMMIT_DOCS', 'RUN_TESTS', 'READ_*'],
  develop: [
    'WRITE_CODE',
    'COMMIT_CODE',
    'COMMIT_DOCS',
    'WRITE_DOCS',
    'WRITE_ISSUE',
    'RUN_TESTS',
    'RUN_BUILD',
    'READ_*',
  ],
  test: ['RUN_TESTS', 'RUN_BUILD', 'WRITE_ISSUE', 'READ_*'],
  review: ['WRITE_ISSUE', 'WRITE_DOCS', 'READ_*'],
  done: ['READ_*'],
});

// ---------------------------------------------------------------------------
// Glob → RegExp
// ---------------------------------------------------------------------------

// Minimal glob compiler: supports `**` (any segments incl. zero), `*` (any
// chars except `/`), and literal `/`. No `?` or character classes — not used
// by the shipped policy. Sufficient for the documented globs.
function globToRegExp(glob) {
  // Normalize: strip leading `./`.
  const g = glob.replace(/^\.\//, '');
  let re = '';
  let i = 0;
  while (i < g.length) {
    const c = g[i];
    if (c === '*' && g[i + 1] === '*') {
      // `**/` matches any number of path segments incl. zero;
      // `**`   at end matches anything.
      if (g[i + 2] === '/') {
        re += '(?:.*/)?';
        i += 3;
      } else {
        re += '.*';
        i += 2;
      }
    } else if (c === '*') {
      re += '[^/]*';
      i += 1;
    } else if ('.+^$()|[]{}\\'.includes(c)) {
      re += '\\' + c;
      i += 1;
    } else {
      re += c;
      i += 1;
    }
  }
  return new RegExp('^' + re + '$');
}

function anyGlobMatch(filePath, globs) {
  if (!Array.isArray(globs)) return false;
  for (const g of globs) {
    if (globToRegExp(g).test(filePath)) return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
// classifyEdit
// ---------------------------------------------------------------------------

const ISSUE_TEMPLATE_RE = /^\.github\/ISSUE_TEMPLATE\//;

export function classifyEdit(filePath, policy = DEFAULT_POLICY) {
  if (typeof filePath !== 'string' || !filePath) return 'WRITE_OTHER';
  // Normalize: collapse leading `./`, no other transforms (caller passes
  // repo-relative paths).
  const p = filePath.replace(/^\.\//, '');

  // Issue templates take precedence over docs (they happen to be .md too).
  if (ISSUE_TEMPLATE_RE.test(p)) return 'WRITE_ISSUE';

  // Docs precede code so `scripts/foo.md` (matches both code-glob `scripts/**`
  // and doc-glob `**/*.md`) classifies as WRITE_DOCS.
  if (anyGlobMatch(p, policy.docGlobs)) return 'WRITE_DOCS';

  // Repo-root / tooling config files (e.g. `.gitignore`, `package.json`,
  // `eslint.config.*`) classify as WRITE_CODE so they remain editable under
  // any state that permits WRITE_CODE. Checked AFTER docs so `*.md` configs
  // still go to docs, and BEFORE code so bare-root configs don't fall
  // through to WRITE_OTHER. See DEFAULT_POLICY.configGlobs for the list.
  if (anyGlobMatch(p, policy.configGlobs)) return 'WRITE_CODE';

  // Repo-root container / deployment files (e.g. `Dockerfile`, `.dockerignore`,
  // `compose.yaml`, `nginx.conf`) classify as WRITE_CODE so a container image
  // is a first-class deliverable in `develop`. Checked AFTER docs (so a
  // `Dockerfile.md` note still goes to docs) and alongside config, BEFORE the
  // code globs. See DEFAULT_POLICY.deployGlobs for the list.
  if (anyGlobMatch(p, policy.deployGlobs)) return 'WRITE_CODE';

  if (anyGlobMatch(p, policy.codeGlobs)) {
    if (anyGlobMatch(p, policy.codeGlobExcludes)) {
      // Re-include carve-outs (e.g., tests under excluded runtime paths).
      if (anyGlobMatch(p, policy.codeGlobReincludes)) return 'WRITE_CODE';
      return 'WRITE_OTHER';
    }
    return 'WRITE_CODE';
  }

  return 'WRITE_OTHER';
}

// ---------------------------------------------------------------------------
// classifyBash — command prefix / write-target extraction
// ---------------------------------------------------------------------------

// Command-prefix match: command line starts with `pattern` followed by a
// word boundary (space, end-of-string, or `-`/`-`-flag). Matches the
// `npm test`, `npm run build`, `tsc`, etc. style entries in the policy.
function startsWithCommand(command, pattern) {
  const trimmed = command.replace(/^\s+/, '');
  if (!trimmed.startsWith(pattern)) return false;
  const next = trimmed.charAt(pattern.length);
  // Boundary: end-of-string, whitespace, semicolon, ampersand, pipe.
  return next === '' || /\s|;|&|\|/.test(next);
}

// Extract write targets from a bash command line. Mirrors `bash-guard.mjs`
// patterns (`redirectRe`, `teeRe`, `writeCommandRe`) but accepts relative
// paths as well as absolute. Returns an array of target path strings.
// Replace any single- or double-quoted substring with same-length spaces so
// downstream regexes don't match shell metacharacters that appear inside
// quoted arguments (e.g. `<pkg-version>` in a `/task check` label string,
// which would otherwise look like a redirect). Preserves byte offsets and
// keeps the rest of the command structure intact.
function stripQuotedRegions(command) {
  let out = '';
  let i = 0;
  while (i < command.length) {
    const c = command[i];
    if (c === "'" || c === '"') {
      const quote = c;
      out += ' ';
      i += 1;
      while (i < command.length && command[i] !== quote) {
        out += ' ';
        i += 1;
      }
      if (i < command.length) {
        out += ' ';
        i += 1;
      }
    } else {
      out += c;
      i += 1;
    }
  }
  return out;
}

export function extractWriteTargets(command) {
  const targets = new Set();
  const scanned = stripQuotedRegions(inspectQuotedHeredocs(command).source);

  // Redirections: `> path` or `>> path` (not `>&`, not `2>`).
  const redirectRe = /(?<![0-9&])>>?\s*([^\s;|&<>]+)/g;
  for (const [, p] of scanned.matchAll(redirectRe)) targets.add(p);

  // `tee [-a] path`
  const teeRe = /\btee\s+(?:-a\s+)?([^\s;|&<>]+)/g;
  for (const [, p] of scanned.matchAll(teeRe)) targets.add(p);

  // `touch|mkdir|rmdir|rm` — first non-flag argument is the target. Supports
  // multiple flags before the path (e.g., `mkdir -p`).
  const writeCommandRe = /\b(?:touch|mkdir|rmdir|rm)\s+((?:-[^\s]+\s+)*)([^\s;|&<>]+)/g;
  for (const m of scanned.matchAll(writeCommandRe)) targets.add(m[2]);

  return [...targets];
}

// @story #1848
// Closed shell forms: incidental scratch paths never authorize other effects.
export function scratchShellTargets(command) {
  if (typeof command !== 'string') return null;
  const target = '(?:\\.scratch|\\.tmp)(?:/[A-Za-z0-9_-]+(?:\\.[A-Za-z0-9_-]+)*)*';
  const heredoc = command.match(
    new RegExp(
      '^\\s*cat\\s*>\\s*(' + target + ")\\s*<<'([A-Za-z_][A-Za-z0-9_]*)'\\n([\\s\\S]*)\\n\\2\\s*$"
    )
  );
  if (heredoc) {
    if (heredoc[3].split('\n').includes(heredoc[2])) return null;
    return [heredoc[1]];
  }
  const mkdir = command.match(
    new RegExp('^\\s*mkdir\\s+(?:-p\\s+)?(' + target + '(?:\\s+' + target + ')*)\\s*$')
  );
  if (mkdir) return mkdir[1].trim().split(/\s+/);
  const echo = command.match(
    new RegExp("^\\s*echo\\s+(?:[A-Za-z0-9_ .-]+|'[^'\\n]*')\\s*>>?\\s*(" + target + ')\\s*$')
  );
  return echo ? [echo[1]] : null;
}

export function classifyBash(command, policy = DEFAULT_POLICY) {
  if (typeof command !== 'string' || !command) return 'READ_*';
  const cmd = command.replace(/^\s+/, '');
  if (scratchShellTargets(cmd)) return 'WRITE_SCRATCH';

  // A compound command may stage a document after writing source. Inspect all
  // shell write targets before granting the narrower Git or runner activity.
  // Every output redirect must expose one literal target to containment checks.
  // Quoted targets, descriptor writes, and descriptor duplication fail closed.
  const redirectSource = inspectQuotedHeredocs(cmd).source;
  const scanned = stripQuotedRegions(redirectSource);
  for (const match of scanned.matchAll(/>+/g)) {
    if (
      /[0-9&]/.test(scanned.charAt(match.index - 1)) ||
      !/^>>?\s*[A-Za-z0-9_./-]+(?=\s|$|[;|&])/.test(redirectSource.slice(match.index))
    )
      return 'WRITE_CODE';
  }
  for (const segment of splitCommandSegments(inspectQuotedHeredocs(cmd).source)) {
    if (
      /^\s*(?:tee|touch|mkdir|rmdir|rm)\b/.test(segment) &&
      !/^\s*(?:tee|touch|mkdir|rmdir|rm)\s+(?:-[A-Za-z]+\s+)*[A-Za-z0-9_./-]+\s*$/.test(segment)
    )
      return 'WRITE_CODE';
  }
  const targets = extractWriteTargets(cmd);
  let writeActivity = null;
  for (const target of targets) {
    const activity = classifyEdit(target, policy);
    if (activity === 'WRITE_CODE') {
      writeActivity = activity;
      break;
    }
    if (
      activity === 'WRITE_ISSUE' ||
      (activity === 'WRITE_DOCS' && writeActivity !== 'WRITE_ISSUE')
    ) {
      writeActivity = activity;
    } else if (!writeActivity) writeActivity = activity;
  }
  const gitActivity = discoverBashActivity(cmd, process.cwd());
  if (gitActivity === 'COMMIT_CODE') return gitActivity;
  if (inspectQuotedHeredocs(cmd).executable) return 'WRITE_CODE';
  if (writeActivity === 'WRITE_CODE') return writeActivity;
  if (gitActivity === 'WRITE_CODE') return gitActivity;
  if (writeActivity === 'WRITE_ISSUE') return writeActivity;

  const segments = splitCommandSegments(inspectQuotedHeredocs(cmd).source).filter((segment) =>
    segment.trim()
  );
  if (
    (writeActivity === 'WRITE_DOCS' || (gitActivity === 'WRITE_DOCS' && segments.length > 1)) &&
    segments.some((segment) => {
      if (
        [...(policy.testRunners || []), ...(policy.buildCommands || [])].some((pattern) =>
          startsWithCommand(segment, pattern)
        )
      )
        return false;
      if (/^\s*(?:cat|echo|printf)\b/.test(segment) && !/[$`|&()]/.test(segment)) return false;
      if (/^\s*(?:tee|touch|mkdir|rmdir|rm)\s+(?:-[A-Za-z]+\s+)*[A-Za-z0-9_./-]+\s*$/.test(segment))
        return false;
      return true;
    })
  )
    return 'WRITE_CODE';
  // Build commands.
  const buildCommands = [...(policy.buildCommands || [])].sort((a, b) => b.length - a.length);
  for (const pat of buildCommands) {
    if (segments.some((segment) => startsWithCommand(segment, pat))) return 'RUN_BUILD';
  }

  // Test runners — longest-first so `npm run test` wins over `npm`.
  const testRunners = [...(policy.testRunners || [])].sort((a, b) => b.length - a.length);
  for (const pat of testRunners) {
    if (segments.some((segment) => startsWithCommand(segment, pat))) return 'RUN_TESTS';
  }

  if (gitActivity) return gitActivity;
  if (writeActivity) return writeActivity;

  return 'READ_*';
}

// ---------------------------------------------------------------------------
// isAllowed
// ---------------------------------------------------------------------------

export function isAllowed(state, activityClass) {
  // READ_* is universally allowed.
  if (activityClass === 'READ_*' || activityClass === 'WRITE_SCRATCH') return true;

  // No-active-task policy: refuse WRITE_CODE / COMMIT_CODE; allow all else.
  if (state == null) {
    if (
      activityClass === 'WRITE_CODE' ||
      activityClass === 'COMMIT_CODE' ||
      activityClass === 'COMMIT_DOCS'
    )
      return false;
    return true;
  }

  const allowed = STATE_MATRIX[state];
  if (!Array.isArray(allowed)) return false;
  return allowed.includes(activityClass);
}

// ---------------------------------------------------------------------------
// loadPolicy
// ---------------------------------------------------------------------------

export function loadPolicy(cwd) {
  if (typeof cwd !== 'string' || !cwd) return DEFAULT_POLICY;
  const filePath = path.join(cwd, '.ai-task-manager', 'activity-policy.json');
  let raw;
  try {
    raw = readFileSync(filePath, 'utf8');
  } catch {
    return DEFAULT_POLICY;
  }
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return DEFAULT_POLICY;
    // Per-key base merge: a list-valued key present in the file fully REPLACES
    // the corresponding default; absent keys keep the default. The additive
    // `*Extra` siblings (`codeGlobsExtra` / `docGlobsExtra` / `configGlobsExtra`)
    // are then APPENDED onto whichever base list is in effect, so a project can
    // widen a glob set without restating the (version-drifting) defaults.
    // Non-array `*Extra` values are ignored. Base first, extras after — the
    // `classifyEdit` precedence is unchanged; extras only broaden membership.
    const withExtra = (baseKey, extraKey) => {
      const base = Array.isArray(parsed[baseKey]) ? parsed[baseKey] : DEFAULT_POLICY[baseKey];
      const extra = Array.isArray(parsed[extraKey]) ? parsed[extraKey] : [];
      return extra.length ? [...base, ...extra] : base;
    };
    return {
      codeGlobs: withExtra('codeGlobs', 'codeGlobsExtra'),
      codeGlobExcludes: Array.isArray(parsed.codeGlobExcludes)
        ? parsed.codeGlobExcludes
        : DEFAULT_POLICY.codeGlobExcludes,
      codeGlobReincludes: Array.isArray(parsed.codeGlobReincludes)
        ? parsed.codeGlobReincludes
        : DEFAULT_POLICY.codeGlobReincludes,
      docGlobs: withExtra('docGlobs', 'docGlobsExtra'),
      configGlobs: withExtra('configGlobs', 'configGlobsExtra'),
      deployGlobs: withExtra('deployGlobs', 'deployGlobsExtra'),
      testRunners: Array.isArray(parsed.testRunners)
        ? parsed.testRunners
        : DEFAULT_POLICY.testRunners,
      buildCommands: Array.isArray(parsed.buildCommands)
        ? parsed.buildCommands
        : DEFAULT_POLICY.buildCommands,
    };
  } catch {
    return DEFAULT_POLICY;
  }
}
