#!/usr/bin/env node
import { enforceDirectGuidance } from './lib/direct-guidance-admission.mjs';
enforceDirectGuidance(import.meta.url, 'heal-functional-dod');
// #403 — Detect + heal issues whose Functional DoD section predates the keyed
// template (#303). Such issues carry the five Functional checkbox lines but
// without their `dod:functional:KEY` markers, so `parseFunctionalDodKeys`
// yields fewer than five keys. Every verb that keys off those markers then
// silently degrades (proof gate refuses to tick, `dod-stamp` finds no line,
// the test-time auto-tick skips, `review.mjs` cannot derive the derived keys),
// leaving the Test→Review checkbox gate unsatisfiable through the normal chain.
//
// This module provides:
//   - detectMissingKeys(body): which of the five canonical keys are absent.
//   - healFunctionalSection(body): rewrite the Functional section to the
//     canonical keyed template, preserving tick state + any recorded evidence.
//
// CLI:
//   node scripts/task-tracker/heal-functional-dod.mjs [--state open|closed|all]
//                                                     [--apply]
//                                                     [--scope 241,242,...]
//
// Default: --state open, dry-run (no writes). `--apply` is the only switch that
// writes; every write routes through `mutateIssueBody`.

import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

import { loadConfig } from './config.mjs';
import { locateFunctionalSection } from './lib/lifecycle-dod.mjs';
import { parseFunctionalDodKeys } from './lib/functional-dod-evidence.mjs';
import { mutateIssueBody } from './lib/issue-body-mutate.mjs';
import { gql, splitRepo } from '../gh/lib/github-projects.mjs';
import { assertKnownArgv, reportStrictArgvError } from './lib/argv-strict.mjs';
import { confirmBlastRadius } from './lib/blast-radius-guard.mjs';
import { wantsHelp, emitSelfDoc } from '../lib/self-doc.mjs';

if (import.meta.url === `file://${process.argv[1]}` && wantsHelp(process.argv.slice(2))) {
  emitSelfDoc('heal-functional-dod');
  process.exit(0);
}

const pexec = promisify(execFile);

// Canonical Functional DoD keys, in canonical render order.
export const CANONICAL_KEYS = Object.freeze(['tests', 'lint', 'commits', 'acs', 'checkboxes']);

// Canonical line text per key (everything after `- [x] ` / `- [ ] `). Mirrors
// templates/definition-of-done.md exactly.
const CANONICAL_LINE = Object.freeze({
  // #934 — two lane commands (`npm test` + `npm run test:slow`), each a separate
  // verifier under its own runner budget, replace the single `npm run test:all`
  // whose ~530–690s wall-time now exceeds the 600s per-command cap.
  tests:
    'All automated tests pass <!-- aitm-verified cmd="`npm test` `npm run test:slow`" --> <!-- dod:functional:tests -->',
  lint: 'Lint and format checks pass <!-- aitm-verified cmd="`npm run lint` `npm run format:check`" --> <!-- dod:functional:lint -->',
  commits:
    'All changes committed; commit messages follow project convention <!-- aitm-verified cmd="`git log --oneline -1`" --> <!-- dod:functional:commits -->',
  acs: 'Acceptance criteria met (including additions from deep dive) <!-- dod:functional:acs -->',
  checkboxes: 'Issue body checkboxes ticked <!-- dod:functional:checkboxes -->',
});

const BOX_RE = /^(\s*)- \[([ x])\]\s+(.+)$/;
const KEY_MARKER_RE = /<!--\s*dod:functional:([a-z0-9-]+)\s*-->/i;
// Execution-proof evidence marker, either grammar (legacy colon or consolidated
// property form). Distinct from the verifier DECLARATION the template supplies.
const EVIDENCE_ANY_RE = /<!--\s*aitm-dod-evidence(?::[a-z0-9-]+)?\s[\s\S]*?-->/i;

// Classify a stale (unkeyed) Functional line to a canonical key by its label
// text. lint is matched before tests so a line mentioning both resolves to the
// more specific key; in practice the five labels are disjoint.
export function classifyLabel(text) {
  const t = String(text || '').toLowerCase();
  if (/\blint\b|format/.test(t)) return 'lint';
  if (/test/.test(t)) return 'tests';
  if (/commit/.test(t)) return 'commits';
  if (/acceptance|criteria/.test(t)) return 'acs';
  if (/checkbox/.test(t)) return 'checkboxes';
  return null;
}

// Report which canonical keys the body's Functional section is missing.
// Returns { sectionPresent, presentKeys, missingKeys, affected }.
//   - sectionPresent: a `#### Functional` heading exists.
//   - affected: sectionPresent AND at least one canonical key is missing.
// A fully-keyed (canonical) issue reports missingKeys=[] and affected=false,
// which is the idempotency guarantee — such issues are never healed.
export function detectMissingKeys(body) {
  const loc = locateFunctionalSection(body);
  if (!loc) {
    return {
      sectionPresent: false,
      presentKeys: [],
      missingKeys: [...CANONICAL_KEYS],
      affected: false,
    };
  }
  const present = new Set(parseFunctionalDodKeys(body).map((it) => it.key));
  const presentKeys = CANONICAL_KEYS.filter((k) => present.has(k));
  const missingKeys = CANONICAL_KEYS.filter((k) => !present.has(k));
  return {
    sectionPresent: true,
    presentKeys,
    missingKeys,
    affected: missingKeys.length > 0,
  };
}

// Extract the per-key facts worth preserving from the existing Functional
// section: tick state and any recorded execution-proof marker. Classifies each
// checkbox line authoritative-marker-first (an existing `dod:functional:KEY`
// wins), falling back to label-text keyword classification.
function collectExisting(sectionText) {
  const byKey = new Map();
  for (const raw of String(sectionText || '').split('\n')) {
    const box = raw.match(BOX_RE);
    if (!box) continue;
    const checked = box[2] === 'x';
    const rest = box[3];
    const km = rest.match(KEY_MARKER_RE);
    const key = km ? km[1].toLowerCase() : classifyLabel(rest);
    if (!key || !CANONICAL_KEYS.includes(key)) continue;
    if (byKey.has(key)) continue; // first occurrence wins
    const ev = rest.match(EVIDENCE_ANY_RE);
    byKey.set(key, { checked, evidence: ev ? ev[0] : null });
  }
  return byKey;
}

// Rewrite the body's Functional section to the canonical keyed template,
// preserving tick state and any recorded evidence marker. Returns
// { body, changed }. No-op (changed=false) when the rebuilt section is
// byte-identical to the input.
export function healFunctionalSection(body) {
  const src = String(body || '');
  const loc = locateFunctionalSection(src);
  if (!loc) return { body: src, changed: false };

  const existing = collectExisting(loc.section);
  const lines = CANONICAL_KEYS.map((key) => {
    const prev = existing.get(key);
    const mark = prev && prev.checked ? 'x' : ' ';
    let line = `- [${mark}] ${CANONICAL_LINE[key]}`;
    if (prev && prev.evidence) line += ` ${prev.evidence}`;
    return line;
  });

  const newSection = `\n\n${lines.join('\n')}\n\n`;
  const next = loc.before + newSection + loc.after;
  return { body: next, changed: next !== src };
}

// ----- Orchestrator (CLI entry) -----

// Parse CLI flags. I/O + termination are injectable (`io.out`/`io.err`/
// `io.exit`) so the flag-routing branches (`--help`, invalid `--state`) are
// exercisable offline; every hook defaults to the real process stream/exit,
// keeping the CLI runtime path byte-identical.
export function parseArgs(argv, io = {}) {
  const out = io.out || process.stdout;
  const err = io.err || process.stderr;
  const exit = io.exit || ((code) => process.exit(code));
  const args = { state: 'open', apply: false, scope: null, yes: false };

  // #878 — refuse unknown flags before interpreting anything.
  try {
    assertKnownArgv(argv, { flags: ['--apply', '--yes'], options: ['--state', '--scope'] });
  } catch (e) {
    if (!reportStrictArgvError(e, { err: (s) => err.write(s) })) throw e;
    printUsage(err);
    exit(2);
    return args;
  }

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--apply') args.apply = true;
    else if (a === '--yes') args.yes = true;
    else if (a === '--state') args.state = argv[++i];
    else if (a.startsWith('--state=')) args.state = a.slice('--state='.length);
    else if (a === '--scope')
      args.scope = argv[++i]
        .split(',')
        .map((s) => Number(s.replace(/^#/, '')))
        .filter(Number.isFinite);
    else if (a.startsWith('--scope='))
      args.scope = a
        .slice('--scope='.length)
        .split(',')
        .map((s) => Number(s.replace(/^#/, '')))
        .filter(Number.isFinite);
    else if (a === '--help' || a === '-h') {
      printUsage(out);
      exit(0);
      return args;
    }
  }
  if (!['open', 'closed', 'all'].includes(args.state)) {
    err.write(`heal-functional-dod: invalid --state ${args.state}\n`);
    exit(2);
    return args;
  }
  return args;
}

export function printUsage(out = process.stdout) {
  out.write(
    'Usage: heal-functional-dod.mjs [--state open|closed|all] [--apply] [--scope N,N,...] [--yes]\n' +
      '  --yes  skip the blast-radius confirmation prompt on a multi-issue --apply\n'
  );
}

export async function fetchAllIssueNumbers({ repo, state, projectId }, gqlFn = gql) {
  const { owner, repoName } = splitRepo(repo);
  const numbers = [];
  let cursor = null;
  for (let page = 0; page < 50; page++) {
    const data = await gqlFn(
      `
      query($owner: String!, $repo: String!, $cursor: String) {
        repository(owner: $owner, name: $repo) {
          issues(first: 100, after: $cursor, states: [OPEN, CLOSED], orderBy: {field: CREATED_AT, direction: ASC}) {
            pageInfo { hasNextPage endCursor }
            nodes {
              number
              state
              projectItems(first: 5) { nodes { project { id } } }
            }
          }
        }
      }
    `,
      { owner, repo: repoName, cursor }
    );
    const issues = data.repository.issues.nodes;
    for (const i of issues) {
      const onProject = i.projectItems.nodes.some((n) => n.project?.id === projectId);
      if (!onProject) continue;
      if (state === 'open' && i.state !== 'OPEN') continue;
      if (state === 'closed' && i.state !== 'CLOSED') continue;
      numbers.push(i.number);
    }
    if (!data.repository.issues.pageInfo.hasNextPage) break;
    cursor = data.repository.issues.pageInfo.endCursor;
  }
  return numbers;
}

export async function fetchIssueBody(issueNumber, repo, gqlFn = gql) {
  const { owner, repoName } = splitRepo(repo);
  const data = await gqlFn(
    `
    query($owner: String!, $repo: String!, $issue: Int!) {
      repository(owner: $owner, name: $repo) {
        issue(number: $issue) { body }
      }
    }`,
    { owner, repo: repoName, issue: Number(issueNumber) }
  );
  return data?.repository?.issue?.body ?? '';
}

// I/O + orchestration seams are injectable (`deps`) so `main` is exercisable
// offline; every dep defaults to the real implementation, keeping the CLI
// runtime path byte-identical.
export async function main(argv, deps = {}) {
  const loadConfigFn = deps.loadConfig || loadConfig;
  const fetchNumbers = deps.fetchAllIssueNumbers || fetchAllIssueNumbers;
  const fetchBody = deps.fetchIssueBody || fetchIssueBody;
  const mutate = deps.mutateIssueBody || mutateIssueBody;
  const out = deps.out || process.stdout;
  const err = deps.err || process.stderr;
  const exit = deps.exit || ((code) => process.exit(code));

  const args = parseArgs(argv, { out, err, exit });
  const cfg = loadConfigFn();
  if (!cfg.repo) {
    err.write('heal-functional-dod: repo not configured\n');
    return exit(1);
  }
  if (!cfg.projectId) {
    err.write('heal-functional-dod: projectId not configured\n');
    return exit(1);
  }

  const numbers =
    args.scope ??
    (await fetchNumbers({ repo: cfg.repo, state: args.state, projectId: cfg.projectId }));

  out.write(
    `heal-functional-dod: mode=${args.apply ? 'APPLY' : 'dry-run'} state=${args.state} issues=${numbers.length}\n`
  );

  if (args.apply) {
    const confirm = deps.confirmBlastRadius || confirmBlastRadius;
    const decision = await confirm({
      issueNumbers: numbers,
      yes: args.yes,
      log: (s) => out.write(s),
      warn: (s) => err.write(s),
    });
    if (!decision.proceed) return exit(2);
  }

  let affectedCount = 0;
  let healedCount = 0;
  let errorCount = 0;

  for (const n of numbers) {
    try {
      const body = await fetchBody(n, cfg.repo);
      const det = detectMissingKeys(body);
      if (!det.affected) continue;
      affectedCount++;
      out.write(`#${n}\tmissing: ${det.missingKeys.join(',')}\n`);
      if (args.apply) {
        const res = await mutate({
          issueNumber: n,
          repo: cfg.repo,
          mutate: (base) => healFunctionalSection(base).body,
          deps: { pexec },
        });
        if (res?.status !== 'no-op') healedCount++;
      }
    } catch (e) {
      errorCount++;
      out.write(`#${n}\tERROR: ${e.message}\n`);
    }
  }

  out.write(`Summary: affected=${affectedCount} healed=${healedCount} errors=${errorCount}\n`);
}

const _isMain = (() => {
  try {
    return process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1]);
  } catch {
    return false;
  }
})();

if (_isMain) {
  main(process.argv.slice(2)).catch((err) => {
    process.stderr.write(`heal-functional-dod: ${err.stack || err.message}\n`);
    process.exit(1);
  });
}
