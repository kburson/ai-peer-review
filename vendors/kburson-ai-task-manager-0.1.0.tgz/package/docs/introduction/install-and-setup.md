# Install and Setup

This guide gets AI Task Manager running inside a local project and explains what the installer adds.

## Prerequisites

Install these before running the package:

- Node.js 24 or newer
- GitHub CLI, authenticated with `gh auth login`
- `jq`
- Git
- Access to the GitHub repository you want agents to work in
- Access to a GitHub Projects V2 board, or permission for setup to create/configure one
- Claude Code and/or Codex, depending on which agent experience you want to use

## Install GitHub CLI

AI Task Manager uses the GitHub CLI for issue, project, and GraphQL operations. Install `gh` first, then authenticate before running `npx @kburson/ai-task-manager init`.

Recommended official install paths:

| Platform      | Command                             | Notes                                                                     |
| ------------- | ----------------------------------- | ------------------------------------------------------------------------- |
| macOS         | `brew install gh`                   | Official GitHub CLI docs list Homebrew as the recommended macOS path      |
| Windows       | `winget install --id GitHub.cli`    | Open a new Windows Terminal window after install so PATH changes apply    |
| Linux and BSD | See the official Linux instructions | Package setup differs by distribution and signed repository configuration |

After installation:

```bash
gh --version
gh auth login
gh auth status
```

Useful official references:

- [Installing `gh` on macOS](https://github.com/cli/cli/blob/trunk/docs/install_macos.md)
- [Installing `gh` on Windows](https://github.com/cli/cli/blob/trunk/docs/install_windows.md)
- [Installing `gh` on Linux and BSD](https://github.com/cli/cli/blob/trunk/docs/install_linux.md)
- [GitHub CLI manual](https://cli.github.com/manual/)

## Install

From the root of your project:

```bash
npx @kburson/ai-task-manager install
```

By default, this installs support for both Claude Code and Codex. To install only one adapter:

```bash
npx @kburson/ai-task-manager install --agent claude
npx @kburson/ai-task-manager install --agent codex
```

The installer writes stable, project-local files so every developer and agent in the repository shares the same workflow contract.

Common generated paths:

| Path                           | Purpose                                                                                   |
| ------------------------------ | ----------------------------------------------------------------------------------------- |
| `.ai-task-manager/`            | Project config, runtime templates, memory index, Pickup Directive, and Definition of Done |
| `.claude/skills/task/SKILL.md` | Claude Code task skill shim                                                               |
| `.agents/skills/task/SKILL.md` | Codex task skill shim                                                                     |
| `.claude/settings.json`        | Claude Code hook and allow-rule configuration when applicable                             |
| `.codex/hooks.json`            | Codex hook configuration when Codex support is installed                                  |

```mermaid
flowchart TB
    Install["npx @kburson/ai-task-manager install"] --> AgentFiles["Agent skill shims"]
    Install --> Templates[".ai-task-manager templates"]
    Install --> Hooks["Claude hooks and guards"]
    Init["npx @kburson/ai-task-manager init"] --> ProjectConfig["task-tracker.json"]
    Init --> IssueTemplates["GitHub issue templates"]
    ProjectConfig --> Commands["/task commands"]
    AgentFiles --> Commands
    Templates --> Commands
```

The `init` command adds GitHub project configuration and issue templates:

| Path                                 | Purpose                                                       |
| ------------------------------------ | ------------------------------------------------------------- |
| `.ai-task-manager/task-tracker.json` | GitHub repo, project, field, workflow, and user configuration |
| `.github/ISSUE_TEMPLATE/`            | Issue form support                                            |

Commit the generated project files:

```bash
git add .ai-task-manager/ .github/ISSUE_TEMPLATE/ .claude/settings.json .claude/commands/task.md .claude/skills/task/SKILL.md .codex/hooks.json .agents/ AGENTS.md CLAUDE.md
git commit -m "chore: add ai-task-manager"
```

Run `install` and `init` once in a maintainer environment, then commit the project-portable outputs. Ephemeral cloud environments should clone the repository and run normal tool setup such as `npm ci`; they should not rerun the interactive installer or initialize project board metadata.

Review the diff before committing. If your repository does not use both Claude Code and Codex, only stage the adapter folder you installed.

## Remove AI Task Manager From a Project

Run project cleanup while the package is still installed, then remove the npm
dependency:

```bash
npx @kburson/ai-task-manager uninstall --dry-run
npx @kburson/ai-task-manager uninstall
npm uninstall -D @kburson/ai-task-manager
```

By default, uninstall removes AITM-owned executable integrations while keeping
durable `.ai-task-manager/` configuration, memory, templates, and GitHub issue
templates. It preserves unrelated entries in shared hook and settings files and
refuses to remove modified generated files. `--agent claude|codex|grok|all`
limits cleanup to selected providers.

To remove durable AITM data as well, inspect the destructive plan and confirm it
explicitly:

```bash
npx @kburson/ai-task-manager uninstall --purge --dry-run
npx @kburson/ai-task-manager uninstall --purge --yes
```

Purge mode additionally removes `.ai-task-manager/`, `.tmp/aitm/`, and
unmodified AITM-owned `task.yml` and `bug.yml` issue templates. Other issue
templates remain untouched.

## Initialize GitHub Project Integration

Run:

```bash
npx @kburson/ai-task-manager init
```

The initializer connects the local project to GitHub and stores the board IDs needed by the task workflow. It can use an existing linked project, link an existing user or organization project, or create/configure a compatible project board.

The important output is `.ai-task-manager/task-tracker.json`, which records values such as:

- GitHub repo name
- GitHub Projects V2 project ID
- Status field ID and option IDs
- Size, Estimate, Priority, Sequence, and timing field IDs
- User-level workflow preferences

These IDs are intentionally stored in project config so future task commands do not require manual GraphQL setup.

## Optional Codex Superpowers Bootstrap

If your team uses Claude Code Superpowers and wants Codex to follow similar workflow discipline, run:

```bash
npx @kburson/ai-task-manager install --codex-superpowers
```

This mirrors supported Superpowers skills into `~/.codex/skills` when a local Claude Code Superpowers cache is available, then writes a managed bootstrap block to the repo `AGENTS.md`. The AITM task skill remains separate at `.agents/skills/task/SKILL.md`.

Use the global variant only when you intentionally want global Codex instructions:

```bash
npx @kburson/ai-task-manager install --codex-superpowers-global
```

## Verify The Install

Run the task command help from an agent session:

```text
/task help
```

Or through the package CLI:

```bash
npx @kburson/ai-task-manager --help
```

Then start with a real issue:

```text
/task #42
```

A successful start should:

- Register issue `#42` as the active task.
- Start or resume the timing baseline.
- Let the installed skill read the issue title and body for context.
- Let the installed skill enforce the current workflow state and gate requirements before implementation.
- Preserve timing state under `.ai-task-manager/`.

## Package Publishing Note

`package.json#files` controls what actually ships to npm. The package currently ships:

- `LICENSE`, `LICENSE-COMMERCIAL`, `NOTICE`
- `bin/`
- `config/`
- `skill/`
- `hooks/` for legacy compatibility assets
- `scripts/` (excluding `scripts/tests/**`, `scripts/maintenance/`, and `*.test.mjs` files)
- `statusline/`
- `docs/README.md`, `docs/QUICKSTART.md`, `docs/DESIGN.md`
- `docs/guides/`
- `docs/introduction/`
- `docs/ai-memory/` (excluding `docs/ai-memory/archive/`)
- `templates/`

Users installing from the registry can read `docs/README.md`, `docs/QUICKSTART.md`, `docs/DESIGN.md`, `docs/guides/`, `docs/introduction/`, and `docs/ai-memory/` locally under `node_modules/@kburson/ai-task-manager/docs/`.

## Common Setup Problems

`gh: command not found`
: Install the GitHub CLI and authenticate with `gh auth login`.

`jq: command not found`
: Install `jq` with your platform package manager.

`task-tracker not configured`
: Run `npx @kburson/ai-task-manager init` from the project root.

Project field errors
: Re-run `npx @kburson/ai-task-manager init` and confirm the configured GitHub Project board has the expected Status, Size, Estimate, Priority, Sequence, and timing fields.

Timing data missing after a reset
: Make sure agent hooks were installed and avoid clearing a session without pausing first. Before a destructive context reset, run `/task pause`.
